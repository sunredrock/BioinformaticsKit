package print_final_PE_report;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(print_final_PE_report);
use strict;

#=======================================
sub print_final_PE_report{
	my (
					$date_stamps,$total_read_count,$total_bases_count,
						$specific_params, $paths, $five_prime_adapter_sequences_part,
						# Main parameters
						$fh_log,
						$mode, $input_filepath_1, $input_filepath_2, $output_dir, $method_sequence_arr_ref, $min_read_length, 
						$ASCII_of_zero_qual_score,
		
		     # Method Parameters
					# PE_ThreeEnd, PE_FiveEnd, TERA
						 $n_threeEnd, $n_fiveEnd, $avg_cutoff,
						# PE_five_prime_adpt
						 $five_prime_adapter_filepath, 
						 $match_percentage, $furthest_allowed_index_for_adapter_match, 
						 $adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
						# PE_LQR
						 $LQS_cutoff, $QPerc_cutoff,
						# PE_Mott
						 $mott_limit,
						# PE_Ncutoff, PE_NPerc, PE_Nsplit
						 $N_cutoff, $Nperc_cutoff, $num_n_cutoff, 
						# qseqB
						 $B_num_cutoff, $detection_mode, $action,
				 # Method counters 
					# PE_ThreeEnd
					 $num_bases_trimmed_by_ThreeEnd, $num_reads_trimmed_by_ThreeEnd, $num_pairs_trimmed_by_ThreeEnd,
					# PE_FiveEnd
					 $num_bases_trimmed_by_FiveEnd, $num_reads_trimmed_by_FiveEnd,$num_pairs_trimmed_by_FiveEnd,
					# PE_five_prime_adpt
					 $num_adpt_trimmed_bases,$num_adpt_trimmed_reads,$num_adpt_trimmed_pairs, $num_detected_adapter_sequences, 
					# PE_LQR
					 $number_of_LQR_trimmed_bases, $number_of_LQR_trimmed_reads,$number_of_LQR_trimmed_pairs,
					# PE_Mott
					 $num_mott_trimmed_bases, $num_mott_trimmed_reads,$num_mott_trimmed_pairs,
					# PE_Ncutoff
					 $num_bases_trimmed_by_Ncuotff, $num_reads_trimmed_by_Ncuotff,$num_pairs_trimmed_by_Ncuotff,
					# PE_NPerc
					 $num_bases_trimmed_by_Nperc, $num_reads_trimmed_by_Nperc,$num_pairs_trimmed_by_Nperc,
					# PE_Nsplit
					 $num_of_removed_bases_using_Nsplit, $num_of_removed_N_blocks,$num_of_Nsplit_removed_reads, $num_of_Nsplit_removed_pairs,
					# qseq0
					 $num_bases_trimmed_by_qseq0, $num_reads_trimmed_by_qseq0, $num_pairs_trimmed_by_qseq0,
					# qseqB
					 $num_bases_trimmed_by_qseqB, $num_reads_trimmed_by_qseqB, $num_pairs_trimmed_by_qseqB,
					# TERA
					 $num_TERA_trimmed_bases,$num_TERA_trimmed_reads, $num_TERA_trimmed_pairs,
					# rmHP
					  $num_rmHP_trimmed_bases,$num_rmHP_trimmed_reads,$num_rmHP_trimmed_pairs	
		) = @_;
	
my $method_sequence = join (' ', @$method_sequence_arr_ref);

	
	my $total_trimmed_bases = $num_bases_trimmed_by_ThreeEnd + $num_bases_trimmed_by_FiveEnd + $num_adpt_trimmed_bases
														+ $number_of_LQR_trimmed_bases + $num_mott_trimmed_bases + $num_bases_trimmed_by_Ncuotff
														+ $num_bases_trimmed_by_Nperc + $num_of_removed_bases_using_Nsplit + $num_bases_trimmed_by_qseq0
														+ $num_bases_trimmed_by_qseqB + $num_TERA_trimmed_bases + $num_rmHP_trimmed_bases,;						 
							  						  
	
	my $total_trimmed_reads = $num_reads_trimmed_by_ThreeEnd + $num_reads_trimmed_by_FiveEnd + $num_adpt_trimmed_reads
														+ $number_of_LQR_trimmed_reads + $num_mott_trimmed_reads + $num_reads_trimmed_by_Ncuotff
														+ $num_reads_trimmed_by_Nperc + $num_of_Nsplit_removed_reads + $num_reads_trimmed_by_qseq0
														+ $num_reads_trimmed_by_qseqB + $num_TERA_trimmed_reads + $num_rmHP_trimmed_reads;
	
	my $total_trimmed_pairs = $num_pairs_trimmed_by_ThreeEnd + $num_pairs_trimmed_by_FiveEnd + $num_adpt_trimmed_pairs
														+ $number_of_LQR_trimmed_pairs + $num_mott_trimmed_pairs + $num_pairs_trimmed_by_Ncuotff
														+ $num_pairs_trimmed_by_Nperc + $num_of_Nsplit_removed_pairs + $num_pairs_trimmed_by_qseq0
														+ $num_pairs_trimmed_by_qseqB + $num_TERA_trimmed_pairs + $num_rmHP_trimmed_pairs; 
	
	
	

	print $fh_log "--------------------------------- PATHS & METHOD PARAMERTERS--------------------------------------------------\n";
	print $fh_log $specific_params.$paths.$five_prime_adapter_sequences_part;
	print $fh_log "--------------------------------------------------------------------------------------------------------------\n\n";


	print $fh_log "========================================== FINAL REPORT =====================================================\n\n";
	print $fh_log $date_stamps;
	print $fh_log "Read Pair Count: ".($total_read_count/2)."\n";
  print $fh_log "Raw Base Count: $total_bases_count\n";
  print $fh_log "\n";	
    
	my $rounded_percentage_of_all_trimmed_bases = sprintf ("%.3f", (100 *  ($total_trimmed_bases/$total_bases_count))); 	
	my $rounded_percentage_of_all_trimmed_reads = sprintf ("%.3f", (100 *  ($total_trimmed_reads/$total_read_count))); 
	my $rounded_percentage_of_all_trimmed_pairs = sprintf ("%.3f", (100 *  ($total_trimmed_pairs/($total_read_count/2)))); 
	
	print $fh_log "---------------------------------- TOTAL REMOVED BASE/READ/PE_PAIR COUNTS -----------------------------------\n";

	print $fh_log "Removed Base Count: $total_trimmed_bases ($rounded_percentage_of_all_trimmed_bases%)\n";
	print $fh_log "Removed PE Pair* Count: $total_trimmed_pairs ($rounded_percentage_of_all_trimmed_pairs%)\n";
	print $fh_log "Removed Reads Count: $total_trimmed_reads ($rounded_percentage_of_all_trimmed_reads%)\n";
	
	print $fh_log "\n*A read is 'removed' (from the trimmed_ files) if it failed one of the trimming methods.\n".
	              "A read pair is 'removed' from a file because one or both of its reads were 'removed' from \n".
	              "the file. If only one read was removed, its mate read will be saved to surviving_mates.fastq.\n". 
	              "So, note that removed_PE_pair_count is not necessarily = (removed_read_count/2).\n\n";
	
#	print $fh_log "--------------------------------------------------------------------------------------------------------------\n\n";
	
	print $fh_log "\n\n------------------------------ REMOVED BASE/READ/PE PAIR COUNTS BY METHOD------------------------------------\n";
	
    if ( $method_sequence =~ /lqr/){
    	print $fh_log "Low quality Perc trimming:\n";
    	
    	if ($number_of_LQR_trimmed_pairs > 0){
    		my $rounded_percentage_lqperc_trimmed_reads = sprintf ("%.3f", (100 * ($number_of_LQR_trimmed_reads/$total_read_count)));    	
    		my $reads_that_survived_lqperc = ($number_of_LQR_trimmed_pairs * 2)-$number_of_LQR_trimmed_reads;
			  my $rounded_percentage_trimmed_bases = sprintf ("%.3f", (100 * ($number_of_LQR_trimmed_bases/$total_bases_count)));
		
			print $fh_log "\tRemoved Base Count: $number_of_LQR_trimmed_bases (".$rounded_percentage_trimmed_bases."%)\n";
			print $fh_log "\tRemoved Read Count: $number_of_LQR_trimmed_reads (".$rounded_percentage_lqperc_trimmed_reads."%)\n";
			print $fh_log "\tSurviving Read Count:  $reads_that_survived_lqperc\n";
			print $fh_log "\tRemoved PE Pair Count:  $number_of_LQR_trimmed_pairs\n";
			
			
    	}
    	else {
    		print $fh_log "No bases or reads were Removed by Low quality Perc in this file.\n";
    	}
		print $fh_log "\n\n";
    }
    
    if ($method_sequence =~ /5adpt/){
    	print $fh_log "5' adapter trimming :\n";
    	if ($num_detected_adapter_sequences > 0){
    		my $rounded_percentage_trimmed_bases = sprintf ("%.3f", (100 * ($num_adpt_trimmed_bases/$total_bases_count)));
    		my $reads_that_survived_adpt = ($num_adpt_trimmed_pairs * 2)-$num_adpt_trimmed_reads;
    		my $rounded_percentage_adpt_trimmed_reads = sprintf ("%.3f", (100 * ($num_adpt_trimmed_reads/$total_read_count)));
    		my $rounded_percentage_adpt_matched_reads = sprintf ("%.3f", (100 * ($num_detected_adapter_sequences/$total_read_count)));  
    		
				print $fh_log "\tMatched read count: $num_detected_adapter_sequences (".$rounded_percentage_adpt_matched_reads."%)\n";
				print $fh_log "\tRemoved Base Count: $num_adpt_trimmed_bases (".$rounded_percentage_trimmed_bases."%)\n";
				print $fh_log "\tRemoved Read Count: $num_adpt_trimmed_reads (".$rounded_percentage_adpt_trimmed_reads."%)\n";
				print $fh_log "\tSurviving Read Count: $reads_that_survived_adpt \n";
				print $fh_log "\tRemoved PE Pair Count: $num_adpt_trimmed_pairs \n";
			}
    	else {
    		print $fh_log "No 5' adapter sequences were detected in this file.\n";
    	}	
		print $fh_log "\n\n";
    }
	
	if ($method_sequence =~ /tera/){
    	print $fh_log "TERA: \n";
		if ($num_TERA_trimmed_bases > 0){
    		my $rounded_percentage_trimmed_bases = sprintf ("%.3f", (100 * ($num_TERA_trimmed_bases/$total_bases_count)));
    		my $reads_that_survived_tera = ($num_TERA_trimmed_pairs * 2)-$num_TERA_trimmed_reads;
    		my $rounded_percentage_3end_trimmed_reads = sprintf ("%.3f", (100 * ($num_TERA_trimmed_reads/$total_read_count))); 
				
				print $fh_log "\tRemoved Base Count: $num_TERA_trimmed_bases (".$rounded_percentage_trimmed_bases."%)\n";
				print $fh_log "\tRemoved Read Count: $num_TERA_trimmed_reads (".$rounded_percentage_3end_trimmed_reads."%)\n";
				print $fh_log "\tSurviving Read Count: $reads_that_survived_tera \n";
				print $fh_log "\tRemoved PE Pair Count: $num_TERA_trimmed_pairs \n";
    	}
    	else {
    		print $fh_log "No bases were Removed using 3' end trimming in this file.\n";
    	}	
		print $fh_log "\n\n";	
		
    }
	
	if ($method_sequence =~ /mott/){
    	print $fh_log "Modified R. Mott trimming:\n";

		if ($num_mott_trimmed_bases > 0){
    		my $rounded_percentage_trimmed_bases = sprintf ("%.3f", (100 * ($num_mott_trimmed_bases/$total_bases_count)));
    		my $reads_that_survived_mott = ($num_mott_trimmed_pairs * 2)-$num_mott_trimmed_reads;
    		my $rounded_percentage_mott_trimmed_reads = sprintf ("%.3f", (100 * ($num_mott_trimmed_reads/$total_read_count))); 
    		
				print $fh_log "\tRemoved Base Count: $num_mott_trimmed_bases (".$rounded_percentage_trimmed_bases."%)\n";
				print $fh_log "\tRemoved Read Count: $num_mott_trimmed_reads (".$rounded_percentage_mott_trimmed_reads."%)\n";
				print $fh_log "\tSurviving Read Count: $reads_that_survived_mott \n";
				print $fh_log "\tRemoved PE Pair Count: $num_mott_trimmed_pairs \n";
    	}
    	else {
    		print $fh_log "No bases were Removed using Modified Mott trimming in this file.\n";
    	}			
    	print $fh_log "\n\n"; 	 

    }

	if ($method_sequence =~ /nsplit/){
    	print $fh_log "Leftmost N-block Splitting:\n";
    	if ($num_of_removed_N_blocks > 0){
    		my $rounded_percentage_trimmed_bases = sprintf ("%.3f", (100 * ($num_of_removed_bases_using_Nsplit/$total_bases_count)));
    		my $rounded_percentage_Nblock_reads = sprintf ("%.3f", (100 * ($num_of_Nsplit_removed_reads/$total_read_count))); 

				print $fh_log "\tRemoved Base Count:  (".$rounded_percentage_trimmed_bases."%)\n";
				print $fh_log "\tRemoved N-block Count:  (".$num_of_removed_N_blocks."%)\n";
				print $fh_log "\tRemoved Read Count:  $num_of_Nsplit_removed_reads (".$rounded_percentage_Nblock_reads."%)\n";
				print $fh_log "\tRemoved PE Pair Count: $num_of_Nsplit_removed_pairs \n";
    	}
    	else {
    		print $fh_log "No N-blocks of length >= $num_n_cutoff were found in this file.\n";
    	}
    	print $fh_log "\n\n";
    }
    
    if ($method_sequence =~ /nperc/){
    	print $fh_log "NPERC:\n";
   	    if ($num_reads_trimmed_by_Nperc > 0){
					my $rounded_percentage_Nperc_trimmed_reads = sprintf ("%.3f", (100 * ($num_reads_trimmed_by_Nperc/$total_read_count)));    	
					my $reads_that_survived_nperc = ($num_pairs_trimmed_by_Nperc * 2)-$num_reads_trimmed_by_Nperc;
					my $rounded_percentage_trimmed_bases = sprintf ("%.3f", (100 * ($num_bases_trimmed_by_Nperc/$total_bases_count)));
					
					print $fh_log "\tRemoved Base Count: $num_bases_trimmed_by_Nperc (".$rounded_percentage_trimmed_bases."%)\n";
					print $fh_log "\tRemoved Read Count: $num_reads_trimmed_by_Nperc (".$rounded_percentage_Nperc_trimmed_reads."%)\n";
					print $fh_log "\tSurviving Read Count: $reads_that_survived_nperc \n";
					print $fh_log "\tRemoved PE Pair Count: $num_pairs_trimmed_by_Nperc \n";
    	}
    	else {
    		print $fh_log "No bases or reads were Removed by NPerc in this file.\n";
    	}
    	print $fh_log "\n\n";
    }

					
	if ($method_sequence =~ /ncutoff/){
    	print $fh_log "N_Cutoff:\n";
   	    if ($num_reads_trimmed_by_Ncuotff > 0){
					my $rounded_percentage_Ncutoff_trimmed_reads = sprintf ("%.3f", (100 * ($num_reads_trimmed_by_Ncuotff/$total_read_count)));    	
					my $reads_that_survived_ncutoff = ($num_pairs_trimmed_by_Ncuotff * 2)-$num_reads_trimmed_by_Ncuotff;
					my $rounded_percentage_trimmed_bases = sprintf ("%.3f", (100 * ($num_bases_trimmed_by_Ncuotff/$total_bases_count)));
					
						print $fh_log "\tRemoved Base Count: $num_bases_trimmed_by_Ncuotff (".$rounded_percentage_trimmed_bases ."%)\n";
						print $fh_log "\tRemoved Read Count: $num_reads_trimmed_by_Ncuotff (".$rounded_percentage_Ncutoff_trimmed_reads."%)\n";
						print $fh_log "\tSurviving Read Count:  $reads_that_survived_ncutoff\n";
						print $fh_log "\tRemoved PE Pair Count: $num_pairs_trimmed_by_Ncuotff  \n";
    	}
    	else {
    		print $fh_log "No bases or reads were Removed by N_Cutoff in this file.\n";
    	}
    	print $fh_log "\n\n";
    }
		
	if ($method_sequence =~ /qseqB/){
    	print $fh_log "qseqB:\n";
   	    if ($num_bases_trimmed_by_qseqB > 0){
					my $rounded_percentage_qseqB_trimmed_reads = sprintf ("%.3f", (100 * ($num_reads_trimmed_by_qseqB /$total_read_count)));    	
					my $reads_that_survived_qseqB = ($num_pairs_trimmed_by_qseqB * 2)-$num_reads_trimmed_by_qseqB;
					my $rounded_percentage_trimmed_bases = sprintf ("%.3f", (100 * ($num_bases_trimmed_by_qseqB /$total_bases_count)));
					
					print $fh_log "\tRemoved Base Count: $num_bases_trimmed_by_qseqB (".$rounded_percentage_trimmed_bases."%)\n";
					print $fh_log "\tRemoved Read Count: $num_reads_trimmed_by_qseqB (".$rounded_percentage_qseqB_trimmed_reads."%)\n";
					print $fh_log "\tSurviving Read Count: $reads_that_survived_qseqB \n";
					print $fh_log "\tRemoved PE Pair Count: $num_pairs_trimmed_by_qseqB \n";
    	}
    	else {
    		print $fh_log "No bases or reads were Removed by qseqB in this file.\n";
    	}
    	print $fh_log "\n\n";
    }
		
		#	 $num_bases_trimmed_by_qseq0, $num_reads_trimmed_by_qseq0, $num_pairs_trimmed_by_qseq0,
			if ($method_sequence =~ /qseq0/){
				print $fh_log "qseq0:\n";
				
				if ($num_reads_trimmed_by_qseq0 > 0){
   	    	my $rounded_percentage_qseq0_trimmed_reads = sprintf ("%.3f", (100 * ($num_reads_trimmed_by_qseq0 /$total_read_count)));    	
					my $reads_that_survived_qseq0 = ($num_pairs_trimmed_by_qseq0 * 2)-$num_reads_trimmed_by_qseq0;
					my $rounded_percentage_trimmed_bases = sprintf ("%.3f", (100 * ($num_bases_trimmed_by_qseq0 /$total_bases_count)));
					
					print $fh_log "\tRemoved Base Count: $num_bases_trimmed_by_qseq0 (".$rounded_percentage_trimmed_bases."%)\n";
					print $fh_log "\tRemoved Read Count: $num_reads_trimmed_by_qseq0 (".$rounded_percentage_qseq0_trimmed_reads."%)\n";
					print $fh_log "\tSurviving Read Count: $reads_that_survived_qseq0 \n";
					print $fh_log "\tRemoved PE Pair Count: $num_pairs_trimmed_by_qseq0 \n";
				}
    	else {
    		print $fh_log "No bases or reads were Removed by qseq0 in this file.\n";
    	}
    	print $fh_log "\n\n";
    }
		
	if ($method_sequence =~ /3end/){
				print $fh_log "3' end:\n";
   	    if ($num_bases_trimmed_by_ThreeEnd > 0){
					my $rounded_percentage_ThreeEnd_trimmed_reads = sprintf ("%.3f", (100 * ($num_reads_trimmed_by_ThreeEnd /$total_read_count)));    	
					my $reads_that_survived_ThreeEnd = ($num_pairs_trimmed_by_ThreeEnd * 2)-$num_reads_trimmed_by_ThreeEnd ;
					my $rounded_percentage_trimmed_bases = sprintf ("%.3f", (100 * ($num_bases_trimmed_by_ThreeEnd /$total_bases_count)));
					
					print $fh_log "\tRemoved Base Count: $num_bases_trimmed_by_ThreeEnd (".$rounded_percentage_trimmed_bases."%)\n";
					print $fh_log "\tRemoved Read Count: $num_reads_trimmed_by_ThreeEnd (".$rounded_percentage_ThreeEnd_trimmed_reads."%)\n";
					print $fh_log "\tSurviving Read Count: $reads_that_survived_ThreeEnd \n";
					print $fh_log "\tRemoved PE Pair Count: $num_pairs_trimmed_by_ThreeEnd \n";
    	}
    	else {
    		print $fh_log "No bases or reads were Removed by 3end in this file.\n";
    	}
    	print $fh_log "\n\n";
    }
		
	if ($method_sequence =~ /5end/){
		print $fh_log "5' end:\n";
   	    if ($num_bases_trimmed_by_FiveEnd > 0){
					my $rounded_percentage_FiveEnd_trimmed_reads = sprintf ("%.3f", (100 * ($num_reads_trimmed_by_FiveEnd /$total_read_count)));    	
					my $reads_that_survived_FiveEnd = ($num_pairs_trimmed_by_FiveEnd * 2)-$num_reads_trimmed_by_FiveEnd ;
					my $rounded_percentage_trimmed_bases = sprintf ("%.3f", (100 * ($num_bases_trimmed_by_FiveEnd /$total_bases_count)));
					
					print $fh_log "\tRemoved Base Count: $num_bases_trimmed_by_FiveEnd (".$rounded_percentage_trimmed_bases."%)\n";
					print $fh_log "\tRemoved Read Count: $num_reads_trimmed_by_FiveEnd (".$rounded_percentage_FiveEnd_trimmed_reads."%)\n";
					print $fh_log "\tSurviving Read Count: $reads_that_survived_FiveEnd \n";
					print $fh_log "\tRemoved PE Pair Count: $num_pairs_trimmed_by_FiveEnd \n";
    	}
    	else {
    		print $fh_log "No bases or reads were Removed by 5end in this file.\n";
    	}
    	print $fh_log "\n\n";
    }
	
	if ($method_sequence =~ /rmHP/){
		print $fh_log "remove Homopolymer:\n"; #$num_rmHP_trimmed_bases,$num_rmHP_trimmed_reads,$num_rmHP_trimmed_pairs
   	    if ($num_rmHP_trimmed_bases> 0){
				my $rounded_percentage_rmHP_trimmed_reads = sprintf ("%.3f", (100 * ($num_rmHP_trimmed_reads /$total_read_count)));    	
				my $reads_that_survived_rmHP = ($num_rmHP_trimmed_pairs * 2)-$num_rmHP_trimmed_reads ;
				my $rounded_percentage_trimmed_bases = sprintf ("%.3f", (100 * ($num_rmHP_trimmed_bases/$total_bases_count)));
				
				print $fh_log "\tRemoved Base Count: $num_rmHP_trimmed_bases (".$rounded_percentage_trimmed_bases."%)\n";
				print $fh_log "\tRemoved Read Count: $num_rmHP_trimmed_reads (".$rounded_percentage_rmHP_trimmed_reads."%)\n";
				print $fh_log "\tSurviving Read Count: $reads_that_survived_rmHP \n";
				print $fh_log "\tRemoved PE Pair Count: $num_rmHP_trimmed_pairs \n";
    	}
    	else {
    		print $fh_log "No bases or reads were Removed by rmHP in this file.\n";
    	}
    	print $fh_log "\n\n";
    }
	
	#print $fh_log "--------------------------------------------------------------------------------------------------------------\n\n";		
	print $fh_log     "============================================ END OF REPORT ==========================================\n\n";
}
