package qseq0;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(SE_qseq0 qseq0 PE_qseq0);

use strict;
use warnings;
use single_fQ_read 1.0;
use PE_fQ_pair 1.0;


=head1 NAME

 qseq0: a module for trimming fastq reads (ONE single_fQ_read object, or two
 single_fQ_read objects within one PE_fQ_pair object) based on their passed_filtering
 flag (the last item of the qseq line). This works only for single_fQ_reads that
 were created from qseq lines. If the flag = 0, the read is killed.

=cut 




sub qseq0{
	# If the qseq_filter is 1, skip flag to 1
	my ($fq_read) = @_;
	if (($fq_read->get_qseq_filter) == 0){
		$fq_read->skip;
	}
}

sub SE_qseq0{
	my ($read, $num_bases_trimmed_by_qseq0_ref, $num_reads_trimmed_by_qseq0_ref) = @_;

	&qseq0($read);
	
	if (!($read->is_good)){ 
		$$num_reads_trimmed_by_qseq0_ref++;
		$$num_bases_trimmed_by_qseq0_ref += ($read->get_length());
	}
	return;
}

sub PE_qseq0{
	my ($PE_pair, 
	   $num_bases_trimmed_by_qseq0_ref, $num_reads_trimmed_by_qseq0_ref, $num_pairs_trimmed_by_qseq0_ref) = @_;

	my ($read1, $read2) = ($PE_pair->read1, $PE_pair->read2);
	
	&qseq0($read1);
	&qseq0($read2);	
	
	if (!($read1->is_good)){ 
		$$num_reads_trimmed_by_qseq0_ref++;
		$$num_bases_trimmed_by_qseq0_ref += ($read1->get_length());
	}
	if (!($read2->is_good)){ 
		$$num_reads_trimmed_by_qseq0_ref++;
		$$num_bases_trimmed_by_qseq0_ref += ($read2->get_length());
	}
	if ( !($read1->is_good) || !($read2->is_good) ) { 
		$$num_pairs_trimmed_by_qseq0_ref++;
	}
	return;
}