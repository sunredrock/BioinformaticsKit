package FiveEnd;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(SE_FiveEnd FiveEnd PE_FiveEnd);

use strict;
use single_fQ_read 1.0;
use PE_fQ_pair 1.0;
use warnings;
use ThreeEnd 1.0;

=head1 NAME

 FiveEnd: a module for trimming fastq reads (ONE single_fQ_read object, or two
 single_fQ_read objects within one PE_fQ_pair object) by removal of N 5' bases. 
 
=head1 SUBROUTINES

=head2 FiveEnd

 Trims N 5' bases from the read's seq and quality line by reversing the read, 
 trimming it using ThreeEnd, then reversing the read back again.

=head2 SE_FiveEnd

 Wrapper subroutine that calls FiveEnd on the read from the SE file.
 
=head2 PE_FiveEnd

 Wrapper subroutine that calls FiveEnd on each of the two reads in the PE_fQ_pair.
 passed from the PE files.

=cut 

sub FiveEnd{ 
	# Trim n bases from the 3'-end
	my ($fq_read, $n, $min_read_length) = @_;
	return 0 if ($fq_read->get_length <= $min_read_length);
	
	# 01 Reverse the seq and qual strings
		$fq_read-> reverse; 
	
	# 02 Trim the reversed read using ThreeEnd
		my $num_trimmed_bases = ThreeEnd ($fq_read, $n, $min_read_length);
		
	# 03 Reverse the read again
		$fq_read-> reverse;	
	
  return $num_trimmed_bases;
}

sub SE_FiveEnd{
	my ($read, $n, $min_read_length,
	   $num_bases_trimmed_by_FiveEnd_ref, $num_reads_trimmed_by_FiveEnd_ref) = @_;
	
	$$num_bases_trimmed_by_FiveEnd_ref += &FiveEnd($read, $n, $min_read_length);
	
	if (!($read->is_good)){
		$$num_reads_trimmed_by_FiveEnd_ref++;
	}
	return;
}

sub PE_FiveEnd{
	my ($PE_pair, $n, $min_read_length,
	   $num_bases_trimmed_by_FiveEnd_ref, $num_reads_trimmed_by_FiveEnd_ref, $num_pairs_trimmed_by_FiveEnd_ref) = @_;

	my ($read1, $read2) = ($PE_pair->read1, $PE_pair->read2);
	
  # 01 Trim reads 1 and 2 using FiveEnd, and get the number of trimmed bases
    $$num_bases_trimmed_by_FiveEnd_ref += &FiveEnd($read1, $n, $min_read_length);
    $$num_bases_trimmed_by_FiveEnd_ref += &FiveEnd($read2, $n, $min_read_length);
	
  # 02 Update the number of trimmed reads and read pairs by checking the pair's status
    my $pe_pair_status = $PE_pair-> get_status();
    # 3 means both reads are good. This means no reads were trimmed 
    # 2 means only 2 is good, 1 means only 1 is good
    # 0 means neither 
    if ($pe_pair_status == 0) {
      $$num_reads_trimmed_by_FiveEnd_ref += 2;
      $$num_pairs_trimmed_by_FiveEnd_ref += 1;
      $$num_bases_trimmed_by_FiveEnd_ref += ($PE_pair->read1->get_length()) + ($PE_pair->read2->get_length());
    }
	 # If only one read is bad, increment trimmed read counters
	    elsif ($pe_pair_status == 1) {
	      $$num_reads_trimmed_by_FiveEnd_ref += 1;
	      $$num_pairs_trimmed_by_FiveEnd_ref += 1;
	      $$num_bases_trimmed_by_FiveEnd_ref += ($PE_pair->read2->get_length());
	    }
	    elsif ($pe_pair_status == 2) {
	      $$num_reads_trimmed_by_FiveEnd_ref += 1;
	      $$num_pairs_trimmed_by_FiveEnd_ref += 1;
	      $$num_bases_trimmed_by_FiveEnd_ref += ($PE_pair->read1->get_length());
	    }
  
  return;
}