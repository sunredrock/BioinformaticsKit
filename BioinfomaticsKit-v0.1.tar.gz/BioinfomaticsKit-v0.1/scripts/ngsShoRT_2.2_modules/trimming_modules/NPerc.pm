package NPerc;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(SE_NPerc NPerc PE_NPerc);

use strict;
use warnings;
use single_fQ_read 1.0;
use PE_fQ_pair 1.0;


=head1 NAME

 NPerc: a module for trimming fastq reads (ONE single_fQ_read object, or two
 single_fQ_read objects within one PE_fQ_pair object) based on the percentage of
 'N' (uncalled) bases in their sequence line. 
   
=head1 SUBROUTINES

=head2 NPerc
 
  Takes a single_fQ_read and nperc_cutoff, a cutoff percentage of 'N' bases. 
  The read's _skip flag is set to 1 (telling process_single_read to discard 
  the read) if the percentage of N bases is >= nperc_cutoff.

=head2 SE_NPerc

 Wrapper subroutine that calls NPerc on the read from the SE file.
 
=head2 PE_NPerc

 Wrapper subroutine that calls NPerc on each of the two reads in the PE_fQ_pair
 passed from the PE files.

=cut 


sub NPerc{
	# If the percentage of N/dot bases in a read is >= nperc_cutoff, set the read's
	# skip flag to 1
	my ($fq_read, $nperc_cutoff) = @_;
	my $seq_ref = $fq_read->get_seq_ref();
	
	if (!$$seq_ref){
		print "WARNING (NPerc): this read's sequence line is empty:\n".$fq_read->return_fQ_string."\n";
		$fq_read->skip();
		return;
	}
	
	my @dotN_matches = ($$seq_ref =~ /[.Nn]/g);
	if (@dotN_matches) {
		if (((($#dotN_matches + 1)/(length $$seq_ref))* 100) >= $nperc_cutoff){
			$fq_read->skip();
		}
	}
}# end sub NPerc

sub SE_NPerc{
	my ($read, $Nperc_cutoff, 
	   $num_bases_trimmed_by_Nperc_ref, $num_reads_trimmed_by_Nperc_ref) = @_;

	&NPerc($read, $Nperc_cutoff);
	
	if (!($read->is_good)){ 
		$$num_reads_trimmed_by_Nperc_ref++;
		$$num_bases_trimmed_by_Nperc_ref += ($read->get_length());
	}
	return;
}


sub PE_NPerc{
	my ($PE_pair, $Nperc_cutoff, 
	   $num_bases_trimmed_by_Nperc_ref, $num_reads_trimmed_by_Nperc_ref, $num_pairs_trimmed_by_Nperc_ref) = @_;

	my ($read1, $read2) = ($PE_pair->read1, $PE_pair->read2);
	
	&NPerc($read1, $Nperc_cutoff);
	&NPerc($read2, $Nperc_cutoff);	
	
	if (!($read1->is_good)){ 
		$$num_reads_trimmed_by_Nperc_ref++;
		$$num_bases_trimmed_by_Nperc_ref += ($read1->get_length());
	}
	if (!($read2->is_good)){ 
		$$num_reads_trimmed_by_Nperc_ref++;
		$$num_bases_trimmed_by_Nperc_ref += ($read2->get_length());
	}
	if ( !($read1->is_good) || !($read2->is_good) ) { 
		$$num_pairs_trimmed_by_Nperc_ref++;
	}
	return;
}