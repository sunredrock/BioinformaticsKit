package qseqB;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(SE_qseqB qseqB PE_qseqB);

use strict;
use warnings;
use single_fQ_read 1.0;
use PE_fQ_pair 1.0;


=head1 NAME

 qseqB: a module for trimming fastq reads (ONE single_fQ_read object, or two
 single_fQ_read objects within one PE_fQ_pair object) by detecting substrings
 of bases with B-quality scores ('B' = undefined, error in Illumina scoring).
 
=head1 SUBROUTINES

=head2 qseqB

 Input:
 ------ 
   - The read (as a single_fQ_read object), 
   - B_num_cutoff: the cutoff number of B-scored bases.
   - detection_mode: how to "count/find" B-scored bases.
   - action: what to do with a read that was "detected"
  
 Detection and Action:
 ---------------------   
  A read is detected using either of two modes: "global" or "local". "global" 
  mode simply means counting the number of B-scored bases in the read; if it's >=
  B_num_cutoff, the read should be killed (by setting its _skip flag to 1). 
  
  "local" mode means try to find a continuous string of B-scored bases whose length
  is >= B_num_cutoff. If such a substring is found, two actions are possible: "ka",
  which is to remove the string and all bases 3' to it, or "kr", which means to kill
  the entire read.

=head2 SE_qseqB

 Wrapper subroutine that calls qseqB on the read from the SE file.
 
=head2 PE_qseqB

 Wrapper subroutine that calls qseqB on each of the two reads in the PE_fQ_pair
 passed from the PE files.

=cut 



sub qseqB{
	# Check qseq for B-quality scored Bases in either of two modes:
	#  - Global : find (and count) B-scored bases in the read
	#  - Local  : find a sting of B-scored bases whose length >= B_num_cutoff
	# Then, do either of two actions:
	#  - ka : Kill bases AFTER the detected local string (applicable only to Local mode)
	#  - kr : Kill the entire read (works with either mode) after the leftmost of the detected B-blocks
	
	my ($fq_read, $B_num_cutoff, $detection_mode, $action) = @_;
	my $qual_ref = $fq_read->get_qual_ref();
	my $num_trimmed_bases =0;
	
	if (($detection_mode eq "global") && ($action eq "ka")){die "ERROR at qseqB: 'global' detection mode can work only with 'kr' action\n";}
	
	if (!$$qual_ref){
		print "WARNING (qseqB): this read's quality line is empty:\n".$fq_read->return_fQ_string."\n";
		return;
	}
	if ($detection_mode eq "global"){
		my @B_matches = ($$qual_ref =~ /B/g);
		
		if ((@B_matches >= $B_num_cutoff) && ($action eq "kr")){
			$fq_read -> skip;
			$num_trimmed_bases = (length $$qual_ref);
		}
	}
	
	elsif ($detection_mode eq "local"){
		#my ($qual_before_first_B_block, $leftmost_B_block) = ($qual =~ /([^B]+)([B]{$B_num_cutoff,})/g);
		
		my ($qual_before_first_B_block, $leftmost_B_block) ;
		if ($$qual_ref =~ /B{$B_num_cutoff,}/){
			$qual_before_first_B_block = $`;
			$leftmost_B_block = $&;
		}
		#die ">> $qual_before_first_B_block, $leftmost_B_block\n";
		
		if ($leftmost_B_block){
			if ($action eq "kr"){
				$fq_read -> skip;
				$num_trimmed_bases = (length $$qual_ref);
			}
			elsif ($action eq "ka"){
				# Trim the read down to the part before the B-block was detected
					my $old_qual_length = length $$qual_ref;
					$$qual_ref  = $qual_before_first_B_block;
					my $seq_ref = $fq_read -> get_seq_ref;
					my $length_qual_before_first_B_block = (length $qual_before_first_B_block);
					$$seq_ref   = substr $$seq_ref, 0, $length_qual_before_first_B_block;
				
				# Count the number of trimmed bases
				if (! $fq_read ->is_good){
					$fq_read -> skip;
					$num_trimmed_bases = $old_qual_length;
					#print $num_trimmed_bases."\n";
				}
				else{
						$num_trimmed_bases = $old_qual_length - $length_qual_before_first_B_block;
				}
			}
		}
	}
	
	return $num_trimmed_bases;
}

sub SE_qseqB{
	my ($read, $B_num_cutoff, $detection_mode, $action,
	   $num_bases_trimmed_by_qseqB_ref, $num_reads_trimmed_by_qseqB_ref) = @_;

	if ($read->get_ascii_zero != 64) {
		die "ERROR at SE_qseqB: the following read is not Illumina-scored (ascii_of_zero_qual_score is ".$read->get_ascii_zero." instead of 64) :\n".$read->return_fQ_string."\n\nIf you are indeed using Illumina-scored Qseq reads, then simply add '-ascii_zero 64' to the commandline.\nElse if your read is Sanger-scored and you want to convert its scoring to Illumina, add s2i to the -methods specification.";
	}
	
	$$num_bases_trimmed_by_qseqB_ref += &qseqB($read, $B_num_cutoff, $detection_mode, $action);
	
	if (!($read->is_good)){ 
		$$num_reads_trimmed_by_qseqB_ref++;
	}
	return;
}

sub PE_qseqB{
	my ($PE_pair, $B_num_cutoff, $detection_mode, $action,
	   $num_bases_trimmed_by_qseqB_ref, $num_reads_trimmed_by_qseqB_ref, $num_pairs_trimmed_by_qseqB_ref) = @_;

	my ($read1, $read2) = ($PE_pair->read1, $PE_pair->read2);
	if ($read1->get_ascii_zero != 64) {
		die "ERROR at PE_qseqB: qseqB requires Illumina scoring (ascii_zero = 64). This read's ascii_of_zero_qual_score is ".$read1->get_ascii_zero.".\n".$read1->return_fQ_string."\n\nIf you are indeed using Illumina-scored Qseq reads, then simply add '-ascii_zero 64' to the commandline.\nElse if your read is Sanger-scored and you want to convert its scoring to Illumina, add s2i to the -methods specification.\n\n";
	}
	
	$$num_bases_trimmed_by_qseqB_ref += &qseqB($read1, $B_num_cutoff, $detection_mode, $action);
	$$num_bases_trimmed_by_qseqB_ref += &qseqB($read2, $B_num_cutoff, $detection_mode, $action);	
	
	if (!($read1->is_good)){ 
		$$num_reads_trimmed_by_qseqB_ref++;
	}
	if (!($read2->is_good)){ 
		$$num_reads_trimmed_by_qseqB_ref++;
	}
	if ( !($read1->is_good) || !($read2->is_good) ) { 
		$$num_pairs_trimmed_by_qseqB_ref++;
	}
	return;
}