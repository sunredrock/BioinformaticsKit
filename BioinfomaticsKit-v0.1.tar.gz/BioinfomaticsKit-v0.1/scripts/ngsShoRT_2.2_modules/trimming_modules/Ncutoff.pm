package Ncutoff;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(SE_Ncutoff PE_Ncutoff);

use strict;
use single_fQ_read 1.0;
use PE_fQ_pair 1.0;
use fQ_array 1.0;


=head1 NAME

 Ncutoff: a module for trimming fastq reads (ONE single_fQ_read object, or two
 single_fQ_read objects within one PE_fQ_pair object) based on the number of
 'N' (uncalled) bases in their sequence line. 
   
=head1 SUBROUTINES

=head2 Ncutoff
 
  Takes a single_fQ_read and n_cutoff, a cutoff number of 'N' bases. The read's
  _skip flag is set to 1 (telling process_single_read to discard  the read) if 
  the percentage of N bases is >= n_cutoff.

=head2 SE_Ncutoff

 Wrapper subroutine that calls Ncutoff on the read from the SE file.
 
=head2 PE_Ncutoff

 Wrapper subroutine that calls Ncutoff on each of the two reads in the PE_fQ_pair
 passed from the PE files.

=cut 



sub Ncutoff{
	# If the number of N/dot bases in a read is >= n_cutoff, set the read's
	# skip flag to 1
	my ($fq_read, $n_cutoff) = @_;
	my $seq_ref = $fq_read->get_seq_ref();
	
	if (!$$seq_ref){
		print "WARNING (Ncutoff): this read's sequence line is empty:\n".$fq_read->return_fQ_string."\n";
		$fq_read->skip();
		return;
	}
	
	my @dotN_matches = ($$seq_ref =~ /[.Nn]/g);
	if (@dotN_matches) {
		if ((scalar(@dotN_matches)) >= $n_cutoff){
			$fq_read->skip();
		}
	}
}

sub SE_Ncutoff{
	my ($read, $N_cutoff, 
	   $num_bases_trimmed_by_Ncuotff_ref, $num_reads_trimmed_by_Ncuotff_ref) = @_;
	
	&Ncutoff($read, $N_cutoff);
	
	if (!($read->is_good)){ 
		$$num_reads_trimmed_by_Ncuotff_ref++;
		$$num_bases_trimmed_by_Ncuotff_ref += ($read->get_length());
	}
	return;
}


sub PE_Ncutoff{
	my ($PE_pair, $N_cutoff, 
	   $num_bases_trimmed_by_Ncuotff_ref, $num_reads_trimmed_by_Ncuotff_ref, $num_pairs_trimmed_by_Ncuotff_ref) = @_;

	my ($read1, $read2) = ($PE_pair->read1, $PE_pair->read2);
	
	&Ncutoff($read1, $N_cutoff);
	&Ncutoff($read2, $N_cutoff);	
	
	if (!($read1->is_good)){ 
		$$num_reads_trimmed_by_Ncuotff_ref++;
		$$num_bases_trimmed_by_Ncuotff_ref += ($read1->get_length());
	}
	if (!($read2->is_good)){ 
		$$num_reads_trimmed_by_Ncuotff_ref++;
		$$num_bases_trimmed_by_Ncuotff_ref += ($read2->get_length());
	}
	if ( !($read1->is_good) || !($read2->is_good) ) { 
		$$num_pairs_trimmed_by_Ncuotff_ref++;
	}
	return;
}