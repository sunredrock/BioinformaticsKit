package ThreeEnd;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(SE_ThreeEnd ThreeEnd PE_ThreeEnd);

use strict;
use warnings;
use single_fQ_read 1.0;
use PE_fQ_pair 1.0;
use warnings;


=head1 NAME

 ThreeEnd: a module for trimming fastq reads (ONE single_fQ_read object, or two
 single_fQ_read objects within one PE_fQ_pair object) by removal of N 3' bases. 
 
=head1 SUBROUTINES

=head2 ThreeEnd

 Trims N 3' bases from the read's seq and quality line by using substr.

=head2 SE_ThreeEnd

 Wrapper subroutine that calls ThreeEnd on the read from the SE file.
 
=head2 PE_ThreeEnd

 Wrapper subroutine that calls ThreeEnd on each of the two reads in the PE_fQ_pair
 passed from the PE files.

=cut 


sub ThreeEnd{
# Trim n bases from the 3'-end
  
  my ($fq_read, $n, $min_read_length) = @_;
  return 0 if ($fq_read->get_length <= $min_read_length);

  my ($seq_ref, $qual_ref) = ($fq_read->get_seq_ref, $fq_read->get_qual_ref);
  my $num_of_trimmed_bases = 0;
  
  # Extract the read's piece that can be trimmed. That is, the part of the read
  # after min_read_length
    my $seq_part_to_be_trimmed  = substr $$seq_ref, $min_read_length;
    my $qual_part_to_be_trimmed = substr $$qual_ref, $min_read_length;
    
    if ($seq_part_to_be_trimmed){
      $num_of_trimmed_bases = $n;
      if ($num_of_trimmed_bases > (length $seq_part_to_be_trimmed)){
        $num_of_trimmed_bases = (length $seq_part_to_be_trimmed)
      };
      
      my $ThreeEnd_trim_index = (length $seq_part_to_be_trimmed) - $num_of_trimmed_bases;
      
      $seq_part_to_be_trimmed  = substr $seq_part_to_be_trimmed , 0,  $ThreeEnd_trim_index;
      $qual_part_to_be_trimmed = substr $qual_part_to_be_trimmed, 0,  $ThreeEnd_trim_index;
    }
  
  # Update seq and qual 
    $$seq_ref  = (substr $$seq_ref, 0,$min_read_length).$seq_part_to_be_trimmed;
    $$qual_ref = (substr $$qual_ref, 0,$min_read_length).$qual_part_to_be_trimmed;
    
  # Return the length of the trimmed segment
    return $num_of_trimmed_bases;
}

sub SE_ThreeEnd{
	my ($read, $n, $min_read_length,
	   $num_bases_trimmed_by_ThreeEnd_ref, $num_reads_trimmed_by_ThreeEnd_ref) = @_;
	
	$$num_bases_trimmed_by_ThreeEnd_ref += &ThreeEnd($read, $n, $min_read_length);
	
	if (!($read->is_good)){
		$$num_reads_trimmed_by_ThreeEnd_ref++;
	}
	return;
}


sub PE_ThreeEnd{
	my ($PE_pair, $n, $min_read_length,
	   $num_bases_trimmed_by_ThreeEnd_ref, $num_reads_trimmed_by_ThreeEnd_ref, $num_pairs_trimmed_by_ThreeEnd_ref) = @_;

	my ($read1, $read2) = ($PE_pair->read1, $PE_pair->read2);
	
  # 01 Trim reads 1 and 2 using ThreeEnd, and get the number of trimmed bases
    $$num_bases_trimmed_by_ThreeEnd_ref += &ThreeEnd($read1, $n, $min_read_length);
    $$num_bases_trimmed_by_ThreeEnd_ref += &ThreeEnd($read2, $n, $min_read_length);
	
  # 02 Update the number of trimmed reads and read pairs by checking the pair's status
    my $pe_pair_status = $PE_pair-> get_status();
    # 3 means both reads are good. This means no reads were trimmed 
    # 2 means only 2 is good, 1 means only 1 is good
    # 0 means neither 
    if ($pe_pair_status == 0) {
      $$num_reads_trimmed_by_ThreeEnd_ref += 2;
      $$num_pairs_trimmed_by_ThreeEnd_ref += 1;
      $$num_bases_trimmed_by_ThreeEnd_ref += ($PE_pair->read1->get_length()) + ($PE_pair->read2->get_length());
    }
	 # If only one read is bad, increment trimmed read counters
	    elsif ($pe_pair_status == 1) {
	      $$num_reads_trimmed_by_ThreeEnd_ref += 1;
	      $$num_pairs_trimmed_by_ThreeEnd_ref += 1;
	      $$num_bases_trimmed_by_ThreeEnd_ref += ($PE_pair->read2->get_length());
	    }
	    elsif ($pe_pair_status == 2) {
	      $$num_reads_trimmed_by_ThreeEnd_ref += 1;
	      $$num_pairs_trimmed_by_ThreeEnd_ref += 1;
	      $$num_bases_trimmed_by_ThreeEnd_ref += ($PE_pair->read1->get_length());
	    }
  
  return;
}