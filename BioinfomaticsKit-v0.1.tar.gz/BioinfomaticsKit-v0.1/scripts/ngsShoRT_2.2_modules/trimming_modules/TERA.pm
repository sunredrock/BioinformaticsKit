package TERA;
require Exporter;

our $VERSION =  1.0;
our @ISA = 	qw(Exporter);
our @EXPORT =   qw(SE_TERA TERA PE_TERA);

use strict;
use warnings;
use single_fQ_read 1.0;
use PE_fQ_pair 1.0;


=head1 NAME

 TERA: a module for trimming fastq reads (ONE single_fQ_read object, or two
 single_fQ_read objects within one PE_fQ_pair object) by removal of 3' bases based
 on their average quality score. 
 
=head1 SUBROUTINES

=head2 TERA

 Trim 3'-end bases from a read bases on their average quality score. Essentially it
 trims out the substring of bases (starting from the 3'-end) whose average quality score
 is under avg_cutoff. However, it cannot trim a read to a length shorter than min_rl.
 
 The algorithm, with examples, is explained in advanced_manual.pdf, section II.1

=head2 SE_TERA

 Wrapper subroutine that calls TERA on the read from the SE file.
 
=head2 PE_TERA

 Wrapper subroutine that calls TERA on each of the two reads in the PE_fQ_pair.
 passed from the PE files.

=cut 



sub TERA{ # (Trim) Three End Running Average
# Trim bases from the 3' end based on their avg qual score. If it's below a specified cutoff, remove the bases.
# The trimming can continue as far as base #1 in the read, in which case the entire read is trimmed off. OR we can specify a min_read_size at which trimming stops.
    my ($fq_read, $avg_cutoff, $min_read_length) = @_;
    return 0 if ($fq_read->get_length <= $min_read_length);

    my ($seq_ref,$qual_ref,$ASCII_of_zero_qual_score) = ($fq_read -> get_seq_ref(), $fq_read -> get_qual_ref(), $fq_read->get_ascii_zero);

    #counters, totals
    my $total_qual_score = 0;
    my $avg_qual_score;
    my $trimmed_TERA_bases_c= 0; 
    my $trimmed_segment_length =0;

    #Create the actual segments to be trimmed. These are the segments starting from the base whose index = min_read_size
    # and end at the last base in the read. So, if min_read_size = zero, we're allowed to apply trimming to the entire read.
    my $trimmed_seq_segment  = substr $$seq_ref , $min_read_length;
    my $trimmed_qual_segment = substr $$qual_ref, $min_read_length; #This PERL code extracts all bases from min_read_size to the end of the read.
																  
                                          
    # Split the segments to be trimmed to a character array                         
    my @qual_array = split (//, $trimmed_qual_segment);
    $trimmed_segment_length = @qual_array;

    my $done = 0;
    my $current_base_count_from_TERA = 0;
    # For i = Loop thru all characters in qual_array 
    for (my $i= $#qual_array; (($i >=0) && (!$done)); $i--){
        my $qual_score_of_current_base = ((ord ($qual_array[$i])) - $ASCII_of_zero_qual_score);
        $total_qual_score += $qual_score_of_current_base;
        
        $current_base_count_from_TERA++;
        $avg_qual_score = ($total_qual_score / $current_base_count_from_TERA);
        if ($avg_qual_score > $avg_cutoff){#if the avg_qual_score of the bases read so far is more than the average_cutoff, we are
                           # done. Note that when this is detected, $trimmed_TERA_bases_c is less than j by 1, and so
                           # we do not trim out the good base that tipped off $avg_qual_score)
            $done= 1;
        }
        else {
            $trimmed_TERA_bases_c++;
        }
    }#end for
		
		# The final result is the concatenation of :
		# [the part of the read from base #0 to min_read_size] and [the result of trimming of the part from min_read_size to the end of the read]
      $$seq_ref = "".(substr $$seq_ref , 0, $min_read_length). (substr $trimmed_seq_segment , 0, ($trimmed_segment_length - $trimmed_TERA_bases_c));
  		$$qual_ref= "".(substr $$qual_ref, 0, $min_read_length). (substr $trimmed_qual_segment, 0, ($trimmed_segment_length - $trimmed_TERA_bases_c));

    return $trimmed_TERA_bases_c;

}#end sub trim_TERA_bases


sub SE_TERA{
	my ($read, $avg_cutoff, $min_read_length, $num_TERA_trimmed_bases_ref,
	 $num_TERA_trimmed_reads_ref) = @_;

  # 01 Trim read using TERA, and get the number of trimmed bases
    $$num_TERA_trimmed_bases_ref += &TERA($read, $avg_cutoff, $min_read_length);

  # 02 Update the number of trimmed reads 
  if (!($read->is_good)){
		$$num_TERA_trimmed_reads_ref++;
		$read->skip;
	}
  return;
}

sub PE_TERA{
	my ($PE_fq_pair, $avg_cutoff, $min_read_length, $num_TERA_trimmed_bases_ref,
	 $num_TERA_trimmed_reads_ref, $num_TERA_trimmed_pairs_ref) = @_;

  my $read1 = $PE_fq_pair->read1(); my $read2 = $PE_fq_pair->read2();
	
  # 01 Trim reads 1 and 2 using TERA, and get the number of trimmed bases
    $$num_TERA_trimmed_bases_ref += &TERA($read1, $avg_cutoff, $min_read_length);
    $$num_TERA_trimmed_bases_ref += &TERA($read2, $avg_cutoff, $min_read_length);
	
  
	
  # 02 Update the number of trimmed reads and read pairs by checking the pair's status
    my $pe_pair_status = $PE_fq_pair-> get_status();
    # 3 means both reads are good. This means no reads were trimmed 
    # 2 means only 2 is good, 1 means only 1 is good
    # 0 means neither 
	if ($pe_pair_status == 0) {
		$$num_TERA_trimmed_reads_ref += 2;
		$$num_TERA_trimmed_pairs_ref += 1;
		$$num_TERA_trimmed_bases_ref += ($PE_fq_pair->read1->get_length()) + ($PE_fq_pair->read2->get_length());
		$PE_fq_pair->read1->skip;
		$PE_fq_pair->read2->skip;
	}
	# If only one read is bad, increment trimmed read counters
	    elsif ($pe_pair_status == 1) {
	      $PE_fq_pair->read2->skip;
		  $$num_TERA_trimmed_reads_ref += 1;
	      $$num_TERA_trimmed_pairs_ref += 1;
	      $$num_TERA_trimmed_bases_ref += ($PE_fq_pair->read2->get_length());
	    }
	    elsif ($pe_pair_status == 2) {
	      $PE_fq_pair->read1->skip;
		  $$num_TERA_trimmed_reads_ref += 1;
	      $$num_TERA_trimmed_pairs_ref += 1;
	      $$num_TERA_trimmed_bases_ref += ($PE_fq_pair->read1->get_length());
	    }
  
  return;
}





	