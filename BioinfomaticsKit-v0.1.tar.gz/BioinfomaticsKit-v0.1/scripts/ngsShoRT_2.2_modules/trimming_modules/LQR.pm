package LQR;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(SE_LQR LQR PE_LQR);

use strict;
use warnings;
use single_fQ_read 1.0;
use PE_fQ_pair 1.0;
use fQ_array 1.0;



=head1 NAME

 LQR: a module for trimming fastq reads (ONE single_fQ_read object, or two
 single_fQ_read objects within one PE_fQ_pair object) based on the percentage of
 'low quality' bases in their sequence line. 
   
=head1 SUBROUTINES

=head2 LQR
 
  Takes a single_fQ_read, and two cutoff values:
      - LQS_cutoff : a low quality score cutoff for bases
      - QPerc_cutof: a cutoff percentage for low quality bases in a read
   
  The read's _skip flag is set to 1 (telling process_single_read to discard 
  the read) if the percentage of low quality bases (bases with quality score
  <= LQS_cutoff) is >= QPerc_cutoff.

=head2 SE_LQR

 Wrapper subroutine that calls LQR on the read from the SE file.
 
=head2 PE_LQR

 Wrapper subroutine that calls LQR on each of the two reads in the PE_fQ_pair
 passed from the PE files.

=cut 



sub LQR{
	my ($fq_read, $LQS_cutoff, $QPerc_cutoff) = @_;
	# LQS_cutoff is the low quality score cutoff
	# QPerc_cutoff is the percent of LQ bases (bases with qual score < LQ) cutoff
	# ASCII_of_zero_qual_score is the ASCII value of a zero quality score (64 for Illumina, 33 for Sanger)
	my $ASCII_of_zero_qual_score = $fq_read->get_ascii_zero;
	
	if (!($fq_read->is_good)){
		print "WARNING (LQR): this read's seq OR quality line is empty:\n".$fq_read->return_fQ_string."\n";
		$fq_read->skip;
	}
	my @qual_array = split (//,  $fq_read->get_qual()); #split the quality score line to its characters
	
	my $total_num_of_bases = @qual_array; 
	my $num_of_bases_below_LQS_cutoff = 0;
	
	foreach my $base(@qual_array){
		my $qual_score_of_current_base = ((ord ($base)) - $ASCII_of_zero_qual_score);
		if ($qual_score_of_current_base < $LQS_cutoff){
			$num_of_bases_below_LQS_cutoff++;
		}
	}
	# return 1 (good read) if the percentage of bases below LQ is less than $QPerc
	my $is_good_read = ( (($num_of_bases_below_LQS_cutoff/$total_num_of_bases)*100) < $QPerc_cutoff);
	
	# Set the read's _skip flag to 1 if it's bad 
	if (!$is_good_read) {$fq_read->skip();}
}

sub SE_LQR{
	# Find the percentage of bases whose qual score is < LQ
	# If a read is bad, set its _skip flag to 1
	# Changes a passed reference variable
	
	my ($read, $LQS_cutoff, $QPerc_cutoff,  
	$number_of_LQR_trimmed_bases_ref, $number_of_LQR_trimmed_reads_ref) = @_;                                        
	
	# LQR-trim read.  
		&LQR($read, $LQS_cutoff, $QPerc_cutoff);
	
	# 02 Update the number of trimmed reads and bases by checking the read
	if (!($read->is_good)){
		$$number_of_LQR_trimmed_reads_ref += 1;
		$$number_of_LQR_trimmed_bases_ref += ($read->get_length());;
	}

	return;
}# end sub SE_LQR

sub PE_LQR{
	# Find the percentage of bases whose qual score is < LQ
	# If a read is bad, set its _skip flag to 1
	# Changes a passed reference variable
	
	my ($PE_fq_pair, $LQS_cutoff, $QPerc_cutoff, 
	$number_of_LQR_trimmed_bases_ref, $number_of_LQR_trimmed_reads_ref, $number_of_LQR_trimmed_pairs_ref) = @_;                                        
	
	# LQR-trim reads.  
		&LQR($PE_fq_pair->read1, $LQS_cutoff, $QPerc_cutoff);
		&LQR($PE_fq_pair->read2, $LQS_cutoff, $QPerc_cutoff);
	
	
	# 02 Update the number of trimmed reads and read pairs by checking the pair's status
    my $pe_pair_status = $PE_fq_pair-> get_status();
		# 3 means both reads are good. This means no reads were trimmed 
    # 2 means only 2 is good, 1 means only 1 is good
    # 0 means neither 
		
	if ($pe_pair_status == 0) {
		$$number_of_LQR_trimmed_reads_ref += 2;
		$$number_of_LQR_trimmed_pairs_ref += 1;
		$$number_of_LQR_trimmed_bases_ref += ($PE_fq_pair->read1->get_length()) + ($PE_fq_pair->read2->get_length());
	}
	elsif ($pe_pair_status == 1){
		$$number_of_LQR_trimmed_reads_ref += 1;
		$$number_of_LQR_trimmed_pairs_ref +=1;
		$$number_of_LQR_trimmed_bases_ref += ($PE_fq_pair->read2->get_length());
	}
	elsif ($pe_pair_status == 2){
		$$number_of_LQR_trimmed_reads_ref += 2;
		$$number_of_LQR_trimmed_pairs_ref +=1;
		$$number_of_LQR_trimmed_bases_ref += ($PE_fq_pair->read1->get_length());;
	}

	return;
}# end sub PE_LQR
