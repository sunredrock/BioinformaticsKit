package five_prime_adpt;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(SE_five_prime_adpt five_prime_adpt PE_five_prime_adpt);

use strict;
use warnings;

use single_fQ_read 1.0;
use PE_fQ_pair 1.0;
use fQ_array 1.0;

use String::Approx 'aslice';

=head1 NAME
 
 five_prime_adpt : a module for detection and trimming of 5' adapter sequences from
 single and paired-end read files. 

=head1 SYNOPSIS

=head2 five_prime_adpt
 
 The core method algorithm is five_prime_adpt, which takes an array (reference) of
 adapter sequences (plus 5' and 3' bases to delete if such a sequence is detected),a
 fastq read (as a single_fQ_read object), and parameters for fuzzy matching.
 
 The algorithm will try to fuzzy-match every adapter sequence in the array against
 the read.
  If a match is found and it's within the $furthest_allowed_index_for_adapter_match,
   - The algorithm removes the adapter sequence, deletes the specicified 5' and 3' bases,
   - Next, the algorithm has to trim the read by either killing it entirely, or removing
     only bases 3' to the detected adapter sequence. This depends on the value of adpt_action,
	 where kr = kill read, while ka = kill [bases] after the detecte adapter sequence.
   - If adpt_action = ka and the trimmed read's length is still >= than min_rl, the 
     read is printed out to the trimmed file handle. If not, the read is deleted (counters are
     updated, and single_fQ_read::skip is called to flag the read as bad). 
   - The detected adapter sequence, its coordinates on the target read, and the read's post-trimming
     version is printed out to the extracted_adapte_sequences filehandle.


=head2 SE_five_prime_adpt

 This is just a wrapper subroutine that simply calls five_prime_adpt on the SE read
 
=head2 PE_five_prime_adpt

 This is also a wrapper subroutine that takes a PE_fQ_pair, an array of adapter sequences and
 other vars. It calls five_prime_adpt on read1 and read2 in the PE_fQ_pair and updates the removed
 PE pair count if either/both reads are removed by five_prime_adpt.


=head1 I/O

=head2 Input vars for five_prime_adpt
 
 See the initialization "my (..) = @_ line for comments that explain each variable's function.
 
 SE_five_prime_adpt and PE_five_prime_adpt simply pass the vars to five_prime_adpt, and
 PE_five_prime_adpt will update removed_pair counts if either/both reads are trimmed to lengths under
 min_rl. 

=head2 Output of five_prime_adpt

 five_prime_adpt prints to two filehandles:
   - It prints trimmed reads to the trimmed_file handle
   - It prints matched sequences to the extracted_adapter_seqs filehandle

=cut


sub five_prime_adpt {
  # Takes a read, tries to match the adapter set against it
  # If any adapter_seq matches, it's extracted from the read along with other specifed base_nums
  # Then the read is either killed (kr), or
  #      the read is trimmed down to the beginning of the adapter sequence (ka)
  # If the read is killed by kr or is rendered too short by ka, it's skipped
  
	my ($read_num, $fq_read, $adapter_seqs_array_ref, 
		$match_percentage, $furthest_allowed_index_for_adapter_match, 
		$extracted_adapters_filehandle, $adpt_action, $min_read_length, 
		$num_adpt_trimmed_bases_ref, $num_adpt_trimmed_reads_ref,
		$num_detected_adapter_sequences_ref, $num_inss, $num_dels, $num_subs, $adpt_max_match_len_diff) = @_;
	
    
    # Checkpoint 1: Exit if there are no adapter sequences
    return if (!@$adapter_seqs_array_ref); 
    
		my ($seq_ref, $qual_ref) = ($fq_read->get_seq_ref, $fq_read->get_qual_ref);
    
	if (!$$seq_ref || !$$qual_ref){
		print "WARNING (five_prime_adpt): this read's seq OR quality line is empty:\n".$fq_read->return_fQ_string."\n";
		$fq_read->skip;
		return;
	}
			
	# PERL's aslice modul takes as input an amatch_mismatch_percentage, which is the percentage of mismatch
	my $amatch_mismatch_percentage = 100-$match_percentage;
	my $old_length = (length $$seq_ref);
	
	foreach my $adapter_seq_line (@$adapter_seqs_array_ref){
		my ($adapter_seq, $three_prime_bases_to_rm, $five_prime_bases_to_rm) = split /,/, $adapter_seq_line;
		# Find a string in the read's sequence line that matches the adapter_seq
		$_ = $$seq_ref;
		my ($index, $size); # index is the index of the first matched base
							# size is the size of the matched string
		
		# If match_perc = 100, use normal regex matching instead of aslice to save time
			if ($match_percentage == 100){
				# Regex-search for the adapter sequence
				my $match = /($adapter_seq)/gi;
				if ($match){
					my $pos = pos();
					$size = (length $adapter_seq);
					$index = $pos - $size;
				}
			}
		# Else If match_perc < 100, Approximate-search for the adapter sequence
			else{
				my $aslice_modifiers = "i $amatch_mismatch_percentage%";
				if ($num_inss) { $aslice_modifiers .= " I$num_inss";}
				if ($num_dels) { $aslice_modifiers .= " D$num_dels";}
				if ($num_subs) { $aslice_modifiers .= " S$num_subs";}
				
				($index, $size) = aslice($adapter_seq,["$aslice_modifiers"]);
			}
		
		
    # Checkpoint 2: Exit if nothing was detected or if the matched string wasn't ok
		next if (!((defined $index) && (defined $size)) || ((defined $index) && ($index == -1)));
    
	# At this point, we assume that we did get some match
		my $adpt_seq_len = (length $adapter_seq);
	
	# Checkpoint 3: make sure that the length (size) of the matched substring is not longer or shorter than the length
	# of the matched adapter sequence by more than $adpt_max_match_len_diff. This is important to avoid extreme
	# matches with aslice at adpt_mp < 100.
		my $matched_substring_len_is_ok =  (($size - $adpt_seq_len <= $adpt_max_match_len_diff) && ($adpt_seq_len - $size <= $adpt_max_match_len_diff));
		next if (!$matched_substring_len_is_ok);
		
	# Checkpoint 4: Exit If the matched string starts after $furthest_allowed_index_for_adapter_match,
		if ($furthest_allowed_index_for_adapter_match){
			#die "$furthest_allowed_index_for_adapter_match WTF?";
			next if ($index > $furthest_allowed_index_for_adapter_match);
		}
		  
    # After this point, we assume that (1) we detected a string and (2) it was ok and (3) it was within furthest_allowed_index
        
        # Increment the number of detected adapter sequences
				$$num_detected_adapter_sequences_ref++;
    
      # After this point, we assume that Action = ka, kill bases AFTER the detected adapter sequence
      
				# Extract the matched sequence
				my $matched_seq = substr($$seq_ref, $index, $size);

				# 01 remove bases before and after the matched sequence based on five_prime_bases_to_rm and three_prime_bases_to_rm
					my $new_index = $index - $five_prime_bases_to_rm ; if ($new_index < 0) {$new_index = 0;}	
					my $new_size  = $size  + $three_prime_bases_to_rm; if ($new_size  > $old_length) {$new_size = $old_length;}
          
					my $removed_sequence;
					if ($adpt_action eq "kr") {$removed_sequence = $$seq_ref;}
					else {$removed_sequence = substr $$seq_ref, $new_index;}
          
          
        # 02 print the extracted sequence data to the extracted_adapter_sequences file
          my $read_index = $fq_read->get_header;
		  
		  # Remove the header's |Trimmed_by.. attachement
			$read_index =~ s/(\|Trimmed_by\w+)$//;
		  
		  print $extracted_adapters_filehandle "> >\n";
          print $extracted_adapters_filehandle "$read_num $read_index $$seq_ref $adapter_seq --> $matched_seq:\t$index\t$size,\t$removed_sequence\n";
		  print $extracted_adapters_filehandle "< <\n";
		  
		  #print "$read_num $read_index $$seq_ref $adapter_seq --> $matched_seq:\t$index\t$size,\tdeleted $removed_sequence\n";
		  
        # 03 If action = kr, kill the whole read
		if ($adpt_action eq "kr"){
			$fq_read -> skip(); 
			$$num_adpt_trimmed_bases_ref += $old_length;
			$$num_adpt_trimmed_reads_ref++;
			return;
		}
        
        # Note that after this point we assume adpt_action is ka
		# 04 update seq and qual and the fq_read
          $$seq_ref  = substr $$seq_ref , 0, $new_index; 
          $$qual_ref = substr $$qual_ref, 0, $new_index;  
           
        # 05 if the read is bad, change the trimmed_base count to the whole sequence length
        #                        increment adpt-trimmed read count,
        #                        and skip the read
		if (!$fq_read->is_good) {
			$$num_adpt_trimmed_bases_ref += $old_length;
			$$num_adpt_trimmed_reads_ref++;
            $fq_read->skip;
		}
		else {
			$$num_adpt_trimmed_bases_ref += (length $removed_sequence);
		}
        
			return;
	}# end foreach
	
	print $extracted_adapters_filehandle "> >\n< <\n";
}# end sub five_prime_adpt

sub SE_five_prime_adpt{
  my ($read, $adapter_seqs_array_R_ref, 
		$match_percentage, $furthest_allowed_index_for_adapter_match, 
		$extracted_adapters_filehandle, $adpt_action, $min_read_length, 
		$num_adpt_trimmed_bases_ref, $num_adpt_trimmed_reads_ref,
		$num_detected_adapter_sequences_ref, $num_inss, $num_dels, $num_subs, $adpt_max_match_len_diff) = @_;
  
  
  five_prime_adpt("read", $read, $adapter_seqs_array_R_ref,
                  $match_percentage, $furthest_allowed_index_for_adapter_match, 
                  $extracted_adapters_filehandle, $adpt_action, $min_read_length, 
                  $num_adpt_trimmed_bases_ref, $num_adpt_trimmed_reads_ref,
                  $num_detected_adapter_sequences_ref, $num_inss, $num_dels, $num_subs, $adpt_max_match_len_diff);
  return;
}

sub PE_five_prime_adpt{
  my ($PE_pair, $adapter_seqs_array_R1_ref, $adapter_seqs_array_R2_ref, 
		$match_percentage, $furthest_allowed_index_for_adapter_match, 
		$extracted_adapters_filehandle, $adpt_action, $min_read_length, 
		$num_adpt_trimmed_bases_ref, $num_adpt_trimmed_reads_ref,$num_adpt_trimmed_pairs_ref,
		$num_detected_adapter_sequences_ref, $num_inss, $num_dels, $num_subs, $adpt_max_match_len_diff) = @_;
  
  my ($read1, $read2) = ($PE_pair->read1, $PE_pair->read2);
  
  five_prime_adpt("read1", $read1, $adapter_seqs_array_R1_ref,
                  $match_percentage, $furthest_allowed_index_for_adapter_match, 
                  $extracted_adapters_filehandle, $adpt_action, $min_read_length, 
                  $num_adpt_trimmed_bases_ref, $num_adpt_trimmed_reads_ref,
                  $num_detected_adapter_sequences_ref, $num_inss, $num_dels, $num_subs, $adpt_max_match_len_diff);
  
  five_prime_adpt("read2", $read2, $adapter_seqs_array_R2_ref,
                  $match_percentage, $furthest_allowed_index_for_adapter_match, 
                  $extracted_adapters_filehandle, $adpt_action, $min_read_length, 
                  $num_adpt_trimmed_bases_ref, $num_adpt_trimmed_reads_ref,
                  $num_detected_adapter_sequences_ref, $num_inss, $num_dels, $num_subs, $adpt_max_match_len_diff);
  
  if (!($read1->is_good) || !($read2->is_good)){
    $$num_adpt_trimmed_pairs_ref++;
  }
}