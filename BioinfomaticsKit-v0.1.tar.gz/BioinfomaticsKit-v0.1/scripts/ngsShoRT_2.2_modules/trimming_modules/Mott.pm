package Mott;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(SE_Mott Mott PE_Mott);

use warnings;
use strict;

use single_fQ_read 1.0;
use PE_fQ_pair 1.0;



=head1 NAME

 Mott: a module for trimming fastq reads (ONE single_fQ_read object, or two
 single_fQ_read objects within one PE_fQ_pair object) using the Richard Mott
 trimming algorithm of CLCBio, but with the modification of limiting trimming
 to min_read_length.
 
=head1 SUBROUTINES

=head2 Mott & Mott_to_min_read_length
 
 The algorithm, with examples, is explained in advanced_manual.pdf, section II.6.
 
 The goal is to extract, from the raw read, a high quality window of bases. The 
 quality cutoff, Q_cutoff, is specified by mott_limit, a cutoff value used as 
 follows:
 
 LmP = mott_limit - Perror[base], 
   where Perror[base] = 10 ^(-Q/10), where Q = quality score
 
 So, when LmP = 0, mott_limit = 10^(-Q/10)= 1.
 Q_cuotff = 2 => mott_limit = 0.631 (Default value) 
 Q_cutoff = 4 => mott_limit = 0.398

 The extracted quality window starts from the first 3' base at which the running
 sum of LmP values exceeded zero to the 5' base with the highest value for the 
 running sum. 
 
 The modification that I introduced was limiting trimming to minimum_read_length 
 in order to avoid the case of reads being trimmed to lengths shorter than the K-mer
 size used by De Bruijn Graph assemblers (minimum_read_length must be higher than 
 the highest K value). This modification is implemented by Mott_to_min_read_length.

=head2 SE_Mott

 Wrapper subroutine that calls Mott on the read from the  file.
 
=head2 PE_Mott

 Wrapper subroutine that calls Mott on each of the two reads in the PE_fQ_pair.
 passed from the PE files.

=cut 


		
sub Mott {
	my ($fq_read, $mott_limit, $min_read_length) = @_;
	return 0 if ($fq_read->get_length <= $min_read_length);
	
	my ($seq_ref,$qual_ref,$ASCII_of_zero_qual_score) = ($fq_read -> get_seq_ref(), $fq_read -> get_qual_ref(), $fq_read->get_ascii_zero);
	
		if (!$$seq_ref || !$$qual_ref){
		print "WARNING (Mott): this read's seq OR quality line is empty:\n".$fq_read->return_fQ_string."\n";
		$fq_read->skip;
		return 0;
	}
		
	my $mott_trimmed_bases = &Mott_to_min_read_length($seq_ref, $qual_ref, $mott_limit, $ASCII_of_zero_qual_score, $min_read_length);
	
	return $mott_trimmed_bases;
}


sub SE_Mott {
	my ($read, $mott_limit, $min_read_length, 
	    $num_mott_trimmed_bases_ref, $num_mott_trimmed_reads_ref) = @_;
	
	# 01 Trim read using Mott, and get the number of trimmed bases
	$$num_mott_trimmed_bases_ref += &Mott($read, $mott_limit, $min_read_length);
	
	if (!($read->is_good)){
		$$num_mott_trimmed_reads_ref++;
		$read->skip;
	}
	return;
}

sub PE_Mott {
	my ($PE_fq_pair, $mott_limit, $min_read_length, 
	    $num_mott_trimmed_bases_ref, $num_mott_trimmed_reads_ref, $num_mott_trimmed_pairs_ref) = @_;
	
	# 01 Trim reads 1 and 2 using Mott, and get the number of trimmed bases
	$$num_mott_trimmed_bases_ref += &Mott($PE_fq_pair->read1, $mott_limit, $min_read_length);
	$$num_mott_trimmed_bases_ref += &Mott($PE_fq_pair->read2, $mott_limit, $min_read_length);
	
	# 02 Update the number of trimmed reads and read pairs by checking the pair's status
    my $pe_pair_status = $PE_fq_pair-> get_status();
    # 3 means both reads are good. This means no reads were trimmed 
    # 2 means only 2 is good, 1 means only 1 is good
    # 0 means neither 
	if ($pe_pair_status == 0) {
		$$num_mott_trimmed_reads_ref += 2;
		$$num_mott_trimmed_pairs_ref += 1;
		$$num_mott_trimmed_bases_ref += ($PE_fq_pair->read1->get_length()) + ($PE_fq_pair->read2->get_length());
		$PE_fq_pair->read1->skip;
		$PE_fq_pair->read2->skip;
		
		return;
	}
	# If only one read is bad, increment trimmed read counters
	elsif ($pe_pair_status == 1) {
			$$num_mott_trimmed_reads_ref += 1;
			$$num_mott_trimmed_pairs_ref += 1;
			
			# Kill read #2 and add its bases to the trimmed count
			$PE_fq_pair->read2->skip;
			$$num_mott_trimmed_bases_ref += ($PE_fq_pair->read2->get_length());
			
			return;
	}
	elsif ($pe_pair_status == 2) {
			$$num_mott_trimmed_reads_ref += 1;
			$$num_mott_trimmed_pairs_ref += 1;
			
			# Kill read #1 and add its bases to the trimmed count
			$PE_fq_pair->read1->skip;
			$$num_mott_trimmed_bases_ref += ($PE_fq_pair->read1->get_length());
			
			return;
	}
	return;
}	



sub Mott_to_min_read_length { 
	my ($seq_ref,$qual_ref, $mott_limit, $ASCII_of_zero_qual_score, $min_read_length) = @_;
	
	#die "$seq_ref,$qual_ref, $mott_limit, $ASCII_of_zero_qual_score, $min_read_length";
	
	my $running_sum_of_LmP_values = 0;
	my $length_before_trimming = length ($$qual_ref);
	
	return 0 if ($length_before_trimming <= $min_read_length);
	
	my @qual_array = split //, $$qual_ref;

	my $base_index_of_1st_nonzero_sumLmP_base = -999;
	my $current_max_running_sum_LmP =0;
	my $index_of_base_with_current_max_running_sum_LmP =0;
	
	# A. Go thru bases (starting at the 3' end) and examine their LmP values and update
	#    the current_running_sum_LmP and its index.
		for (my $i = $#qual_array; $i>= 0; $i--){
			my $base = $qual_array[$i];
			my $qual_score_of_current_base = ((ord ($base)) - $ASCII_of_zero_qual_score);
			my $P_error_of_current_base = 10 ** (-1*$qual_score_of_current_base/10);
			
			# 1. Add the base's LmP value to a running sum.
			#    If the sum drops below zero, set it to zero,
			#    LmP(base) = mott_limit - P_error of the base
				my $LmP_of_current_base = $mott_limit - $P_error_of_current_base;
				
				$running_sum_of_LmP_values += $LmP_of_current_base;
				if ($running_sum_of_LmP_values < 0) {$running_sum_of_LmP_values = 0 };
				
			# 2. if this running_sumLmP is >0, 
				if ($running_sum_of_LmP_values > 0) {
					# - if it's the first positive running sum ever, save it
						if ($base_index_of_1st_nonzero_sumLmP_base == -999){
							$base_index_of_1st_nonzero_sumLmP_base = $i;
						}
					
					# - Compare it against the current max running sum. If it's >= the current
					#   sum, update the values of the max current sum AND, MORE IMPORTANTLY, the
					#   index of the highest current running sum location.
						if ($running_sum_of_LmP_values >= $current_max_running_sum_LmP){
								$current_max_running_sum_LmP = $running_sum_of_LmP_values;
								$index_of_base_with_current_max_running_sum_LmP = $i;
						}
				}#end if >0
					
				
			# 3. ElseIf this running_sumLmP is 0, see if we've reached min_rl. If we have, stop here and
			#    return the substring from base #0 to base #min_read_length,removing only
			#    ($length_before_trimming - min_read_length) bases
				elsif (($running_sum_of_LmP_values == 0) && ( ($i+1) <= $min_read_length)) {
						$$seq_ref  = substr $$seq_ref  , 0, $min_read_length; 
						$$qual_ref = substr $$qual_ref , 0, $min_read_length; 
						
						# return the number of trimmed bases
							return ($length_before_trimming - $min_read_length);
				}
		}#end for i
		
	
	# B. If we're here, this means a positive running_sum_LmP was found at a base that's to the
	#    right of min_rl.
	#    However, this doesn't necessarily mean that there's >= min_rl bases between the base with
	#    the first positive running sum and the base with the highest running sum.
	
	# So, we have to first check if the distance between these two bases.
		my $distance_btwn_1st_posv_n_highest_rnnng_sum_LmP = $base_index_of_1st_nonzero_sumLmP_base -
															$index_of_base_with_current_max_running_sum_LmP + 1; 
		# If it is indeed >= min_rl, we're good. Trim and return results.
			if ($distance_btwn_1st_posv_n_highest_rnnng_sum_LmP >= $min_read_length){
				# Trim the read
					$$seq_ref  = substr $$seq_ref  , $index_of_base_with_current_max_running_sum_LmP, $distance_btwn_1st_posv_n_highest_rnnng_sum_LmP; 
					$$qual_ref = substr $$qual_ref  , $index_of_base_with_current_max_running_sum_LmP, $distance_btwn_1st_posv_n_highest_rnnng_sum_LmP;
				# return the number of trimmed bases
					return ($length_before_trimming - length($$seq_ref));
			}
		
		# Else, try to salvage the best part of the read. What we know is that:
		#  - All bases to the right of $index_of_base_with_current_max_running_sum_LmP have 0 running_sumLmPs,
		#  - bases to the left of $index_of_base_with_current_max_running_sum_LmP have smaller, probably positive sumLmP values.
		# So, we try to add the left bases first, then the right.
		#
			else{
				my $left_index = $index_of_base_with_current_max_running_sum_LmP;
				my $right_index = $distance_btwn_1st_posv_n_highest_rnnng_sum_LmP;
				
				while (($right_index-$left_index +1)< $min_read_length){
					# Try adding left bases, one by one.
						if ($left_index >0){
							$left_index--;
						}
						# If there are no left bases to add, use the right bases
						else{
							if ($right_index < $#qual_array){
								$right_index++;
							}
						}
					
						last if (($left_index == 0) && ($right_index == $#qual_array));
				}#end while
				
				# If this salvage procedure worked, return the bases between the new left and right indices
					if (($right_index-$left_index +1)>= $min_read_length){
						# Trim the read
						$$seq_ref  = substr $$seq_ref  , $left_index, $min_read_length; 
						$$qual_ref = substr $$qual_ref , $left_index, $min_read_length;
					# return the number of trimmed bases
						return ($length_before_trimming - $min_read_length);
					}
				
				# Else if it failed (impossible, but you never know), return the 0->min_rl part of the read
				else{
					$$seq_ref  = substr $$seq_ref  , 0, $min_read_length; 
					$$qual_ref = substr $$qual_ref , 0, $min_read_length; 
						
					# return the number of trimmed bases
						return ($length_before_trimming - $min_read_length);
				}
			}# end else try to salvage
	
}# end mott_to_min_read_length
