package rmHP;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(SE_rmHP rmHP PE_rmHP);

use strict;
use warnings;
use single_fQ_read 1.0;
use PE_fQ_pair 1.0;


=head1 NAME

 rmHP: a module for trimming homopolymer sequences out of (fastQ) reads. It simply searches
	   for a string of similar characters that has a minimum length of 8 (default) or a user-set
	   value. If such a string is found, all bases following it are removed as well. Since
	   we're dealing with fastQ reads, the trimmed bases' quality scores are removed as well
 
=head1 SUBROUTINES

=head2 rmHP

 Input:
 ------ 
   - The read (as a single_fQ_read object), 
   - min_length : minimum length of a homopolymer string to be removed
   - base_List: a reference to an array of bases that will be uses as seeds for the
                homopolymer. The default, set in MAIN, is \(A,G,C,T)

  
 Detection and Action:
 ---------------------   
  Detection is simply done using s/$base{$min_length,}.*//i, which removes
  

=head2 SE_rmHP

 Wrapper subroutine that calls rmHP() on the read from the SE file.
 
=head2 PE_rmHP

 Wrapper subroutine that calls rmHP() on each of the two reads in the PE_fQ_pair
 passed from the PE files.

=cut 



sub rmHP{
	# Check the sequence line for the presence of a homopolymer made of the bases listed
	# in base_list using s///i. If a match is detected, detected_flag = 1
	
	my ($fq_read, $min_length, $base_list_arr_ref) = @_;
	my $seq_ref  = $fq_read->get_seq_ref();
	my $qual_ref = $fq_read->get_qual_ref();
	my $num_trimmed_bases =0;
	my $original_read_length = $fq_read -> get_length();
	
	
	if (!$$qual_ref){
		print "WARNING (rmHP): this read's quality line is empty:\n".$fq_read->return_fQ_string."\n";
		return;
	}
	
	my $read_is_good = 1;
	
	foreach my $base (@$base_list_arr_ref){
		if ($$seq_ref =~ s/($base){$min_length,}.*//i){
			$num_trimmed_bases += length ($&);
			
			# Trim the quals down to the new read length
				$$qual_ref = substr $$qual_ref, 0, length ($$seq_ref);	
			
			# Check if the read is still good. If not, skip()
				if (! $fq_read ->is_good){
					$fq_read -> skip; $read_is_good = 0;
					$num_trimmed_bases = $original_read_length;
				}
		}
		last if !$read_is_good;
	}
	
	return $num_trimmed_bases;
}


sub SE_rmHP{
	my ($read, $min_length, $base_list_arr_ref,
	   $num_bases_trimmed_by_rmHP_ref, $num_reads_trimmed_by_rmHP_ref) = @_;
	
	$$num_bases_trimmed_by_rmHP_ref += &rmHP($read, $min_length, $base_list_arr_ref);
	
	if (!($read->is_good)){ 
		$$num_reads_trimmed_by_rmHP_ref++;
	}
	return;
}

sub PE_rmHP{
	my ($PE_pair, $min_length, $base_list_arr_ref,
	   $num_bases_trimmed_by_rmHP_ref, $num_reads_trimmed_by_rmHP_ref, $num_pairs_trimmed_by_rmHP_ref) = @_;

	my ($read1, $read2) = ($PE_pair->read1, $PE_pair->read2);
	
	$$num_bases_trimmed_by_rmHP_ref += &rmHP($read1, $min_length, $base_list_arr_ref);
	$$num_bases_trimmed_by_rmHP_ref += &rmHP($read2, $min_length, $base_list_arr_ref);	
	
	if (!($read1->is_good)){ 
		$$num_reads_trimmed_by_rmHP_ref++;
	}
	if (!($read2->is_good)){ 
		$$num_reads_trimmed_by_rmHP_ref++;
	}
	if ( !($read1->is_good) || !($read2->is_good) ) { 
		$$num_pairs_trimmed_by_rmHP_ref++;
	}
	return;
}