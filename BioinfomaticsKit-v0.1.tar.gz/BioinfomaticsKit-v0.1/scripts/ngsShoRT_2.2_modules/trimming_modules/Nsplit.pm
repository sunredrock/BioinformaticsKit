package Nsplit;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(SE_Nsplit Nsplit PE_Nsplit);

use strict;
use warnings;
use single_fQ_read 1.0;
use PE_fQ_pair 1.0;
use fQ_array 1.0;


=head1 NAME

 Nsplit: a module for trimming fastq reads (ONE single_fQ_read object, or two
 single_fQ_read objects within one PE_fQ_pair object) by searching for a string
 of N-bases whose length is >= num_n_cutoff, and if found, splitting the read
 into two new daughter reads.
 
=head1 SUBROUTINES

=head2 Nsplit

 Input:
 ------ 
   - The read (as a single_fQ_read object), 
   - num_n_cutoff
  
 Algorithm:
 ----------
   - The algorithm is fully explained in the advanced_manual.pdf, section II.4,
     and its programming implementation is explained in the documentation of 
     process_single_read.pm and process_PE_read_pair.pm (section II.2.d). 
   
   - The basic idea is this: if a string of Ns whose length is >= num_n_cutoff is
     found in a read, the read is split into two daughter reads (each created as a
     new single_fQ_read objects), which maybe both "good" (longer than min_rl). In
     this case, the reads are loaded into an fQ_array object that is returned by 
     the algorithm, and the remaining methods in the method sequence will be run
     on each of the daughter reads.
 
 Output:
 -------   
 - Nothing : if the read doesn't have a string of Ns, or if the read's daughter reads
             are both "bad".
 - An fQ_array object containing two daughter reads in the case of SE read processing
 - An fQ_array object containing a number of daughter pairs in the case of PE read 
   processing
  
=head2 SE_Nsplit

 Wrapper subroutine that calls Nsplit on the read from the SE file.
 
=head2 PE_Nsplit

 Wrapper subroutine that calls Nsplit on each of the two reads in the PE_fQ_pair
 passed from the PE files.

=cut 



sub Nsplit{
  # Takes a single_fQ_read and returns an fQ_array of fQ_read's. The fQ_array contains the same read OR, if the read is
	# split, it will contain the 1-2 new daughter reads 
	my ($fq_read, $num_n_cutoff, $min_read_length,
			$num_of_removed_bases_using_Nsplit_ref, $num_of_removed_N_blocks_ref, $num_of_Nsplit_removed_reads_ref) = @_;
	
	my ($seq_ref, $qual_ref) = ($fq_read->get_seq_ref, $fq_read->get_qual_ref);
	my ($length_of_matched_N_string,$seq_left_piece,$seq_right_piece, $qual_left_piece,$qual_right_piece, @result);

	if (!$$seq_ref || !$$qual_ref){
		print "WARNING (Nsplit): this read's seq OR quality line is empty:\n".$fq_read->return_fQ_string."\n";
		$fq_read->skip;
		push @result, $fq_read;
	}
	
	else {	# begin big else
		my @Nblocks = ($$seq_ref =~ /[.N]{$num_n_cutoff,}/g); # {$num_n_cutoff,}  means $num_n_cutoff and above
		
		# 01 Search for valid Nblocks
			#If any blocks are detected,
			if (@Nblocks){ 		
				#find the longest of the blocks
				my $longest_block = $Nblocks[0];
				
				foreach my $block (@Nblocks){
					if ((length $block) > (length $longest_block)){
						$longest_block = $block;
					}
				}	
				
			# Now, extract the pieces around the longest block
				if ($$seq_ref =~ $longest_block){
					# Extract the sequence line pieces
					$seq_left_piece = $`; $seq_right_piece = $'; $length_of_matched_N_string = length $&;
					
					# Create the corresponding qual pieces
						$qual_left_piece  = substr ($$qual_ref, 0 , (length $seq_left_piece)); 
						$qual_right_piece = substr ($$qual_ref, ((length $seq_left_piece) + $length_of_matched_N_string));
	
					# Increment the number of detected N blocks by 1
					$$num_of_removed_N_blocks_ref++;
				
					# Add the number of detected (and thus removed) N bases to the number of bases removed using Nsplit
					$$num_of_removed_bases_using_Nsplit_ref += $length_of_matched_N_string;
					
						# Create two new daughter reads (if necessary)
						my ($daughter_readL, $daughter_readR);
						
						my $left_piece_is_good  = ($seq_left_piece && ((length $seq_left_piece) >= $min_read_length));
						my $right_piece_is_good = ($seq_right_piece && ((length $seq_right_piece) >= $min_read_length));
							
						if ($left_piece_is_good){
							$daughter_readL = new single_fQ_read(
								_header  => $fq_read->get_header,
								_seq     => $seq_left_piece,
								_comment => $fq_read->get_comment,
								_qual    => $qual_left_piece,
								_min_rl  => $min_read_length,
								_qseq_filter => $fq_read->get_qseq_filter,
								_ascii_zero  => $fq_read->get_ascii_zero,
								_call_from => "Nsplit: daughter_readL creation");
							
							push @result, $daughter_readL;
						}
						else{$$num_of_removed_bases_using_Nsplit_ref += (length $seq_left_piece);}
						
						if ($right_piece_is_good){
							$daughter_readR = new single_fQ_read(
								_header  => $fq_read->get_header,
								_seq     => $seq_right_piece,
								_comment => $fq_read->get_comment,
								_qual    => $qual_right_piece,
								_min_rl  => $min_read_length,
								_qseq_filter => $fq_read->get_qseq_filter,
								_ascii_zero  => $fq_read->get_ascii_zero,
								_call_from => "Nsplit: daughter_readR creation");
							
							push @result, $daughter_readR;
						}
						else{$$num_of_removed_bases_using_Nsplit_ref += (length $seq_right_piece);}
						
						# If both pieces are bad, increment the number of removed reads and label their
						# parent with ->skip (discard)
						if (!$left_piece_is_good && !$right_piece_is_good){
							$$num_of_Nsplit_removed_reads_ref++;
							$fq_read->skip;
						}
				}
				
				else { # BUG: if the longest block (which was detected already), wasn't detected again
					die "BUG (Nsplit): longest N block was not re-detected in $$seq_ref !!\n";
				}
			}# end if (@Nblocks)
			
			elsif (!@Nblocks){ #If no valid blocks were detected
				# do nothing (leave @result empty)
			}
	}# end big else
	
	# 02 Create a new fQ_array from @result
	  my $fQ_array = new fQ_array(_arr_ref => \@result);
	
	# Return the new fQ_array which holds single_fQ_read object(s), if any
	return $fQ_array;
}

sub SE_Nsplit{
  # Takes a single_fQ read and returns an fQ_array of single_fQ_read's. The fQ_array contains the same read OR, if the read is
  # split, it will contain the 1-2 new daughter **reads** instead
	my ($read, $num_n_cutoff, $min_read_length,
			$num_of_removed_bases_using_Nsplit_ref, $num_of_removed_N_blocks_ref, $num_of_Nsplit_removed_reads_ref) = @_;
	
	# 01 Nsplit the read and get its corresponding read_split_set's
		# read_split_set is an fQ_array object that holds single_fQ_read object(s)
		my $read_split_set = &Nsplit($read, $num_n_cutoff, $min_read_length,
										$num_of_removed_bases_using_Nsplit_ref, $num_of_removed_N_blocks_ref, $num_of_Nsplit_removed_reads_ref);
	
  # 02 return this read split set's array reference
		return ($read_split_set->get_arr_ref);
}

sub PE_Nsplit{
  # Takes a PE_fQ_pair and returns an fQ_array of PE_fQ_pair's. The fQ_array contains the same pair OR, if the pair is
  # split, it will contain the 1-2 new daughter **pairs** instead
	my ($PE_pair, $num_n_cutoff, $min_read_length,
			$num_of_removed_bases_using_Nsplit_ref, $num_of_removed_N_blocks_ref, $num_of_Nsplit_removed_reads_ref,
			$num_of_Nsplit_removed_pairs_ref) = @_;
	
	my ($read1, $read2) = ($PE_pair->read1, $PE_pair->read2);
	
	# 01 Nsplit will try to split each read and return an fQ_array_object. We have the following cases: 
	#   A. If the read was not Nsplit (no Nblock was found), its fQ_array_object is empty
	#	B.If the read was Nsplit,
	#			B.1. If neither of its children are good (>= min_rl), it's skipped AND its fQ_array_object is empty
	#			B.2. If either/both children are good, they are put in fQ_array_object
		
		# $readN_split_set is the fQ_array_object mentioned above
		my $read1_split_set = &Nsplit($read1, $num_n_cutoff, $min_read_length,
									$num_of_removed_bases_using_Nsplit_ref, $num_of_removed_N_blocks_ref, $num_of_Nsplit_removed_reads_ref);
		my $read2_split_set = &Nsplit($read2, $num_n_cutoff, $min_read_length,
                              $num_of_removed_bases_using_Nsplit_ref, $num_of_removed_N_blocks_ref, $num_of_Nsplit_removed_reads_ref);
	
		#my $pushed_read = $read1_split_set -> pop(); my $pushed_read_seq = $pushed_read -> get_seq_ref; print "=>".$$pushed_read_seq."<=\n"; die;
		
	
  # 02 If either read in the pair were set to be skipped by Nsplit (case B.1., see above)
  #    their pair is no longer usable, and we increment the trimmed pairs count
  #    return (nothing), which tells process_PE_read_pair to take them to surv/discarded
		if (!($read1->is_good) || !($read2->is_good) ){
			$$num_of_Nsplit_removed_pairs_ref++;
			return ;
		}

  # 03 If both reads are still good, 	
	# 03.A If neither of them have a split set, return (nothing), which tells
	#      process_PE_pair to just keep going on with other trimming methods
		if (($read1_split_set->is_empty) && ($read2_split_set->is_empty)){
			return;
		}
	
	# 03.B if either/both reads were succeffuly split, we must shuffle the pieces.
	#      for a read that wasn't split, we add it to the shuffling.
	#      The result of shuffling is @result, an array of new PE_FQ_pair's
		my $read1_parts_ref = $read1_split_set->get_arr_ref; 
		my $read2_parts_ref = $read2_split_set->get_arr_ref;
		
		if (!@$read1_parts_ref) {push @$read1_parts_ref, $read1;}
		if (!@$read2_parts_ref) {push @$read2_parts_ref, $read2;}
	
		#print "read1 has parts\n" if (@$read1_parts_ref); print "read2 has parts\n" if (@$read2_parts_ref);
		#print "read1 has NO parts\n" if (!@$read1_parts_ref); print "read2 has NO parts\n" if (!@$read2_parts_ref);
		#die;
		
	
		my @result; #is an array of PE_fQ_pair objects
		
		foreach my $piece1 (@$read1_parts_ref){# a piece is ONE read
			foreach my $piece2 (@$read2_parts_ref){
				my $new_pe_pair = new PE_fQ_pair(_read1 => $piece1,_read2 => $piece2);
				push @result, $new_pe_pair;
			}
		}
		
		return \@result;
}
