package PE_fQ_pair;

use strict;
use warnings;
use Carp;

our $VERSION = "1.0";


=head1 NAME

PE_fQ_pair: object for a pair of (single_fQ_read)s with a set of attributes and methods

=head1 Synopsis 
 
 use single_fQ_read;
 use PE_fQ_pair;
 
 my $read1 = new single_fQ_read(
        _header => '@SRR065390.1 HWUSI-EAS687_61DAJ:8:1:1055:3384',
        _seq    => 'TGAANACCTCGAAACTTTTTCAGCGGNNTCNTTNNNN',
        _comment => '+',
        _qual =>   '0000!<:<;:@AAA=@:@@@A@AA@#!!##!##!!!!',
        _min_rl => '52'
        );

my $read2 = new single_fQ_read(
        _header => '@SRR065390.1 HWUSI-EAS687_61DAJ:8:1:1055:3384',
        _seq    => 'NNNNNNNNNNNNTGAATAAATACTTTTTGCAGATGCT',
        _comment => '+',
        _qual =>   '!!!!!!!!!!!!#########################',
        _min_rl => '52'
			     );
			     
my $PE_pair = PE_fQ_pair-> new(
                _read1 => $read1,
                _read2 => $read2
		);
	
$PE_pair->switch_qual_scores ($x2y) # where x2y is either s2i or i2s (s=sanger, i= illumina).
                                    # calls switch_qual_scores($x2y) for reads 1 and 2.
                                    
print $PE_pair->return_fQ_string,"\n"; # Prints read1 followed by read2, using their 
                                       # return_fQ_string methods


=head1 Methods

=head2 Pair Status

 print "Pair Status is : ", $PE_pair->get_status,"\n"; 
 # get_status returns 3 if both reads are good, i.e, each has (length >= min_read_length && _skip == 0)
 #                    2 if only read2 is good.  
 #                    1 if only read 1 is good
 #                    0 if neither are good
 # This flag is used by PE_ trimming methods to determine if the trimmed pair is intact (3) and can 
 # thus be printed out (each read is printed to its trimmed_.. file). If status = 2 | 1, the good
 # read is printed to surviving_SR_mates.fastq and the bad read is printed to bad_reads.fastq

=head2 Accessing Read1 and Read2 and their single_fQ_read methods

 # _read1 and _read2 and their methods (as single_fQ_read objects) are accessible 
 # from inside PE_pair using the read1 and read2 functions, which return the _read1 and _read2
 # attributes, which are the references to the read objects. For example:

 $PE_pair->read1->skip(); # sets the _skip value for read1
 $PE_pair->read1->get_length();
	
=head1 AUTHOR

 Sari Khaleel (skhaleel at udel.edu)
 Last modified on 1-24-2012

=cut


# Constructor
sub new {
    my ($class, %arg) = @_;
        
    my $self = bless {
        # Chomped Fastq read lines 
		_read1   => $arg{_read1}     || croak("Error: no read1"),
        _read2   => $arg{_read2}     || croak("Error: no read2"),  
    }, $class;

    return $self;
}# end sub new

sub read1{
    # Returns a pointer to the first read
    return $_[0] -> {_read1};
}

sub read2{
    # returns a pointer to the second read
    return $_[0] -> {_read2};
}

sub get_status{
    # Checks read1 and read2 to see if they're good (see is_good() at single_fQ_read)
    # Returns 3 if both reads are good
    #         2 if only 2 is good
    #         1 if only 1 is good
    #         0 if neither are good
    my $read1_is_good = $_[0]->read1->is_good;
    my $read2_is_good = $_[0]->read2->is_good;
    
    return 3 if ($read1_is_good && $read2_is_good);
    return 2 if ($read2_is_good);
    return 1 if ($read1_is_good);
    return 0;
}

sub return_fQ_string{
    return ($_[0]->read1->return_fQ_string."\n".$_[0]->read2->return_fQ_string);
}

sub switch_qual_scores{
	my ($class, $x2y) = @_;
	die "ERROR: no x2y was specified" if (!$x2y);
	$_[0]->read1->switch_qual_scores($x2y);
	$_[0]->read2->switch_qual_scores($x2y); 
}
sub DESTROY{
    my ($self) = @_;
}

1;