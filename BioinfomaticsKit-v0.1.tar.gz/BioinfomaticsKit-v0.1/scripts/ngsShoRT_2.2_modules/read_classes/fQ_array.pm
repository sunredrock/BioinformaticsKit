package fQ_array;

use strict;
use warnings;

our $VERSION = "1.0";

use single_fQ_read 1.0;
use PE_fQ_pair 1.0;

=head1 NAME

fQ_array : an array of single_fQ_read and/or PE_fQ_pair 's. However, it's recommended to have only
one type of item within the same fQ array.

Most regular perl array actions can be done on this object (see Methods)

=head1 Synopsis 

 use single_fQ_read;
 my $read1 = new single_fQ_read(
        _header => '@SRR065390.1 HWUSI-EAS687_61DAJ:8:1:1055:3384',
        _seq    => 'TGAANACCTCGAAACTTTTTCAGCGGNNTCNTTNNNN',
        _comment => '+',
        _qual =>   '0000!<:<;:@AAA=@:@@@A@AA@#!!##!##!!!!',
        _min_rl => '52'
        );

 my $read2 = new single_fQ_read(
        _header => '@SRR065390.1 HWUSI-EAS687_61DAJ:8:1:1055:3384',
        _seq    => 'NNNNNNNNNNNNTGAATAAATACTTTTTGCAGATGCT',
        _comment => '+',
        _qual =>   '!!!!!!!!!!!!#########################',
        _min_rl => '52'
			     );

 my @some_array_of_fq = ($read1, $read2);
 my $fQ_array = fQ_array->new(_arr_ref=> \@some_array_of_fq);

=head1 Methods 

 $fQ_array->pop                 # returns the last item and removes it from the array
 $fQ_array->push($item)         # where item is either a single_fQ_read OR a PE_fQ_pair
 $fQ_array->shift               # returns the first item and removes it from the array
 $fQ_array->unshift($item)      # where item is either a single_fQ_read OR a PE_fQ_pair
 $fQ_array->get_item($N),       # where N is the number of the item
 $fQ_array->set_item($N, $val)  # where val is either a single_fQ_read OR a PE_fQ_pair
 $fQ_array->get_arr_ref         # returns a reference to an arry that contains all items 
 
 $fQ_array->get_length          # returns the length of the inner array
 $fQ_array->is_empty            # returns (get_length == 0)
 
 $fQ_array->return_fQ_string;   # calls return_fQ_string on each item in the inner array,
                                # joining the returned values by "\n"

=head1 Author
 
 Sari Khaleel (skhaleel at udel.edu)
 Last modified on 1-24-2012
=cut


# Constructor
sub new {
    my ($class, %arg) = @_;
    
    my $self = bless { 
        _arr_ref   => $arg{_arr_ref}     || die "no array reference!", 
    }, $class;

    return $self;
}# end sub new

sub get_arr_ref{
    return $_[0]->{_arr_ref};
}

sub get_length{
    my $arr_ref = $_[0]->get_arr_ref;
    return (@$arr_ref);
}

sub is_empty{
    my $arr_ref = $_[0]->get_arr_ref;
    return (!@$arr_ref)
}
sub get_item{
    my ($class, $n) = @_;
    my $arr_ref = $_[0]->get_arr_ref;
    
    return ($$arr_ref[$n])
}

sub set_item{
    my ($class, $n, $val) = @_;
    my $arr_ref = $_[0]->get_arr_ref;
    
    $$arr_ref[$n] = $val;
}

sub shift{
    my $arr_ref = $_[0]->get_arr_ref;
    my $val = shift @$arr_ref;
    
    return $val;
}

sub unshift{
    my ($class, $item) = @_;
    
    my $arr_ref = $_[0]->get_arr_ref;
    unshift @$arr_ref, $item;
}

sub pop{
    my $arr_ref = $_[0]->get_arr_ref;
    my $val = pop @$arr_ref;
    
    return $val;
}

sub push{
    my ($class, $item) = @_;
    
    my $arr_ref = $_[0]->get_arr_ref;
    push @$arr_ref, $item;
}

sub return_fQ_string{
    my $arr_ref = $_[0]->get_arr_ref;
    
    my $result = "";
    foreach my $item(@$arr_ref){
        $result .= ($item->return_fQ_string())."\n";
    }
    $result =~ s/\n$//;
    
    return $result;
}