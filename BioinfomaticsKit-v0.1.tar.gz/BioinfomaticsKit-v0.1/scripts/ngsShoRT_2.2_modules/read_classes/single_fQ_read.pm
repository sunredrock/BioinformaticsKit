package single_fQ_read;

use strict;
use warnings;

our $VERSION = "1.0";

=head1 NAME

single_fQ_read: object for a single fQ (fastq) read with a set of attributes and methods

=head1 Synopsis

 use single_fQ_read;
 my $read = single_fQ_read->new(
     _header => '@SRR065390.1 HWUSI-EAS687_61DAJ:8:1:1055:3384',
     _seq    => 'TGAANACCTCGAAACTTTTTCAGCGGNNTCNTTNNNNNN',
     _comment => '+',
     _qual =>   '0000!<:<;:@AAA=@:@@@A@AA@#!!##!##!!#!##',
      _min_rl => '52'
    );

 $read -> switch_qual_scores("s2i"); # s2i = sanger to Illumina
                                     # i2s = Illumina to sanger
 $read -> reverse(); # Reverse the read's sequence (and corresponding quality) line
 print $read->return_fQ_string(),"\n";
 print $read->get_length(),"\n";
 print $read->is_good(),"\n"; # return the value of the is_good flag (see Advanced Methods)
 $read->skip(); # set the is_good flag to 1.
	
=head1 Attributes
		
=head2 Chomped Fastq read lines, required on new()
      
 _header
 _seq
 _comment
 _qual
		
=head2 Specs required for Trimming
       
 _qseq_filter : OPTIONAL for reads converted from qseq, saves
                the value of the passed-filtering flag (1/0)
 _ascii_zero  : OPTIONAL, the ascii char value that maps to zero phred score
 	       Default is 33, the standard for Sanger FastQ files.
 _min_rl      : REQUIRED on new(), the minimum_allowed read length
                a read is "good" if its length is >= max_rl
 _skip        : a flag that is set to 1 if the read is filtered out		   
	

=head1 Advanced Methods 
  
=head2 Set the value of a certain attribute
   
 $read->set_<ATTRIBUTE NAME>(<VALUE>); # See attributes for attribute names and vals
 $read->set_min_rl($val);     # used to change the minimum read length if it was redefined by
                              # -min_rl
 $read->set_seq($val);        # used by trimming methods to change the sequence line
 $read->set_header($val);     # used by trimming methods to (optionally) add the trimming
                              # method details to the header
 $read->set_comment($val);    
 $read->set_qual($val);       # used by trimming methods to change the read's quality line
 $read->set_ascii_zero($val); # used by the (quality score-ASCII mapping) methods i2s or s2i	

=head2 Get the value of an attribute
    
 $read->get_<ATTRIBUTE NAME>; # Returns the value of the attribute
 $read->get_qseq_filter; # returns undefined for this read
 $read->get_ascii_zero;  # returns the default 33 for this read
 $read->get_get_seq;     # returns the seq line
 $read->get_header;      # returns the header
 $read->get_comment;     # returns the comment line
 $read->get_qual;        # returns the quality line
 $read->get_min_rl;      # returns 52

=head2 Get reference to a fastq line attribute	
    
 $read->get_header_ref; # returns the reference to  _header
 $read->get_seq_ref;    # returns the reference to _seq
 $read->get_comment_ref; # returns the reference _comment
 $read->get_qual_ref; # returns the reference to _qual 

=head2 Misc

 $read->switch_qual_scores($x2y); # $x2y = (s2i | i2s). Uses set_ascii_zero($val) to switch
                                  # the quality-scoreTOascii mapping between Sanger(s) and 
                                  # Illumina(i).
 $read->is_corrupt; # Under the hood sub. A read is corrupt if (1) the header doesn't start 
                    # with '@' and the comment doesn't start with '+', (2) the lengths of
                    # the sequence and quality strings are NOT equal, (3) the sequence line
                    # contains non-word characters. 

 $read->skip; # set _skip to 1. Used by trimming methods if they cause the read to be filtered
              # out of if they make it shorter than min_rl.

 $read->is_good; # returns the value of (length of seq is >= min_rl) && (_skip == 0)

 $read->DESTROY; # destroys the object. I don't use it.
	
=head1 AUTHOR

 Sari Khaleel (skhaleel AT udel.edu)
 Last modified on 1-24-2012

=cut

# Constructor
sub new {
    my ($class, %arg) = @_;
        
    my $self = bless {
        # Chomped Fastq read lines 
		_header   => $arg{_header}  || die("Error: no header line @_"),
        _seq      => $arg{_seq}     || die("Error: no seq(uence) line @_"),
        _comment  => $arg{_comment} || die("Error: no comment line @_"),
        _qual     => $arg{_qual}    || die("Error: no qual(lity) line @_"),
        
	# Specs required for Trimming
        _qseq_filter =>  $arg{_qseq_filter} || undef,     # or the qseq_filter
        _ascii_zero  => $arg{_ascii_zero}   || 33,        # 33 (Sanger), 64 (Illumina)
        _min_rl      => $arg{_min_rl}       || die("Error: no min_rl @_") ,
		_skip 	     => $arg{_skip} || undef
    }, $class;

    return $self;
}# end sub new

sub reverse{
		$_[0]->{_seq}  = reverse $_[0]->{_seq};
		$_[0]->{_qual} = reverse $_[0]->{_qual};
		return 1;
}
sub get_length{
    # Returns the Read's Length, which equals the length of the sequence line
    return (length ($_[0] -> {_seq}));
}

sub get_quality_scoring{
    my $ascii_zero = $_[0]->{_ascii_zero};
    if ($ascii_zero  == 64){
			return "Illumina scoring (ascii char \#64 = Zero quality score)";
    }
    elsif ($ascii_zero  == 33){
			return "Sanger/NCBI Read Archive scoring (ascii char \#33 = Zero quality score)";
    }
    else {
			return "Neither Sanger nor Illumina (ascii char \#$ascii_zero = Zero quality score)"
    }
}

sub skip{
    $_[0] -> {_skip} = 1;
}
sub is_good{
    # A read is good if its length is >= min_rl (minimum read length) AND its _skip flag
    # is not set to 1
    return 0 if (!($_[0] -> {_seq}) || !($_[0] -> {_qual})); 
    my $read_length = $_[0] -> get_length();
    my $min_rl = $_[0] -> get_min_rl();
    return (!($_[0] -> {_skip}) && ($read_length >= $min_rl));
}

sub is_corrupt{    
#   This is for the programmer. It makes sure the read isn't messed up
#        A read is corrupt if
#	1. Doesn't look like a fastq read (header doesn't start with @, comment doesn't have +)
#	2. The length of its sequence and quality lines isn't the same
#	3. The sequence line has non-word character

    my $seq_len = (length ($_[0] -> {_seq}));
    my $qual_len = (length ($_[0] -> {_seq}));
    
    #1.
    return 1 if ($_[0] -> {_header} !~ /^\@/);
    return 1 if ($_[0] -> {_comment} !~ /^\+/);

    #2.
    return 1 if ($seq_len != $qual_len );
    
    #3.
    return 1 if ($_[0] -> {_seq} =~ /\W/);
}

sub return_fQ_string{
    # Return the string (with carriage symbol) that contains the 4 lines of a fastQ read
    my $fq_string = $_[0] -> {_header} ."\n".$_[0] -> {_seq} ."\n".$_[0] -> {_comment}."\n".$_[0] ->{_qual};
}

sub switch_qual_scores{
	# Switch quality scores between Sanger and Illumina
	my ($class, $x2y) = @_;
	die "No x2y option was specified. Valid options are s2i and i2s" if (!$x2y);
	my $conversion_factor;
	if ($x2y eq "s2i")   { 
		$conversion_factor = 31;
                $_[0] -> set_ascii_zero(64);
	}
	elsif ($x2y eq "i2s"){ 
		$conversion_factor = -31;
                $_[0] -> set_ascii_zero(33);
	}
	else {
	    die "invalid x2y option for switch_qual_scores: $x2y. Valid options are s2i and i2s";
	}
	
	my @chars = split (//, $_[0] -> {_qual});
    
    my $char;
    foreach $char (@chars){
		my $ascii_num = ord($char);
		$ascii_num += $conversion_factor;
		
		# Make sure that the new ascii_num isn't out of bounds :
		# 1. ascii_num < 33, which means that the user is trying to do i2s with a read that isn't
		#    Illumina-scored (Q[0] = ASCII[64]), and so the -31 reduction overshooting
		# 2. ascii_num > 126, which means that the user is trying s2i with a read that isn't Sanger-
		#    scored (Q[0] = ASCII[33]), and so the +31 is overshooting 
			if (($x2y eq "i2s" && ($ascii_num < 33))){
				die "ERROR (single_fQ_read::switch_qual_scores) : i2s (Illumina to Sanger) conversion has lead to an out of bounds (< 33) ASCII character.\n".
					"It seems that original your quality score mapping isn't Illumina's ASCII[64]-based mapping.\n\n";
			}
			
			if (($x2y eq "s2i" && ($ascii_num > 126))){
				die "ERROR (single_fQ_read::switch_qual_scores) : s2i (Sanger to Illumina) conversion has lead to an out of bounds (> 126) ASCII character.\n".
					"It seems that original your quality score mapping isn't Sanger's ASCII[33]-based mapping.\n\n";
			}
		
		$char = chr($ascii_num);
    }
    my $new_qual_line = join ('', @chars);
    $_[0] -> set_qual($new_qual_line);
    
    return $x2y;
}# end switch qual scores

# DESTROY
sub DESTROY{
    my ($self) = @_;
}

########## SET/GET FUNCTIONS ###################
# Accessor Functions (get_)
sub get_qseq_filter{
	$_[0] -> {_qseq_filter};	
}

sub get_ascii_zero{
	$_[0] -> {_ascii_zero};	
}

sub get_min_rl{
	$_[0] -> {_min_rl};
}

sub get_seq{
	$_[0] -> {_seq};
}

sub get_header{
	$_[0] -> {_header};
}

sub get_comment{
	$_[0] -> {_comment};
}

sub get_qual{
	$_[0] -> {_qual};
}

sub get_seq_ref{
	\($_[0] -> {_seq});
}

sub get_header_ref{
	\($_[0] -> {_header});
}

sub get_comment_ref{
	\($_[0] -> {_comment});
}

sub get_qual_ref{
	\($_[0] -> {_qual});
}


# Mutator Functions (set_)
sub set_min_rl{
	my ($class, $min_rl) = @_;
	$_[0] -> {_min_rl} = $min_rl;
}

sub set_seq{
	my ($class, $seq) = @_;
	$_[0] -> {_seq} = $seq;
}

sub set_header{
	my ($class, $header) = @_;
	$_[0] -> {_header} = $header;
}
sub set_comment{
	my ($class, $comment) = @_;
	$_[0] -> {_comment} = $comment;
}

sub set_qual{
	my ($class, $qual) = @_;
	$_[0] -> {_qual} = $qual;
}
sub set_ascii_zero{
	my ($class, $ascii_zero) = @_;
	$_[0] -> {_ascii_zero} = $ascii_zero;
}

sub set_qseq_filter{
	my ($class, $qseq_filter) = @_;
	$_[0] -> {_qseq_filter} = $qseq_filter;
}
sub set_skip{
	my ($class, $val) = @_;
	$_[0] -> {_skip} = $val;
}

1;
