package manage_input_params;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(extract_parameters_from_input_file validate_input_params);

use strict;
use warnings;

=head1 NAME

 manage_input_params: a module for validating input parameters passed from ngsShoRT's commandline
 AND/OR extraction of these parameters from an input_params.txt file.
 
head1 manage_input_params::validate_input_params
   
   Validation includes checking that:
     - input file/dir paths exist,
	 - output directories can be created
     - that mode and method names are valid
	 - that parameter values are valid and within accepted range (if numerical)

head1 manage_input_params::extract_parameters_from_input_file
		  
  The only input is $params_file, the path of the input_params file (a modified copy of
  input_file_TEMPLATE.txt). All params are extracted from this file.

=cut

sub validate_input_params{
	my ($mode, $min_read_length, $qseq_dot_to_N, $merge_dir, $header_tag,
		$method_sequence_arr_ref, $print_discarded_reads,
		$PE_input_filepath_1, $PE_input_filepath_2,$SE_input_filepath,
		$se_dir_path, $pe_dir_path,
		$output_dir,
		$five_prime_adapter_filepath_ref, $match_percentage, $adpt_action,
		$furthest_allowed_index_for_adapter_match_ref, $built_in_adapter_lib_dirpath,
		$nsplit_n_cutoff, $avg_cutoff, $mott_limit,
		$Nperc_cutoff, $N_cutoff, $QPerc_cutoff, $LQS_cutoff, $qB_action, $qB_mode,
		$rmHP_min_length, $rmHP_bases_string
		) = @_;
	
	# MAIN PARAMETERS
	# Check the mode
		if (! $mode){
			die "\nERROR (main params: mode): a mode (trim | report) was not specified !\n";
		}
		die "\nERROR (main params: mode): invalid mode: $mode. Valid modes: trim, report\n" if (($mode ne "trim") && ($mode ne "report"));
	
	# Check that min_read_length was specified
		if (! $min_read_length){
			die "\nERROR (main params: min_rl): a minimum_read_length (-min_rl INT) was not specified !\n";
		}
	
	# Check qseq .2N
		if (($qseq_dot_to_N ne "yes") && ($qseq_dot_to_N ne "no")){
			die "\nERROR (main params: qseq_.2N): invalid value for -qseq_.2N: $qseq_dot_to_N. Valid values are (yes | no).\n";
		}
		if ($qseq_dot_to_N eq "yes"){$qseq_dot_to_N = 1;}
		if ($qseq_dot_to_N eq "no") {$qseq_dot_to_N = 0;}
	
	if (($merge_dir ne "yes") && ($merge_dir ne "no")){
			die "\nERROR (main params: merge_dir): invalid value for -merge_dir: $merge_dir. Valid values are (yes | no).\n";
	}
	
	#	Check header tag
	if (($header_tag ne "yes") && ($header_tag ne "no")){
			die "\nERROR (main params: header_tag): invalid value for -header_tag: $header_tag. Valid values are (yes | no).\n";
	}
	
	# Check that all methods are valid
		my @valid_method_names = qw (5adpt lqr tera nsplit mott i2s s2i nperc ncutoff qseq0 qseqB 3end 5end rmHP);
		foreach my $current_method (@$method_sequence_arr_ref){
			my $method_name_matches = 0;
			foreach my $valid_method_name (@valid_method_names){
				if ($current_method eq $valid_method_name){
					$method_name_matches = 1;
				}
			}
			if (!$method_name_matches){
				die "\nERROR (main params: methods): this method name is invalid: $current_method.\nValid method names are @valid_method_names\n";
			}
		}# end foreach of my methods
	
	# Check print_discarded_reads
		if (($print_discarded_reads ne "yes") && ($print_discarded_reads ne "no")){
			die "\nERROR (main params: print_discarded_reads): invalid value for -print_discarded_reads: $print_discarded_reads. Valid values are (yes | no).\n";
		}
	
	# Check ascii zero : already done in  elsif (! $params_file){
	
# FILE/DIR PATHS
	# Check that input files were provided
		if (!$SE_input_filepath && !($PE_input_filepath_1 || $PE_input_filepath_2) && !$se_dir_path && !$pe_dir_path){
			die "\nERROR (main params: input): no input files (-pe1 STRING -pe2 STRING  OR  -se STRING OR -dir_se STRING or -dir_pe STRING) were specified.\n";
		}
	# IF dirs were provided, make sure they are dirs
	if ($se_dir_path)  {
		if ((! -d $se_dir_path) || (! -e $se_dir_path)){
			die "\nERROR (main params: input) the directory path for multiple SE files, $se_dir_path, does not seem to be a directory and/or does not exist.".
			"This can be due to using '~' instead of /home/username/ in the path\n";
		}	
	}
	if ($pe_dir_path)  {
		if ((! -d $pe_dir_path) || (! -e $pe_dir_path)){
			die "\nERROR (main params: input) the directory path for multiple PE files, $pe_dir_path, does not seem to be a directory and/or does not exist.".
			"This can be due to using '~' instead of /home/username/ in the path\n";
		}
	}
	
	# NOT USED ANYMORE: Check that SE and PE were not specified together	
		#if (! (($SE_input_filepath) xor ($PE_input_filepath_1 || $PE_input_filepath_2) xor $pe_dir_path xor $se_dir_path)){
		#	die "\nERROR (main params: input): both Paired-End (PE) and Single-Read (SE) input files/dir were specified.
		#    You can specify only on of these types (-pe 1 -pe2  OR -se OR -dir_se OR dir_pe).\n";
		#}
	
	# Check that input files exist	
		if (defined $SE_input_filepath){
			# If a single file is listed (there are no commas in the path), check that it exists
				if ($SE_input_filepath !~ /,/){
					if (! -e $SE_input_filepath){
						die "\nERROR (paths: input): the SE input file does not exist !\n";
					}
				}
			# else: if there are commas in the path, i.e, there are multiple files listed here	
				else {
					my @SE_filepaths = split /,/, $SE_input_filepath;
					foreach my $se_filepath (@SE_filepaths){
						if (! -e $se_filepath){
							die "\nERROR (paths: input): one of the listed (comma-separated) SE input files does not exist at $se_filepath !\n";
						}
					}
				}
		}
		if ($PE_input_filepath_1){
			if ( (! -e $PE_input_filepath_1) || (! -e $PE_input_filepath_2)){
				die "\nERROR (paths: input): one/both PE files do(es) not exist at your specified paths!\nPE_1: $PE_input_filepath_1\nPE_2: $PE_input_filepath_2\n\n";
			}
		}# end elsif (!$SE_input_filepath)
	
	
	# Check that output dir exists and try to create it if it doesn't
		if (! $output_dir){
			die "\nERROR (paths: output): the output directory (-o STRING) was not specified !\n";
		}
		if (-e $output_dir){
			print "\nWARNING (paths: output):  the output directory already exists. Files might be overwritten!\n";
		}
		elsif (! -e $output_dir){
			system ("mkdir $output_dir");
			if (! -e $output_dir){
				die "\nERROR (paths: output): output directory did not exist and cannot be created !\n";
			}
		}

	
# VERIFY METHOD PARAMS	: Foreach method, make sure that all its parameters are defined and valid
	my $concated_methods = join '__', @$method_sequence_arr_ref;
	if ($concated_methods =~ /5adpt/){
		
		# Check the adapter filepath provided via 5a_f. If it matches a built-in symbol, set the full
		# filepath to that symbol. Else, see if the provided string value is a valid and existent filepath
		# If not, die.
		my $lib_filename; my $filepath_is_a_lib_code = 1;
		my $lib_code = $$five_prime_adapter_filepath_ref;
		if ($five_prime_adapter_filepath_ref){
			if ($$five_prime_adapter_filepath_ref eq "i-g"){
				#$lib_filename = "Illumina_Genomic";
				$lib_filename = "Illumina_PE_with_RCed_adapters";
			}
			elsif ($$five_prime_adapter_filepath_ref eq "i-d"){
				$lib_filename = "Illumina_DpnII";
			}
			elsif ($$five_prime_adapter_filepath_ref eq "i-m"){
				$lib_filename = "Illumina_multiplex";
			}
			elsif ($$five_prime_adapter_filepath_ref eq "i-n"){
				$lib_filename = "Illumina_NIaIII";
			}
			elsif ($$five_prime_adapter_filepath_ref eq "i-p"){
				$lib_filename = "Illumina_PE";
			}
			elsif ($$five_prime_adapter_filepath_ref eq "i-r"){
				$lib_filename = "Illumina_sRNA";
			}
			elsif ($$five_prime_adapter_filepath_ref eq "p-r"){
				$lib_filename = "pyroseq_sRNA";
			}
			elsif ($$five_prime_adapter_filepath_ref eq "p-b"){
				$lib_filename = "pyroseq_basic";
			}
			elsif ($$five_prime_adapter_filepath_ref eq "p-p"){
				$lib_filename = "pyroseq_PE";
			}
			elsif ($$five_prime_adapter_filepath_ref eq "p-a"){
				$lib_filename = "pyroseq_amplicon";
			}
			else{
				if (! -e $$five_prime_adapter_filepath_ref){
					die "\nERROR (5a_f): the specified value ($$five_prime_adapter_filepath_ref) is not a valid library code (see quick manual) nor a valid filepath !\n";
				}
				else{
					$filepath_is_a_lib_code  = 0;
				}
			}
			if ($filepath_is_a_lib_code){
				$$five_prime_adapter_filepath_ref = "$built_in_adapter_lib_dirpath/$lib_filename.txt";
				# Check that it exists
				die "\nERROR (5a_f): it seems that the library file corresponding to the lib_code $lib_code does not exist at $$five_prime_adapter_filepath_ref !\n" if (!-e $$five_prime_adapter_filepath_ref);
				#die ">> $$five_prime_adapter_filepath_ref\n";
			}
			
		}
		#die "$five_prime_adapter_filepath";
		
		die "\nERROR (method params: 5adpt): invalid -5a_mp value : $match_percentage. It must be between 50-100.\n\n" if (($match_percentage < 50) || ($match_percentage > 100));
		die "\nERROR (method params: 5adpt): invalid -5a_axn value: $adpt_action. Valid values are (ka | kr).\n\n" if (($adpt_action ne "kr") && ($adpt_action ne "ka"));
		die "\nERROR (method params: 5adpt): the user-specified 5' adapter file was not found at $$five_prime_adapter_filepath_ref !!\n" if (! -e $$five_prime_adapter_filepath_ref);
		
		my $fmi = $$furthest_allowed_index_for_adapter_match_ref;
		
		#if fmi is not 'full' AND !(fmi =~ digit && fmi !~ non-digit)
		if (($fmi ne "full") && !(($fmi =~ /^\d+/) && ($fmi !~ /\D/))){	    
			die "\nERROR (method params: 5adpt): this 5a_fmi value (5adpt_furthest_allowed_index_for_adapter_match), $$furthest_allowed_index_for_adapter_match_ref, seems to neither 'full' nor an integer!!\n\n"; 
		}
		if ($fmi eq "full"){$$furthest_allowed_index_for_adapter_match_ref = "";}
		#die "$fmi - $$furthest_allowed_index_for_adapter_match_ref";
	}
	
	  
	
	if ($concated_methods =~ /tera/){
		# Check that their values are valid
		die "\nERROR (method params: tera): invalid -tera_avg value : $avg_cutoff. It must be between 0 and 100\n\n" if (($avg_cutoff < 0) || ($avg_cutoff > 100));
	}
	
	if ($concated_methods =~ /nsplit/){
		die "\nERROR (method params: nsplit): invalid -nsplit_len value : $nsplit_n_cutoff. It must be > 0\n\n" if ($nsplit_n_cutoff < 1);
	}
	
	if ($concated_methods =~ /mott/){
		die "\nERROR (method params: mott): invalid -mott_lim value : $mott_limit. It must be a float and <= 1\n\n" if ($mott_limit > 1);
	}
	
	if ($concated_methods =~ /nperc/){
		die "\nERROR (method params: nperc): invalid -nperc_cutoff value : $Nperc_cutoff. It must be between 1 and 100\n\n" if (($Nperc_cutoff < 0) || ($Nperc_cutoff > 100));
	}
	if ($concated_methods =~ /ncutoff/){
		die "\nERROR (method params: ncutoff): invalid -ncutoff_len value : $N_cutoff. It must be >=1\n\n" if ($N_cutoff < 1);
	}
	
	if ($concated_methods =~ /lqr/){
		die "\nERROR (method params: lqr): invalid -lqs value : $LQS_cutoff. It must be between 0-100\n\n" if (($LQS_cutoff < 0) || ($LQS_cutoff > 100));
		die "\nERROR (method params: lqr): invalid -lq_p (LQS_Perc_in_read_cutoff) value: $QPerc_cutoff. It must be between 0-100\n\n" if (($QPerc_cutoff < 0) || ($QPerc_cutoff > 100));
	}
	
	if ($concated_methods =~ /qseqB/){
		die "\nERROR (method params: qseqB): invalid -qB_action value: $qB_action. Valid values are (ka | kr).\n\n" if (($qB_action ne "kr") && ($qB_action ne "ka"));
		die "\nERROR (method params: qseqB): invalid -qB_mode value: $qB_mode. Valid values are (global | local).\n\n" if (($qB_mode ne "local") && ($qB_mode ne "global"));
		die "\nERROR (method params: qseqB): '-qB_mode global' cannot be used with '-qB_action ka' (use -qB_action kr instead).\n\n" if (($qB_mode eq "global") && ($qB_action eq "ka"));
	}
	
	if ($concated_methods =~ /rmHP/){
		die "\nERROR (method params: rmHP): invalid -rmHP_ml (minimum homopolymer length) value : $rmHP_min_length. It must be >=5 \n" if ($rmHP_min_length <5);
		
		my @bases_list = split (//, $rmHP_bases_string);
		foreach my $base (@bases_list){
			die "\nERROR (method params: lqr): invalid -rmHP_bases value: $rmHP_bases_string. It can only consist of a,g,c,t,n (case insensitive)\n" if ($base !~ /[agctn]/i);
		}
	}
}# end validate_input_params

sub extract_parameters_from_input_file{
	my ($input_file) = @_;
	
    my (
    	$SE_input_filepath, $PE_input_filepath_1, $PE_input_filepath_2, $output_dir,                
			$se_dir_path,$pe_dir_path,               
		
		# Main parameters
				$min_read_length, $ASCII_of_zero_qual_score, $mode, $method_sequence_arr_ref, 
				$print_discarded_reads, $qseq_dot_to_N,$pe_filename_pattern, $merge_dir, $header_tag,
			
		# Method Parameters and trimmed base/read/pair counter references
		  $n_threeEnd, $n_fiveEnd, $avg_cutoff, $mott_limit,

		  $five_prime_adapter_filepath, 
		  $match_percentage, $furthest_allowed_index_for_adapter_match, 
		  $adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
		 
		  $LQS_cutoff, $QPerc_cutoff,
		  $N_cutoff, $Nperc_cutoff, $nsplit_n_cutoff, 
		  $B_num_cutoff, $qB_mode, $qB_action,
		  $rmHP_min_length, $rmHP_bases_string
		);

	
	#die $header_tag;	
	if (! -e $input_file){
		die "\nERROR (extract_parameters_from_input_file): Parameters INPUT file, $input_file, does not exist ! \n";
	}

	open (INPUT, "<", $input_file);
	
	my $line = <INPUT>;
	while (defined($line)){
		chomp($line);
		
		if (defined ($line)){
			if ($line =~ /^\#/){ 
				#it's a comment line. Skip it.
			}
			elsif ($line =~ /->/) {
				my ($parameter, $value) = split /:/, $line;
				if (!$parameter) {
					die "ERROR (extract_parameters_from_input_file): A Parameter is empty in this line from the input".
						"parameters file: $line\nYour parameters input file seems to be corrupt. Try using a fresh copy ".
						"from the original input_file_TEMPLATE.txt\n\n";}
				
				# Clean up white spaces
				$parameter =~ s/\s+//g;
				$parameter =~ s/->//g;
				$value =~ s/\s+//g;
	
				# File/Dir paths
					if ($parameter eq "PE_file_1"){
						$PE_input_filepath_1 = $value;
					}
					if ($parameter eq "PE_file_2"){
						$PE_input_filepath_2 = $value;
					}
					if ($parameter eq "SE_file"){
						$SE_input_filepath = $value;
					}
					if ($parameter eq 'output_dir'){
						$output_dir = $value;
					}
					if ($parameter eq 'PE_files_dir'){
						$pe_dir_path = $value;
					}
					if ($parameter eq 'SE_files_dir'){
						$se_dir_path = $value;
					}
	
				# Main params				
					if ($parameter eq "mode"){
						$mode = $value;
					}
					if ($parameter eq 'method_sequence'){
						my @methods = split /_/, $value;
						$method_sequence_arr_ref = \@methods;
					}
					if ($parameter eq 'min_read_length'){
						$min_read_length = $value;
					}
					if ($parameter eq 'ASCII_of_zero_qual_score'){
						$ASCII_of_zero_qual_score = $value;
					}
					if ($parameter eq 'print_discarded_reads'){
						$print_discarded_reads = $value;
					}
					if ($parameter eq 'qseq_dot_to_N'){
						$qseq_dot_to_N = $value;
					}
					if ($parameter eq 'merge_multiple_files'){
						$merge_dir = $value;
					}
					if ($parameter eq 'PE_filename_pattern'){
						$pe_filename_pattern = $value;
					}
					if ($parameter eq 'header_tag'){
						$header_tag = $value;
					}
					
				 # NPerc, Nsplit, Ncutoff				
					if ($parameter eq 'Nperc_cutoff'){
						$Nperc_cutoff = $value;
					}
					if ($parameter eq 'nsplit_len'){
						$nsplit_n_cutoff = $value;
					}
					if ($parameter eq 'ncutoff_len'){
						$N_cutoff = $value;
					}
	
				# LQR								
					if ($parameter eq "LQS"){
						$LQS_cutoff = $value;
					}
					if ($parameter eq 'LQS_Perc_in_read_cutoff'){
						$QPerc_cutoff = $value;
					}
	
				# TERA, Mott, 3end and 5end
					if ($parameter eq 'tera_avg'){
						$avg_cutoff  = $value;
					}
					if ($parameter eq 'mott_limit'){
						$mott_limit = $value;
					}
					if ($parameter eq 'n_3end'){
						$n_threeEnd = $value;
					}
					if ($parameter eq 'n_5end'){
						$n_fiveEnd = $value;
					}
			
			 # 5adpt
					if ($parameter eq '5adpt_file'){
						$five_prime_adapter_filepath = $value;
					}
					if ($parameter eq '5adpt_match_percentage'){
						$match_percentage = $value;
					}
					if ($parameter eq '5adpt_furthest_allowed_index_for_adapter_match'){
						$furthest_allowed_index_for_adapter_match = $value;
					}
					if ($parameter eq '5adpt_max_match_len_diff'){
						$adpt_max_match_len_diff = $value;
					}
					if ($parameter eq '5adpt_ins'){
						$num_inss = $value;
					}
					if ($parameter eq '5adpt_del'){
						$num_dels = $value;
					}
					if ($parameter eq '5adpt_sub'){
						$num_subs = $value;
					}
					if ($parameter eq '5adpt_action'){
						$adpt_action = $value;
						#die $value;
					}
	
			# qseqB
				if ($parameter eq 'num_B_cutoff'){
						$B_num_cutoff = $value;
				}
				if ($parameter eq 'qseqB_mode'){
						$qB_mode = $value;
				}
				if ($parameter eq 'qseqB_axn'){
						$qB_action = $value;
				}
				
			# rmHP
				if ($parameter eq 'rmHP_ml'){
						$rmHP_min_length= $value; #, 
				}
				if ($parameter eq 'rmHP_bases'){
						$rmHP_bases_string = $value;
				}

			}# end if parameter line
		}# end if defined
		
		$line = <INPUT>;
	}
	
	#die ">> $five_prime_adapter_filepath\n";
	return ($SE_input_filepath, $PE_input_filepath_1, $PE_input_filepath_2, $output_dir,                
					$se_dir_path,$pe_dir_path,               
				# Main parameters
				$min_read_length, $ASCII_of_zero_qual_score, $mode, $method_sequence_arr_ref, 
				$print_discarded_reads, $qseq_dot_to_N,$pe_filename_pattern, $merge_dir, $header_tag,
			
				# Method Parameters and trimmed base/read/pair counter references
		  $n_threeEnd, $n_fiveEnd, $avg_cutoff, $mott_limit,

		  $five_prime_adapter_filepath, 
		  $match_percentage, $furthest_allowed_index_for_adapter_match, 
		  $adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
		 
		  $LQS_cutoff, $QPerc_cutoff,
		  $N_cutoff, $Nperc_cutoff, $nsplit_n_cutoff, 
		  $B_num_cutoff, $qB_mode, $qB_action,
		  $rmHP_min_length, $rmHP_bases_string);
	

}# end sub extract


