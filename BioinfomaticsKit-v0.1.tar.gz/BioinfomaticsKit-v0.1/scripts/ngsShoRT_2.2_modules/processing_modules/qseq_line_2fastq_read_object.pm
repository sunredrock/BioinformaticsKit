package qseq_line_2fastq_read_object;
require Exporter;

use strict;
use warnings;

our $VERSION =  1.0;
our @ISA = 		  qw(Exporter);
our @EXPORT =   qw(get_single_fQ_read_from_qseq);

=head1 NAME

 &get_single_fQ_read_from_qseq : a subroutine that takes a single qseq read line, re-arranges
 its parts to create the corresponding 4 fastq lines, then loads them (with the qseq filter
 information) into a new single_fQ_read object.
 
=head1 SYNOPSIS

 my $qseq_line = 'INSERT QSEQ LINE HERE';
 my $read = get_single_fQ_read_from_qseq($qseq_line,
                                         # The following values are for the single_fQ_read object
                                          $min_read_length,$ASCII_of_zero_qual_score, $qseq_dot_to_N);

=cut

sub get_single_fQ_read_from_qseq{
    my ($qseq_line,$min_read_length,$ASCII_of_zero_qual_score, $qseq_dot_to_N)= @_;
	
  # Takes the following parts from ONE tab-delimited qseq line:
    #0 Machine name
    #1 Run number
    #2 Lane number
    #3 Tile number
    #4 X coordinate of spot
    #5 Y coord of spot
    #6 Index
    #7 Read number
    #8 Sequence
    #9 quality
    #10 filter

    # AND returns the following 4-lines of fastq (note that the standard qseq2fastq conversion skips ".
    # parts 1 and 10. However, I kept part 10 by appending it to part 0)
      # @[0]:[2]:[3]:[4]:[5]#[6]/[7]
      # [8]
      # +
      # [9]

    my @parts = split (/\t/, $qseq_line);
    # Check that the line is really qseq
    if (! @parts){
    	die "ERROR (qseq2fastq): An error has occured. The following line and/or its file does not seem ".
	    "to be in the tab-delimited qseq format:\n$qseq_line\n";
    }
		
    my $header = "@"."$parts[0]:$parts[2]:$parts[3]:$parts[4]:$parts[5]#$parts[6]/$parts[7]";
    my $seq = "$parts[8]" || die "ERROR (qseq2fastq): An error has occured. I could not extract a Fastq".
	                         " sequence line from the following read in the file:\n$qseq_line\n";
    my $comment = "+";
    my $qual = "$parts[9]" || die "ERROR (qseq2fastq): An error has occured. I could not extract a Fastq ".
	                          "quality line from the following read in the file:\n$qseq_line\n";
		
    my $qseq_filter = $parts[10];
		
    # Convert . -> N if ($qseq_dot_to_N)
	if ($qseq_dot_to_N){
	    $seq =~ s/\./N/g;
	}
		
	my $read = new single_fQ_read(
	    _header => $header,
	    _seq    => $seq,
	    _comment => $comment,
	    _qual =>   $qual,
	    _min_rl => $min_read_length,
	    _ascii_zero => $ASCII_of_zero_qual_score,
	    _qseq_filter => $qseq_filter
				      );
   return $read;
}
