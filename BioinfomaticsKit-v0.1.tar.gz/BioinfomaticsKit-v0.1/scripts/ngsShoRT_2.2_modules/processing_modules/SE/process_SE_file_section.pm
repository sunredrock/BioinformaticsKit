package process_SE_file_section;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(process_SE_file_section);

use strict;
use threads;

# Read classes
use single_fQ_read 1.0;
use fQ_array 1.0;


# Processing modules
use process_SE_read 1.0;
use qseq_line_2fastq_read_object 1.0;


=head1 NAME

 process_SE_file_section: a subroutine that parses a section of the input SE
 file and run ngsShoRT methods locally on that section of the file. The resulting
 output files are: 
 
  - a trimmed_SE_file (if mode = trim)
  - discarded reads file (optional) for reads that failed trimming and were thus
    discarded from the final trimmed output
  - extracted 5' adapter sequences (only if -methods include 5adpt).
  - counts.txt : a csv file containing all trimming counts for the file

	
=head1 SYNOPSIS

 In the MASTER thread, process_single_read_file is called to trim its input file
 using N threads. To do this, N threads are created, each running an instance of
 process_SE_file_section on its separate "section" of the file. Each thread starts
 at a different spot of the SE input file, and parses reads separated by N steps.
 The trimming result of each section is then merged by process_PE_files.
 
 To order the output, the output files of each thread/process_SE_file_section is
 prefixed with the number of the thread calling that instance process_SE_file_section.
 In addition, in each output file, the output corresponding to each read is enclosed
 by '> >' and '< <' lines -- even if the output is an empty string (if a read is
 trimmed successfuly, its corresponding "discarded read" is null). These lines are
 necessary for the merging step done by process_PE_files. 
 
 
 &process_SE_file_section(
    $thread_num, $num_threads, $read_format,
	# FilePaths
		$input_filepath, $output_dir,
	
	# Main params
		$methods_include_qseq0, $methods_include_5adpt,
		$mode, $method_sequence_arr_ref, $min_read_length, 
		$ASCII_of_zero_qual_score, $qseq_dot_to_N, $print_discarded_reads,
		$header_tag,
	
	# Method params
		# PE_ThreeEnd, PE_FiveEnd
			$n_threeEnd,$n_fiveEnd,
		# PE_five_prime_adpt
			\@five_prime_r_adpt,
			$match_percentage, $furthest_allowed_index_for_adapter_match, 
			$adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
		# PE_LQR
			$LQS_cutoff, $QPerc_cutoff,
		# PE_Mott, PE_Ncutoff, PE_NPerc, PE_Nsplit
			$mott_limit, $N_cutoff, $Nperc_cutoff,$nsplit_n_cutoff, 
		# qseqB
			$B_num_cutoff, $qB_mode, $action, 
		# TERA
			$avg_cutoff
	);
										
 
 The first read in the section is used to identify the read format of the file (either
 qseq or fastq).
   - If fastq, 4 lines are parsed at a time and the next read in the section
     is 4 * N lines away.
   - If qseq, 1 line is parsed at a time and the next read in the section
     is N lines away.

 Every read is parsed/processed/trimmed using process_single_read.
 	
=head1 I/O 

=head2 Input parameter details

 See the initialization syntax " my ( ...) = @_" below; each parameter is followed
 by a comment explaining its function.

=head2 Output 
 
 See NAME and SYNOPSIS sections above for details. The resulting files are:
 (X = thread number)
  /temp/
	X.counts.txt
	X.trimmed_reads.fastq (only if mode = trim)
	X.extracted_5adpt_seqs.txt (only if -methods includes 5adpt)
	X.discarded_reads.fastq (only if -print_discarded_reads yes)
 
=head1 AUTHOR

 Sari Khaleel (skhaleel at udel.edu)
 Last modified on 1-26-2012

=cut


sub process_SE_file_section{
	my ($thread_num, $num_threads, $read_format,
        
        # FilePaths
			$input_filepath, $out_dir,
		
        # Main params
			$methods_include_qseq0, $methods_include_5adpt,
			$mode, $method_sequence_arr_ref, $min_read_length, 
			$ASCII_of_zero_qual_score, $qseq_dot_to_N, $print_discarded_reads,
			$header_tag,
		
        # Method params
            # SE_ThreeEnd, SE_FiveEnd
                $n_threeEnd,$n_fiveEnd,
            # SE_five_prime_adpt
                $five_prime_r_adpt_arr_ref,
                $match_percentage, $furthest_allowed_index_for_adapter_match, 
                $adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
            # SE_LQR
                $LQS_cutoff, $QPerc_cutoff,
            # SE_Mott, SE_Ncutoff, SE_NPerc, SE_Nsplit
                $mott_limit, $N_cutoff, $Nperc_cutoff,$nsplit_n_cutoff, 
            # qseqB
                $B_num_cutoff, $qB_mode, $action, 
            # TERA
                $avg_cutoff,
			# rmHP
				$rmHP_min_length, $rmHP_bases_arr_ref
	) = @_;

	my $one_thread = ($num_threads == 1);
	
	# 0. translate print_discarded_reads from string to binary
		my $print_discarded_reads_flag;
		if ($print_discarded_reads eq "yes") {$print_discarded_reads_flag = 1;}
		else {$print_discarded_reads_flag = 0;}
	
	# 1. Open chunk handles
		my $temp_out_dir = "$out_dir/temp";
		if (! -e $temp_out_dir){
			system ("mkdir $temp_out_dir");
		}
		my ($trimmed_reads_fH, $five_prime_extracted_adpt_fH, $discarded_reads_fH, $counts_fH);
		
		open $counts_fH, "> $temp_out_dir/$thread_num.counts.txt";
		if ($mode eq "trim") {open $trimmed_reads_fH, "> $temp_out_dir/$thread_num.trimmed_reads.fastq";}
		if ($methods_include_5adpt){open $five_prime_extracted_adpt_fH, "> $temp_out_dir/$thread_num.extracted_5adpt_seqs.txt";}
		if ($print_discarded_reads_flag){open $discarded_reads_fH, "> $temp_out_dir/$thread_num.discarded_reads.fastq";}
	
	# 2. Initialize main counters
		my ($thread_read_count, $thread_base_count)  = (0,0);
	
    # 3. Initialize Local counters 
		my (
		 # SE_ThreeEnd
			$num_bases_trimmed_by_ThreeEnd, $num_reads_trimmed_by_ThreeEnd,
		 # SE_FiveEnd
			$num_bases_trimmed_by_FiveEnd, $num_reads_trimmed_by_FiveEnd,
		 # SE_five_prime_adpt
			$num_adpt_trimmed_bases,
			$num_adpt_trimmed_reads, 
			$num_detected_adapter_sequences, 
		 # SE_LQR
			$number_of_LQR_trimmed_bases, $number_of_LQR_trimmed_reads,
		 # SE_Mott
			$num_mott_trimmed_bases, $num_mott_trimmed_reads,
		 # SE_Ncutoff
			$num_bases_trimmed_by_Ncuotff, $num_reads_trimmed_by_Ncuotff,
		 # SE_NPerc
			$num_bases_trimmed_by_Nperc, $num_reads_trimmed_by_Nperc,
		 # SE_Nsplit
			$num_of_removed_bases_using_Nsplit, $num_of_removed_N_blocks,
			$num_of_Nsplit_removed_reads, 
		 # qseq0
			$num_bases_trimmed_by_qseq0, $num_reads_trimmed_by_qseq0, 
		 # qseqB
			$num_bases_trimmed_by_qseqB,$num_reads_trimmed_by_qseqB,
		 # TERA
			$num_TERA_trimmed_bases,$num_TERA_trimmed_reads,
		# rmHP
			$num_rmHP_trimmed_bases,$num_rmHP_trimmed_reads)
		= (0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,0,0,0);
	
	# 4. Open the input and log files, managing compressed files
		my $IN; my $uncompress;
		
		if ($input_filepath =~ /\.zip$/i) {
			if(grep { -x "$_/unzip"} split /:/,$ENV{PATH}) {
			  $uncompress = 'unzip -p'; # -p = pipe output to STDOUT
			}
			else {
				  print "unzip is not in your PATH, please add it\n";
				  exit 1;
			}
		}
		elsif ($input_filepath =~ /\.gz$/i) {
			if(grep { -x "$_/gzip"}split /:/,$ENV{PATH}) {
				$uncompress = 'gzip -cd'; # -d = decompress; -c = write to STDOUT
			}
			else {
				print "gzip is not in your PATH, please add it\n";
				exit 1;
			}
		}
		elsif ($input_filepath =~ /\.bz2$/i) {
			if(grep { -x "$_/bzip2"}split /:/,$ENV{PATH}) {
				$uncompress = 'bzip2 -cd';
			}
			else {
				print "bzip2 is not in your PATH, please add it\n";
				exit 1;
			}
		}
	
		if ($uncompress) {
			open ($IN, "$uncompress $input_filepath|")|| die("ERROR: $uncompress can not read file ($input_filepath): $!\n");
		}
		else {
			open ($IN, $input_filepath) || die("ERROR: Can not read file ($input_filepath): $!\n");
		}
		
	
	# 5. First, skip to the correct start position, count*num_lines_per_read
		my $num_lines_per_read = 1; if ($read_format eq "fastq") {$num_lines_per_read = 4;}
		my $start_position = 0; my $line;
		while (($thread_num *$num_lines_per_read) > $start_position){
			$line = <$IN>;
			$start_position++;
		}
	
	# 6. Begin to parse the file
		my $done = 0;
		my $first_line_in_file = 1; # This is used to check the file's format (fastq vs qseq)
		my ($line1, $line2, $line3, $line4, $read);
		
		while (!$done){
			$line1 = <$IN>;
			
			# Determine the file's format (fastq vs qseq) <-- I deactivated the fastQ check part bc fastQ read headers no longer start with @
				if ($first_line_in_file){
					$first_line_in_file = 0;
					if ($line1){
						#if ($line1 =~ /^@/){  # fastq reads begin with a header line that begins with @
						#	$read_format = "fastq";
						#}
						if ($line1 =~ /\d+\t\d+\t\d+/){ # qseq lines have several nums separated by tabs.
							$read_format = "qseq";
						}
						else{
							$read_format = "fastq";
						}
						#else {
						#	die "ERROR (reading the first line from the file $input_filepath):\n\tRead format".
						#	    " is neither fastq (line doesn't start with @) nor qseq (line doesn't have multiple nums sep.ed by tabs.\n";
						#}
					}
				}# end if $first_line_in_file
			
			if ($read_format eq "fastq") {
				$line2 = <$IN>;
				$line3 = <$IN>;		
				$line4 = <$IN>;
				
				if (!($line1 && $line2 && $line3 && $line4)){
					print "Thread \#$thread_num has reached EOF\n" if !$one_thread;
					$done = 1;
				}
				else{# if not EOF
					chomp ($line1); chomp ($line2); chomp ($line3); chomp ($line4);
					
					$read = new single_fQ_read(
								_header => $line1,
								_seq    => $line2,
								_comment => $line3,
								_qual =>   $line4,
								_min_rl => $min_read_length,
								_ascii_zero => $ASCII_of_zero_qual_score
							 );
				}
			}# end if ($read_format eq "fastq") {
			else { # elsif ($read_format eq "qseq") {
				if (!($line1)){
					print "\nThread \#$thread_num has reached EOF\n" if !$one_thread;
					$done = 1;
				}
				else{
					chomp ($line1);
					$read = get_single_fQ_read_from_qseq($line1,$min_read_length,$ASCII_of_zero_qual_score, $qseq_dot_to_N);
				}
			}	
			
			if (!$done){	
				# Update Thread read count
				$thread_read_count  += 1; 
				$thread_base_count += ($read->get_length);
		
				my @array = ($read);
				my $single_reads_set = new fQ_array(_arr_ref => \@array);
		
				
				
				&process_SE_read ( 
					$single_reads_set, 
				# Main parameters
					$mode, $method_sequence_arr_ref, $min_read_length, $print_discarded_reads_flag,
					$header_tag,
	
				# Method Parameters and trimmed base/read/pair counter references
				 # SE_ThreeEnd
					$n_threeEnd, \$num_bases_trimmed_by_ThreeEnd, \$num_reads_trimmed_by_ThreeEnd,
				 # SE_FiveEnd
					$n_fiveEnd,\$num_bases_trimmed_by_FiveEnd, \$num_reads_trimmed_by_FiveEnd,
				 # SE_five_prime_adpt
					$five_prime_r_adpt_arr_ref, 
					$match_percentage, $furthest_allowed_index_for_adapter_match, 
					$adpt_action, \$num_adpt_trimmed_bases,
					\$num_adpt_trimmed_reads, $adpt_max_match_len_diff,
					\$num_detected_adapter_sequences, $num_inss, $num_dels, $num_subs,
				 # SE_LQR
					$LQS_cutoff, $QPerc_cutoff,\$number_of_LQR_trimmed_bases, \$number_of_LQR_trimmed_reads,
				 # SE_Mott
					$mott_limit,\$num_mott_trimmed_bases, \$num_mott_trimmed_reads,
				 # SE_Ncutoff
					$N_cutoff, 
					\$num_bases_trimmed_by_Ncuotff, \$num_reads_trimmed_by_Ncuotff,
				 # SE_NPerc
					$Nperc_cutoff, 
					\$num_bases_trimmed_by_Nperc, \$num_reads_trimmed_by_Nperc,
				 # SE_Nsplit
					$nsplit_n_cutoff, \$num_of_removed_bases_using_Nsplit, \$num_of_removed_N_blocks,
					\$num_of_Nsplit_removed_reads, 
				 # qseq0
					\$num_bases_trimmed_by_qseq0, \$num_reads_trimmed_by_qseq0, 
				 # qseqB
					$B_num_cutoff, $qB_mode, $action, \$num_bases_trimmed_by_qseqB,
					\$num_reads_trimmed_by_qseqB,
				 # TERA
					$avg_cutoff, \$num_TERA_trimmed_bases,\$num_TERA_trimmed_reads,
				
				# rmHP
						$rmHP_min_length, $rmHP_bases_arr_ref, \$num_rmHP_trimmed_bases,\$num_rmHP_trimmed_reads,
					
				# Filehandles
					$trimmed_reads_fH, $five_prime_extracted_adpt_fH, $discarded_reads_fH
				);
				
				# skip by a step size of n_children * 4
				for (my $i =0; $i< (($num_threads -1) * $num_lines_per_read); $i++){
					$line = <$IN>;
				}
				
			}# end if !done						
		}# end while
		
	# 7. Print your count results
		print $counts_fH  "$thread_read_count,$thread_base_count,"
						 ."$num_bases_trimmed_by_ThreeEnd,$num_reads_trimmed_by_ThreeEnd,$num_bases_trimmed_by_FiveEnd,$num_reads_trimmed_by_FiveEnd,"
						 ."$num_adpt_trimmed_bases,$num_adpt_trimmed_reads,$num_detected_adapter_sequences,$number_of_LQR_trimmed_bases,"
						 ."$number_of_LQR_trimmed_reads,$num_mott_trimmed_bases,$num_mott_trimmed_reads,"
						 ."$num_bases_trimmed_by_Ncuotff,$num_reads_trimmed_by_Ncuotff,$num_bases_trimmed_by_Nperc,$num_reads_trimmed_by_Nperc,"
						 ."$num_of_removed_bases_using_Nsplit,$num_of_removed_N_blocks,$num_of_Nsplit_removed_reads,"
						 ."$num_bases_trimmed_by_qseq0,$num_reads_trimmed_by_qseq0,$num_bases_trimmed_by_qseqB,"
						 ."$num_reads_trimmed_by_qseqB,$num_TERA_trimmed_bases,$num_TERA_trimmed_reads,"
						 ."$num_rmHP_trimmed_bases,$num_rmHP_trimmed_reads"
						 ."\n";
	
    # 8. Close the filehandles
		close $IN;
		close $counts_fH;
		if ($mode eq "trim") {close $trimmed_reads_fH;}
		if ($methods_include_5adpt){close $five_prime_extracted_adpt_fH;}
		if ($print_discarded_reads_flag){close $discarded_reads_fH;}
		
}# end sub process_file_section
