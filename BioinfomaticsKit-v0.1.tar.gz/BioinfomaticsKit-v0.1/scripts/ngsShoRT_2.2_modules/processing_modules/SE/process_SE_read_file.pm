package process_SE_read_file;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(process_SE_read_file);

use strict;
use warnings;
use threads;

# Read classes
use single_fQ_read 1.0;
use PE_fQ_pair 1.0;
use fQ_array 1.0;


# Processing modules
use extract_5adpt_sequences 1.0;
use process_SE_file_section 1.0;
use merge_thread_output 1.0;
use print_params_and_get_filehandles_for_process_SE_files 1.0;

# Report module
use print_final_SE_report 1.0;


=head1 NAME

 process_SE_read_file : a subroutine that applies ngsShoRT trimming to a single
 read file to produce:
  - a trimmed_SE_file(if mode = trim)
  - discarded reads file (optional) for reads that failed trimming and were thus
    discarded from the final trimmed output
  - log file: contains the commandline and the values of every parameter used for
    this specific trimming job
  - report file: contains the text from the log file AND final counts of bases and
    reads trimmed (or that would be trimmed, if mode = report) by ngsShoRT and
    its methods.
  - extracted 5' adapter sequences (only if -methods include 5adpt).
	
=head1 SYNOPSIS

&process_SE_read_file(
                $commandline,$num_threads, $read_format,
		
		$mode, 
		$method_sequence_arr_ref, 
		$input_filepath,          
		$output_dir,              
		$print_discarded_reads,   
		$qseq_dot_to_N,$header_tag,
		
		# Main parameters
		$min_read_length, 
		$ASCII_of_zero_qual_score, 
		
		# Method Parameters and trimmed base/read/pair counter references
		 # SE_ThreeEnd, SE_FiveEnd, TERA
		  $n_threeEnd, $n_fiveEnd, $avg_cutoff,
		 # SE_five_prime_adpt
		  $five_prime_adapter_filepath, 
		  $match_percentage, $furthest_allowed_index_for_adapter_match, 
		  $adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
		 # SE_LQR
		  $LQS_cutoff, $QPerc_cutoff,
		 # SE_Mott
		  $mott_limit,
		 # SE_Ncutoff, SE_NPerc, SE_Nsplit
		  $N_cutoff, $Nperc_cutoff, $nsplit_n_cutoff, 
		 # qseqB
		  $B_num_cutoff, $qB_mode, $action
		  );
	
=head1 I/O 

=head2 Input parameter details

 See the initialization syntax " my ( ...) = @_" below; each parameter is followed
 by a comment explaining its function.

=head2 Output 
 
 See section VI of the advanced manual (/manuals/advanced_manual.pdf) for details
 on output files. 
 
  Note that these files are the results of merging the temporary outputs of multiple
 threads, each running an instance of process_SE_file_section on a separate section
 of the input SE file. For more detail on how this is done, see the advanced_manual
 or the documenation for process_SE_file_section.pm

=head1 Under the hood: Multithreading

  ngsShoRT offers multithreading to speed up trimming. mulithreading is done in an
 embarassingly parallel fashion where each thread parses a separate section of the
 input file, producing its own ouput files (trimmed_reads.fastq, discarded_reads.fastq,
 and counts.txt).
 
 When all threads are done trimming, the Master thread merges the outputs of the threads
 in an ordered fashion and sums their trimming counts to create the final_report.
 
 Here's how it's done:
 ---------------------
  - N threads are created inside process_single_read_file.
  - Each thread is assigned a number between 0 and N-1.
  - Each thread runs an instance of process_SE_file_section, and: 
     - Each thread starts parsing the input file at the read corresponding to its number,
       so thread 0 starts parsing at the 0th read, thread 2 starts parsing at the 2nd
	   read, and so on.
     - When done parsing a read, the thread jumps to its next read, which is N reads
       away.
     - The output (trimmed_reads.fastq, counts.txt, and the optional discarded_reads.fastq)
       of all threads is saved in a temporary directory, temp_dir. To separate and order the
	   output of each thread, its output files are prefixed with its number.
	   
   So, if N = 2, we have two threads numbered 0 and 1. Thread #0 parses reads (0,2,4,..) and
   Thread #1 parses reads (1,3,5,..). When both threads are done parsing the input file and
   trimming, temp_dir/ will contain the following files:
      0.trimmed_reads.fastq
      0.counts.txt
      1.trimmed_reads.fastq
      1.counts.txt	  
    
   process_single_read_file then calls merge_thread_output::merge_output to merge the output
   files (except counts.txt) of the threads to produce the final output files. Next,
   it parses the counts.txt files and sums the counts of each thread into the final
   counts, which are passed to print_final_SE_report::print_final_SE_report to print
   the report for this job. Finally, temp_dir is removed.
   
   To see how individual read trimming output is modified to allow for merging reads,
   see the documentation for process_PE_files_section.pm and process_PE_read_pair.pm

=head1 AUTHOR

 Sari Khaleel (skhaleel at udel.edu)
 Last modified on 1-26-2012
 
=cut


sub process_SE_read_file{

#---------------------------------------------------------------------------------------	
# A. GET PARAMETERS
#---------------------------------------------------------------------------------------
	my (
		$commandline,
		$num_threads, $read_format, $gzip,
		
		$mode, #mode is trim (produce trimmed file, along with other files), or report (do not produce a trimmed file)
		$method_sequence_arr_ref, # The ordered sequence of methods to be applied
		$input_filepath,          # The path of the input file
		$output_dir,                # The output directory where the log file
		$print_discarded_reads,           # yes|no
		$qseq_dot_to_N,$header_tag,
		
		# Main parameters
		$min_read_length, #min_read_length is the minimum allowed size for a read to be included in the trimmed file or surviving mates
		$ASCII_of_zero_qual_score, #ASCII_of_zero_qual_score is the ASCII value of a zero quality score (64 for Illumina, 33 for Sanger)
		
		# Method Parameters and trimmed base/read/pair counter references
		 # SE_ThreeEnd, SE_FiveEnd, TERA
		  $n_threeEnd, $n_fiveEnd, $avg_cutoff,
		 # SE_five_prime_adpt
		  $five_prime_adapter_filepath, 
		  $match_percentage, $furthest_allowed_index_for_adapter_match, 
		  $adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
		 # SE_LQR
		  $LQS_cutoff, $QPerc_cutoff,
		 # SE_Mott
		  $mott_limit,
		 # SE_Ncutoff, SE_NPerc, SE_Nsplit
		  $N_cutoff, $Nperc_cutoff, $nsplit_n_cutoff, 
		 # qseqB
		  $B_num_cutoff, $qB_mode, $action,
		  
		 # rmHP
		  $rmHP_min_length, $rmHP_bases_string
		  ) = @_;
		
	my @rmHP_bases  = split //, $rmHP_bases_string;
	my $one_thread = ($num_threads == 1);

#---------------------------------------------------------------------------------------
# B. START PRINTING THE LOG AND THE PARAMS TEXT	
#---------------------------------------------------------------------------------------
	my $log_filepath  = $output_dir."/log.txt";
	my $log_fh;
	open ($log_fh,         ">", $log_filepath     ) ; # or die "failed to open/create $log_filepath from the module process_SE_file\n";
	
	
	my $concated_methods = join '__', @$method_sequence_arr_ref;

	# Print (to STDOUT and log_fh) the commandline and the values of all parameters
	# used for trimming this file, and return this data as a string ($specific_params)
	# that will be used in the final_report.
		my $specific_params = &get_params_string(
							$commandline,$num_threads, $read_format,
						 $mode,$method_sequence_arr_ref, 
						 $input_filepath, $output_dir,  
			    			 $print_discarded_reads, $qseq_dot_to_N,
						 $min_read_length, $ASCII_of_zero_qual_score, 
		 				 $n_threeEnd, $n_fiveEnd, $avg_cutoff,
		 				 $five_prime_adapter_filepath, 
		  				 $match_percentage, $furthest_allowed_index_for_adapter_match, 
		 				 $adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
		  				 $LQS_cutoff, $QPerc_cutoff,
		 				 $mott_limit,
						 $N_cutoff, $Nperc_cutoff, $nsplit_n_cutoff, 
						 $B_num_cutoff, $qB_mode, $action,
						 $rmHP_min_length, $rmHP_bases_string,
						 
						 $concated_methods
							);
	
	my $methods_include_qseq0 = 0; 
	if ($concated_methods =~ /qseq0/){
		$methods_include_qseq0 = 1;
	}
	
	 print $specific_params;
	 print $log_fh $specific_params;

#---------------------------------------------------------------------------------------
# C. CREATE (NAME) AND OPEN TRIMMED, DISCARDED READS FILE PATHS
#---------------------------------------------------------------------------------------
	# Programmer's note: I commented out all the "or die .." lines below because of a problem with our server
	
	# Call &get_filehandles_and_print_paths_to_log to
	# 	1. Get output file handles
	#	2. Load the output file paths to $paths (which will be used for the final report), and
	#   3. Print these paths to log_fh and STDOUT
		my $paths;
		my ($trimmed_reads_fh, $report_fh,$discarded_reads_fh,$output_filepath, $discarded_reads_filepath) = @{&get_filehandles_and_print_paths_to_log(
																										  $output_dir, $input_filepath,
																										  $print_discarded_reads, $mode,
																										  $log_fh,$log_filepath, \$paths, $gzip
																										  )};
     #die "$output_filepath, $discarded_reads_filepath";
	 
#---------------------------------------------------------------------------------------
# D. EXTRACT ADAPTER SEQUENCES FROM THE ADAPTERS FILE, LOAD THEM INTO ARRAYS, OPEN THE EXTRACTED SEQS FILEHANDLE
#---------------------------------------------------------------------------------------
	my $five_prime_adapter_sequences_list_string ;
	# Extract five_prime_adapter_file lines into an array,
	# and open extracted adapter file handle
	my ($five_prime_extracted_adpt_fh, @five_prime_r_adpt);
	
	# Do this only if method_sequence includes adpt
	my $methods_include_5adpt = 0;
	foreach (@$method_sequence_arr_ref){
		if ($_ eq "5adpt") {$methods_include_5adpt = 1;}
	}
	# open the extracted_adapter_seqs_file_path, 
	# Extract adapter seq lines from the adapter sequences file
	my $five_prime_extracted_adapter_seqs_filepath;
	if ($methods_include_5adpt){
		# Check that the adapter file exists
		if (! -e $five_prime_adapter_filepath){
			die "five_prime adapter file not found !";
		}
		
		$five_prime_extracted_adapter_seqs_filepath = $output_dir."/extracted_five_prime_adapter_sequences_at_".$match_percentage."_percent_match.txt";
		open ($five_prime_extracted_adpt_fh, ">", $five_prime_extracted_adapter_seqs_filepath); # or die;
		
		# Extract adapter_file lines into an array		
			$five_prime_adapter_sequences_list_string = &extract_5adpt_sequences_to_arrays_and_print_header($five_prime_adapter_filepath,
																		   \@five_prime_r_adpt,
																		   "", # for process_PE_files, this is the entry for \@five_prime_r2_adpt
																		   $five_prime_extracted_adapter_seqs_filepath);
			print $five_prime_adapter_sequences_list_string;
			print $five_prime_extracted_adpt_fh $five_prime_adapter_sequences_list_string;
			print $log_fh $five_prime_adapter_sequences_list_string;
	}


#---------------------------------------------------------------------------------------
# E. PARSE INPUT FILE USING THREADS
#---------------------------------------------------------------------------------------
	# 0. Set start date stamp
		my $start_all_time = time();
	
	# 1. Create the threads
		my $temp_out_dir = "$output_dir/temp";
		if (! -e $temp_out_dir){system ("mkdir $temp_out_dir");}
		die "ERROR (Process_single_read_file): Failed to create temporary output directory for threads at $temp_out_dir!\n" if (! -e $temp_out_dir); 
		
		my @jobs; 
		for(my $thread_num=0; $thread_num<$num_threads; $thread_num++){
			push @jobs, threads->create(\&process_SE_file_section, $thread_num, $num_threads, $read_format,
										# FilePaths
											$input_filepath, $output_dir,
										
										# Main params
											$methods_include_qseq0, $methods_include_5adpt,
											$mode, $method_sequence_arr_ref, $min_read_length, 
											$ASCII_of_zero_qual_score, $qseq_dot_to_N, $print_discarded_reads,
											$header_tag,
										
										# Method params
											# PE_ThreeEnd, PE_FiveEnd
												$n_threeEnd,$n_fiveEnd,
											# PE_five_prime_adpt
												\@five_prime_r_adpt,
												$match_percentage, $furthest_allowed_index_for_adapter_match, 
												$adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
											# PE_LQR
												$LQS_cutoff, $QPerc_cutoff,
											# PE_Mott, PE_Ncutoff, PE_NPerc, PE_Nsplit
												$mott_limit, $N_cutoff, $Nperc_cutoff,$nsplit_n_cutoff, 
											# qseqB
												$B_num_cutoff, $qB_mode, $action, 
											# TERA
												$avg_cutoff,
											# rmHP
											  $rmHP_min_length, \@rmHP_bases
										);
		}# end for
		
	# 2. Join the threads
		$_->join for @jobs;
	
	# 3. Print the EOF message
		my $end_threads_time = time();
		my $threads_runtime_in_mins = sprintf("%.3f", (($end_threads_time - $start_all_time)/60));
		print "\nAll threads have reached EOF and are done trimming their file sections within $threads_runtime_in_mins minutes.\n" if !$one_thread ;

		print $log_fh "\nReached EOF\n";
		
	
	# 4. Merge the counts into ONE
		# a. Go thru each threads counts line, and add it to the counters
			my @total_counts;
			
			for(my $thread_num=0; $thread_num<$num_threads; $thread_num++){
				open COUNT, "< $temp_out_dir/$thread_num.counts.txt";
				chomp (my $line = <COUNT>);

				my @section_counts = split /,/, $line;
				#print "sectionCounts: @section_counts\n";
				for (my $i= 0; $i < scalar(@section_counts); $i++){
					if ($total_counts[$i]){
						$total_counts[$i] += $section_counts[$i];
					}
					else {push @total_counts, $section_counts[$i];}
				}
				close COUNT;
			}
		#die "totalCounts  : @total_counts\n";
	
		# b. Create counters from this array
			my 	(
			# Read count
				$total_read_count,$total_bases_count,
			# Three End, FiveEnd counters
				$num_bases_trimmed_by_ThreeEnd,$num_reads_trimmed_by_ThreeEnd,$num_bases_trimmed_by_FiveEnd,
				$num_reads_trimmed_by_FiveEnd,
			# 5adpt counters
				$num_adpt_trimmed_bases,$num_adpt_trimmed_reads,$num_detected_adapter_sequences,
			# LQR counters
				$number_of_LQR_trimmed_bases,$number_of_LQR_trimmed_reads,
			# Mott, Ncutoff counters
				$num_mott_trimmed_bases,$num_mott_trimmed_reads,
				$num_bases_trimmed_by_Ncuotff,$num_reads_trimmed_by_Ncuotff,
			# Nperc, Nsplit, qseq0, qseqB, and TERA counters
				$num_bases_trimmed_by_Nperc,$num_reads_trimmed_by_Nperc,
				$num_of_removed_bases_using_Nsplit,$num_of_removed_N_blocks,$num_of_Nsplit_removed_reads,
				$num_bases_trimmed_by_qseq0,$num_reads_trimmed_by_qseq0,
				$num_bases_trimmed_by_qseqB, $num_reads_trimmed_by_qseqB,
				$num_TERA_trimmed_bases,$num_TERA_trimmed_reads,
				$num_rmHP_trimmed_bases,$num_rmHP_trimmed_reads
			) = @total_counts;
	
	# 5. Merge the temp files
		my $start_merging_time = time();
		print "\nMerging temp files (thread outputs) into single final files ..\n" if !$one_thread;
		
		if ($mode eq "trim") {
			&merge_output($temp_out_dir, "trimmed_reads.fastq", $trimmed_reads_fh, $num_threads, $gzip,$output_filepath);
		}
		if ($methods_include_5adpt)	{
			&merge_output($temp_out_dir,"extracted_5adpt_seqs.txt", $five_prime_extracted_adpt_fh, $num_threads);
		}
		if ($print_discarded_reads eq "yes"){
			&merge_output($temp_out_dir,"discarded_reads.fastq", $discarded_reads_fh, $num_threads, $gzip,$discarded_reads_filepath);
		}
		
		my $end_merging_time = time();
		my $merging_time_in_mins = sprintf("%.3f", (($end_merging_time - $start_merging_time)/60));
			
		print "\nDone merging. Deleting temp files (thread outputs) ..\n" if !$one_thread;
		system("rm -r $temp_out_dir");
		
		
	# 6. Print Final Report
		my $end_all_time = time();
		my $all_runtime_in_mins = sprintf("%.3f", (($end_all_time - $start_all_time)/60));
	
		my $date_stamps = "\n\nDONE.\nTrimming started at ".gmtime($start_all_time)." ,\nTrimming ended   at ".gmtime($end_all_time).".\n";
		$date_stamps .= "Total runtime = $all_runtime_in_mins mins.\nThreads runtime = $threads_runtime_in_mins mins.\nMerging runtime = $merging_time_in_mins min.\n\n";
		print $log_fh $date_stamps;
		print $date_stamps;
		
		&print_final_SE_report(
							$date_stamps,$total_read_count,$total_bases_count,
							$specific_params, $paths, $five_prime_adapter_sequences_list_string,
							# Main parameters
							$report_fh,
							$mode, $input_filepath, $output_dir, $method_sequence_arr_ref, $min_read_length, 
							$ASCII_of_zero_qual_score,
			
				 # Method Parameters
						# SE_ThreeEnd, SE_FiveEnd, TERA
							 $n_threeEnd, $n_fiveEnd, $avg_cutoff,
							# SE_five_prime_adpt
							 $five_prime_adapter_filepath, 
							 $match_percentage, $furthest_allowed_index_for_adapter_match, 
							 $adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
							# SE_LQR
							 $LQS_cutoff, $QPerc_cutoff,
							# SE_Mott
							 $mott_limit,
							# SE_Ncutoff, SE_NPerc, SE_Nsplit
							 $N_cutoff, $Nperc_cutoff, $nsplit_n_cutoff, 
							# qseqB
							 $B_num_cutoff, $qB_mode, $action,
					 # Method counters 
						# SE_ThreeEnd
						 $num_bases_trimmed_by_ThreeEnd, $num_reads_trimmed_by_ThreeEnd, 
						# SE_FiveEnd
						 $num_bases_trimmed_by_FiveEnd, $num_reads_trimmed_by_FiveEnd,
						# SE_five_prime_adpt
						 $num_adpt_trimmed_bases,$num_adpt_trimmed_reads, $num_detected_adapter_sequences, 
						# SE_LQR
						 $number_of_LQR_trimmed_bases, $number_of_LQR_trimmed_reads,
						# SE_Mott
						 $num_mott_trimmed_bases, $num_mott_trimmed_reads,
						# SE_Ncutoff
						 $num_bases_trimmed_by_Ncuotff, $num_reads_trimmed_by_Ncuotff,
						# SE_NPerc
						 $num_bases_trimmed_by_Nperc, $num_reads_trimmed_by_Nperc,
						# SE_Nsplit
						 $num_of_removed_bases_using_Nsplit, $num_of_removed_N_blocks,$num_of_Nsplit_removed_reads, 
						# qseq0
						 $num_bases_trimmed_by_qseq0, $num_reads_trimmed_by_qseq0, 
						# qseqB
						 $num_bases_trimmed_by_qseqB, $num_reads_trimmed_by_qseqB, 
						# TERA
						 $num_TERA_trimmed_bases,$num_TERA_trimmed_reads,
						# rmHP
						  $num_rmHP_trimmed_bases,$num_rmHP_trimmed_reads
						);
	
		
	# 7. close the filehandles
		close $log_fh;
		if ($methods_include_5adpt){
			close $five_prime_extracted_adpt_fh;
		}
		
		close $report_fh;
	
		if ($mode eq "trim"){
			close $trimmed_reads_fh;
			if ($discarded_reads_fh){
				close $discarded_reads_fh;
			}
		}
		
}# end process single read file
