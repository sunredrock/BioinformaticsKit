package print_params_and_get_filehandles_for_process_SE_files;
use Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(get_params_string get_filehandles_and_print_paths_to_log);

use strict;
use warnings;


=head1 NAME

  print_params_and_get_filehandles_for_process_SE_files : a simple module with two
  subroutines used by process_single_read_file.pm.

=head1 SYNOPSIS

=head2 get_params_string

 This subroutine takes the parameters of process_single_read_file and returns them
 in an organized fashion along with their method names, etc, in one string.
 
 my $specific_params = &get_params_string(
				$commandline,$num_threads, $read_format,
			 $mode,$method_sequence_arr_ref, 
			 $input_filepath, $output_dir,  
				 $print_discarded_reads, $qseq_dot_to_N,
			 $min_read_length, $ASCII_of_zero_qual_score, 
			 $n_threeEnd, $n_fiveEnd, $avg_cutoff,
			 $five_prime_adapter_filepath, 
			 $match_percentage, $furthest_allowed_index_for_adapter_match, 
			 $adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
			 $LQS_cutoff, $QPerc_cutoff,
			 $mott_limit,
			 $N_cutoff, $Nperc_cutoff, $nsplit_n_cutoff, 
			 $B_num_cutoff, $qB_mode, $action,$concated_methods
							);
							
=head2 get_filehandles_and_print_paths_to_log

 my $paths;
 my ($trimmed_reads_fh, $report_fh,$discarded_reads_fh) =
 	@{&get_filehandles_and_print_paths_to_log(
 					$output_dir, $input_filepath,
 					$print_discarded_reads, $mode,
 					$log_fh,$log_filepath, \$paths
 	 )
 	};
 
 This subroutine creates output_file handles and returns an array reference to them. It
 will also load the output_file paths into the referenced string, $paths.
 
 Algorithm breakdown:
 1. If mode = trim, create the trimmed_reads.fastq file and open a filehandle to it.
 2. If mode = trim AND print_discarded_reads flag = 1, create the discarded_reads.fastq
    file and open a filehandle to it.
 3. Create the report filepath and open a filehandle to it.
 4. Print these created paths to STDOUT and log_fh, and load them into \$paths string,
    which is passed from process_single_read_file to be used later by print_final_SE_report.
 5. Return the filehandle values
 
=cut

sub get_params_string{
	my (
		$commandline,$num_threads, $read_format,
		
		$mode,$method_sequence_arr_ref, 
		$input_filepath, $output_dir,  
		$print_discarded_reads, $qseq_dot_to_N,
		
		# Main parameters
		$min_read_length, $ASCII_of_zero_qual_score, 
		
		# Method Parameters and trimmed base/read/pair counter references
		 # PE_ThreeEnd, PE_FiveEnd, TERA
		  $n_threeEnd, $n_fiveEnd, $avg_cutoff,
		 # PE_five_prime_adpt
		  $five_prime_adapter_filepath, 
		  $match_percentage, $furthest_allowed_index_for_adapter_match, 
		  $adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
		 # PE_LQR
		  $LQS_cutoff, $QPerc_cutoff,
		 # PE_Mott
		  $mott_limit,
		 # PE_Ncutoff, PE_NPerc, PE_Nsplit,# qseqB
		  $N_cutoff, $Nperc_cutoff, $nsplit_n_cutoff, 
		  $B_num_cutoff, $qB_mode, $action,
		  $rmHP_min_length, $rmHP_bases_string,
		  
		  $concated_methods
		  ) = @_;
		  
		my $specific_params = <<PARAMS;
	
	Commandline : $commandline
	number of threads: $num_threads
	
	Specified parameters:
	--------------------
		  mode: $mode
		  method_sequence: @$method_sequence_arr_ref
		  
		  Single Reads File: $input_filepath
		  output_dir : $output_dir
                  print_discarded_reads: $print_discarded_reads           	
	
	Main parameters:
	----------------
		  minimum read length* : $min_read_length
		  ASCII of zero quality score: $ASCII_of_zero_qual_score
		  
		  * minimum read length is the cutoff for read length to be included
		  in the trimmed file. It's also the limit on how far TERA, 3end, 5end,
		  and Mott trimming are allowed to go into a read. See quick_manual for
		  more details.
PARAMS

	if ($concated_methods =~ /nperc/){
		$specific_params .= "
		Trimming Ambiguous (High perc of N/. base) reads:
		--------------------------------------------------
		  Cutoff Percentage of N bases in a read: $Nperc_cutoff %
	";
	}	
	 
	if ($concated_methods =~ /lqr/){
		$specific_params .= "
		Trimming Low quality reads: 
		---------------------------
		  Low quality (LQ) base score cutoff: $LQS_cutoff  
		  Cutoff percentage of LQ bases in a read: $QPerc_cutoff %
		";
	}
	
	if ($concated_methods =~ /tera/){
		$specific_params .= "
		TERA: Trimming bases from the 3' end based on their running average quality score:
		----------------------------------------------------------------------------------
		  3' end average cutoff: $avg_cutoff
		  ";
	}
	
	if ($concated_methods =~ /5adpt/){
		$specific_params .= "
		Trimming 5' (Illumina) adapter sequences:
		--------------------------------------
		  adapter sequence filepath: $five_prime_adapter_filepath  
		  adapter action: $adpt_action (kr = kill read, ka = kill after matched sequence)
		  match percentage: $match_percentage 
		  furthest allowed index for adapter match: $furthest_allowed_index_for_adapter_match
		  Maximum allowed difference in length between adpt sequence and matched substring: $adpt_max_match_len_diff";
		
		if ($num_inss){
			$specific_params .= "
			Maximum number of allowed insertions = $num_inss\n";
		}
		if ($num_dels){
			$specific_params .= "
			Maximum number of allowed deletions = $num_dels\n";
		}
		if ($num_subs){
			$specific_params .= "
			Maximum number of allowed substitutions = $num_subs\n";
		}
	$specific_params .= "\n";
		
	}# end if ($concated_methods =~ /5adpt/){
	if ($concated_methods =~ /nsplit/){
		$specific_params .= "	
		Removing N-blocks (and splitting reads around them):
		----------------------------------------------------
		  cutoff_num_of_Ns: $nsplit_n_cutoff
	    ";
	}
	if ($concated_methods =~ /mott/){
		$specific_params .= "	
		Modified Mott Algorithm trimming of reads
		--------------------------------------
		  mott_limit : $mott_limit	  
	    "; 
	}
	if ($concated_methods =~ /ncutoff/){
		$specific_params .= "	
		Trimming Reads with >N_cutoff N/. bases
		--------------------------------------
		  N_cutoff : $N_cutoff	  
	    "; 
	}
	if ($concated_methods =~ /qseqB/){
		$specific_params .= "	
		Trimming 'B'-scored Illumina reads
		--------------------------------------
		  Cutoff number of B-scored bases : $B_num_cutoff
			Detection mode (global*/local): $qB_mode 
			Action on detection (ka=kill bases after, kr=kill read): $action
			
			*global works only with kr
	    "; 
	}
	if ($concated_methods =~ /3end/){
		if (!$n_threeEnd) {$n_threeEnd = "0";}
		$specific_params .= "	
		Trimming N bases from the 3' end: 
		---------------------------------
		  N : $n_threeEnd	  
	    "; 
	}
	if ($concated_methods =~ /5end/){
		if (!$n_fiveEnd) {$n_threeEnd = "0";}
		$specific_params .= "	
		Trimming N bases from the 5' end: 
		---------------------------------
		  N : $n_fiveEnd	  
	    ";
	}	
	
	if ($concated_methods =~ /rmHP/){	
		my @bases = split //, $rmHP_bases_string;
		my $comma_joined_bases = join ',', @bases;
		
		$specific_params .= "	
		Trimming homopolymers: 
		---------------------------------
		  minimum homopolymer length: $rmHP_min_length
		  homopolymers can be from these bases: $comma_joined_bases
	    "; 
	}
	
		
	return $specific_params;
}# end sub get_params_string

#------------------------------------------------------
sub get_filehandles_and_print_paths_to_log{
	my ($output_dir, $input_filepath,$print_discarded_reads, $mode, $log_fh,$log_filepath, $paths_ref, $gzip) = @_;
	
		my $open_fh_symbol = ">";
		if ($gzip){
			$gzip = ".gz";#$open_fh_symbol = ">:gzip";
		}
		else{
			$gzip = "";
		}
		
		#die $open_fh_symbol;
		
		my @input_fname_parts = split (/\//,$input_filepath); 
		my $output_file = $input_fname_parts[$#input_fname_parts];
		
		# If input file was suffixed w .zip, .gz, or bz2, remove these suffixes from output filename
				$output_file =~ s/\.zip$//i;
				$output_file =~ s/\.gz$//i;
				$output_file =~ s/\.bz2$//i;
				
				
		my ($discarded_reads_filepath);
		if ($print_discarded_reads eq "yes"){
			$discarded_reads_filepath = $output_dir."/discarded_reads_in_".$input_fname_parts[$#input_fname_parts].$gzip;
		}
		
		
		my ($output_filepath);
		if ($input_filepath !~ /trimmed/){
			$output_filepath = $output_dir."/trimmed_".$output_file.$gzip;
		}
		else{
			$output_filepath = $output_dir."/".$output_file.$gzip;
		}	
		
		my $report_filepath = $output_dir."/final_SE_report.txt";
		
	# Print out these paths
		my $paths;		
		print "\n";
		if ($mode eq "trim") {
		
		$paths = "
		Output files :
		-------------
			trimmed file : $output_filepath
			report file   : $report_filepath
			log file      : $log_filepath\n";
		}
		else {
			$paths = "
		Output files :
		-------------
			report file   : $report_filepath
			log file      : $log_filepath\n";
		}
		if ($discarded_reads_filepath){
			$paths .="			discarded_reads file: $discarded_reads_filepath";
		}
		$paths .="\n";
		print $paths;
		print $log_fh $paths;
		$$paths_ref = $paths;
	
	# Open the filehandles
		my ($trimmed_reads_fh, $report_fh, $discarded_reads_fh);	# Open the trimmed file ONLY if mode = trim
		
		if ($mode eq "trim"){
			open ($trimmed_reads_fh,  $open_fh_symbol, $output_filepath ) or die "failed to open/create $output_filepath from the module process_SE_file.\nMake sure that your output directory path is valid!\n\n";
			
			if ($print_discarded_reads eq "yes"){
				open $discarded_reads_fh, $open_fh_symbol, $discarded_reads_filepath;
			}
		
		}
		
		open ($report_fh,  ">", $report_filepath  ) or die "failed to open/create $report_filepath from the module process_SE_file.\nMake sure that your output directory path is valid!\n\n";
		
	# Return the new filehandles
		my @filehandles= ($trimmed_reads_fh, $report_fh,$discarded_reads_fh,$output_filepath, $discarded_reads_filepath);
		return \@filehandles;

}# end sub get_filehandles_and_print_paths_to_log