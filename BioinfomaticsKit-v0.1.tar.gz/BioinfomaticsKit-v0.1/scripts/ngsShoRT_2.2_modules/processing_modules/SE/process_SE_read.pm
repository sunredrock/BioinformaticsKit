package process_SE_read;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(process_SE_read);

use strict;
use warnings;

# Read classes
use single_fQ_read 1.0;
use fQ_array 1.0;

# Trimming modules
use five_prime_adpt 1.0 ;
use FiveEnd 1.0 ;
use LQR 1.0 ;
use Mott 1.0;
use Ncutoff 1.0;
use NPerc 1.0;
use Nsplit;
use qseq0 1.0;
use qseqB 1.0;
use TERA 1.0;
use ThreeEnd 1.0;
use rmHP 1.0;

=head1 I. NAME
  
  process_SE_read: a module for trimming the sequence and quality score lines of
  a single_fQ_read object using the specified ngsShoRT methods and their parameters.
  

=head1 II. SYNOPSIS

=head2 II.1 Calling and output

 The following call is made from process_SE_file_section, which parses its designated
 section of the SE file (see process_SE_file_section.pm documentation), trimming one read
 at a time. Once a single_fQ_read object is created for the next read, it is put
 inside an fQ_array object called single_reads_set and is passed to process_single_read
 along with @methods (the ordered list of methods to run on the read), method parameters,
 and references to trimming counters and the output filehandles.

  &process_SE_read ( 
		$single_reads_set, 
		# Main parameters
			$mode, $method_sequence_arr_ref, $min_read_length, $print_discarded_reads_flag,
			$header_tag,

		# Method Parameters and trimmed base/read/pair counter references
		 # SE_ThreeEnd
			$n_threeEnd, \$num_bases_trimmed_by_ThreeEnd, \$num_reads_trimmed_by_ThreeEnd,
		 # SE_FiveEnd
			$n_fiveEnd,\$num_bases_trimmed_by_FiveEnd, \$num_reads_trimmed_by_FiveEnd,
		 # SE_five_prime_adpt
			$five_prime_r_adpt_arr_ref, 
			$match_percentage, $furthest_allowed_index_for_adapter_match, 
			$adpt_action, \$num_adpt_trimmed_bases,
			\$num_adpt_trimmed_reads, $adpt_max_match_len_diff,
			\$num_detected_adapter_sequences, $num_inss, $num_dels, $num_subs,
		 # SE_LQR
			$LQS_cutoff, $QPerc_cutoff,\$number_of_LQR_trimmed_bases, \$number_of_LQR_trimmed_reads,
		 # SE_Mott
			$mott_limit,\$num_mott_trimmed_bases, \$num_mott_trimmed_reads,
		 # SE_Ncutoff
			$N_cutoff, 
			\$num_bases_trimmed_by_Ncuotff, \$num_reads_trimmed_by_Ncuotff,
		 # SE_NPerc
			$Nperc_cutoff, 
			\$num_bases_trimmed_by_Nperc, \$num_reads_trimmed_by_Nperc,
		 # SE_Nsplit
			$nsplit_n_cutoff, \$num_of_removed_bases_using_Nsplit, \$num_of_removed_N_blocks,
			\$num_of_Nsplit_removed_reads, 
		 # qseq0
			\$num_bases_trimmed_by_qseq0, \$num_reads_trimmed_by_qseq0, 
		 # qseqB
			$B_num_cutoff, $qB_mode, $action, \$num_bases_trimmed_by_qseqB,
			\$num_reads_trimmed_by_qseqB,
		 # TERA
			$avg_cutoff, \$num_TERA_trimmed_bases,\$num_TERA_trimmed_reads,
			
		# Filehandles
			$trimmed_reads_fH, $five_prime_extracted_adpt_fH, $discarded_reads_fH
				);
	By the end of the call, the counters will be updated and the trimmed/killed read
	will be printed to trimmed_FH (if mode = trim AND the read is still good after
	all trimming methods), or to discarded_reads_FH (if print_discarded_reads yes AND
	the read is destroyed by one of the trimming methods).
	
				
=head2 II.2. Under the hood
 
 a. Trimming method calls and output
 -----------------------------------
 For every trimming method in the passed methods array, process_PE_read_pair calls the
 corresponding PE trimming subroutine, passing the PE_fQ_pair along with references
 to counter variables (passed to it from process_PE_files_section, which prints them,
 when reaching EOF, to counts.txt) 
 
 When a trimming method is done with the PE pair, process_PE_read_pair checks its
 status as described above. 

 b. Why enclose outputs (including null output) with '> >' and '< <' lines?
 ---------------------------------------------------------------------------
 Because of the multithreaded design of ngsShoRT, each process_SE_file_section will
 trim a different section of the file. Section outputs can be merged because of two
 things: prefixing each section with its (0-N) thread number, and enclosing every
 read's corresponding trimmed and discarded ouputs with > > and < < to indicate an
 entry. For more on that, see the documentation for process_SE_file section.pm and
 process_single_read_file.pm.

 c. Read Header modification
 ---------------------------
 By default, process_single_read will append "|Trimmed_by" to the read's header,
 and then append method names as it iteratively runs the methods in
 @$method_sequence_arr_ref on the read. So, if @methods = (5adpt, 3end, tera),
 then by the end of trimming, the read should have "|Trimmed_by_5adpt_3end_tera"
 appended to its header, unless the read was killed/skipped/rendered too short
 by a method. In this case, header modification will be different -- see below.
 
 d. Discarded reads
 ------------------
 Before trimming a read, process_single_read creates an "unchanged_read" copy of
 this read. Like the read, unchanged_read will have its header modified (appending
 the next method), but its sequence is NOT trimmed. If the read gets killed/skipped/
 rendered shorter than min_rl before the end of trimming, then process_single_read
 will print out the unchanged_read to discarded_reads_FH (if $print_discarded_reads_flag,
 passed as input from process_SE_file_section, is defined, which only if the user
 specified -printed_discarded_reads yes). So, the user can see the raw read
 and in its header, the sequence of methods that led to its removal.
 
 E.g. @methods = 5adpt, lqr, 3end, and the read was "skipped" by lqr. The printed
 output in discarded_reads_FH will be:
 > >
 @READs_HEADER|Trimmed_by_5adpt_lqr
 UNCHANGED SEQUENCE LINE
 +
 UNCHANGED QUALITY LINE
 < <
 
 e. The nightmare called nsplit
 ------------------------------
 For all methods, process_SE_file_section will pass ONE single_fQ_read object, but
 it's inside an fQ_array object called single_reads_set. Why?

 The answer has to do with nsplit. nsplit is the ONLY method that splits a single
 read into potentially 2 reads, returning the result (1-2 reads) inside an fQ_array
 object. If splitting has indeed occured and two "good" daughter reads are created,
 the remaining methods in @methods have to be called on each of the daughter reads,
 and so process_single_read will put these reads into a new fQ_array and call itself
 on these reads with the remaining methods.
 
 Note that you can tell if a read in the trimmed file is a daughter read of nsplitting
 by its header: Since process_single_read was called again on the daughter read, it
 will have a new "|Trimmed_by_.." appended to its header.
 
 E.g.
 @methods = (5adpt, nsplit, 3end)
 current_method = 5adpt
 Parent read header: "@SE_1234|Trimmed_by_5adpt"
 -> Do 5adpt trimming
 
 current_method = nsplit 
 Parent read header: "@SE_1234|Trimmed_by_5adpt_nsplit"
 -> Do nsplit trimming
 -> You get two new daughter reads
 -> skip the parent read from being printed to trimmed_ or discarded_ FH
 -> Call process_single_read on each daughter read with @methods = (3end)
 
 @methods = 3end
 current_method = 3end
 Daughter read header: "@SE_1234|Trimmed_by_5adpt_nsplit|Trimmed_by_3end"
 -> Do 3end trimming
				
=cut


sub process_SE_read{
	my (# Read 
		  $single_reads_set, 
		# Main parameters
		  $mode, $method_sequence_arr_ref, $min_read_length,
		  $print_discarded_reads_flag, # is defined (1) only if the user specified
			                           # "-print_discarded_reads yes" in the commandline
		  $header_tag,
		
		# Method Parameters and trimmed base/read/pair counter references
		 # SE_ThreeEnd
		  $n_threeEnd, $num_bases_trimmed_by_ThreeEnd_ref, $num_reads_trimmed_by_ThreeEnd_ref,
		 # SE_FiveEnd
		  $n_fiveEnd,$num_bases_trimmed_by_FiveEnd_ref, $num_reads_trimmed_by_FiveEnd_ref,
		 # SE_five_prime_adpt
		  $adapter_seqs_array_R_ref,
		  $match_percentage, $furthest_allowed_index_for_adapter_match, 
		  $adpt_action, $num_adpt_trimmed_bases_ref,
			$num_adpt_trimmed_reads_ref, $adpt_max_match_len_diff,
		  $num_detected_adapter_sequences_ref, $num_inss, $num_dels, $num_subs,
		 # SE_LQR
		  $LQS_cutoff, $QPerc_cutoff,$number_of_LQR_trimmed_bases_ref, $number_of_LQR_trimmed_reads_ref,
		 # SE_Mott
		  $mott_limit,$num_mott_trimmed_bases_ref, $num_mott_trimmed_reads_ref,
		 # SE_Ncutoff
		  $N_cutoff, 
	    $num_bases_trimmed_by_Ncuotff_ref, $num_reads_trimmed_by_Ncuotff_ref,
		 # SE_NPerc
		  $Nperc_cutoff, 
	    $num_bases_trimmed_by_Nperc_ref, $num_reads_trimmed_by_Nperc_ref,
		 # SE_Nsplit
		  $nsplit_n_cutoff, $num_of_removed_bases_using_Nsplit_ref, $num_of_removed_N_blocks_ref,
			$num_of_Nsplit_removed_reads_ref, 
		 # qseq0
		  $num_bases_trimmed_by_qseq0_ref, $num_reads_trimmed_by_qseq0_ref, 
		 # qseqB
		  $B_num_cutoff, $qB_mode, $action, $num_bases_trimmed_by_qseqB_ref,
	    $num_reads_trimmed_by_qseqB_ref, 
		 # TERA
		  $avg_cutoff, $num_TERA_trimmed_bases_ref,$num_TERA_trimmed_reads_ref,
		# rmHP
			$rmHP_min_length, $rmHP_bases_arr_ref, $num_rmHP_trimmed_bases_ref,$num_rmHP_trimmed_reads_ref,
		  
		# Main Filehandles
		  $trimmed_reads_fH,  $five_prime_extracted_adpt_fH, $discarded_reads_fH
		) 
		= @_; 
	
	my @method_sequence = @$method_sequence_arr_ref;
	
	while (!($single_reads_set->is_empty)){
		my $read = $single_reads_set->pop;
		
		if ($header_tag && @method_sequence){
		# Add |trimmed_by_ to both reads
			$read->set_header(($read->get_header)."|Trimmed_by");
		}
		
		# Create a copy of the read that won't be changed. This copy is used only if the user wants to have
		# a bad reads file, which would contain the bad "unchanged" read with its new header (now contains
		# the name of the method sequence that killed it)
			my $unchanged_read = new single_fQ_read(
													_header  => $read->get_header,
													_seq     => $read->get_seq,
													_comment => $read->get_comment,
													_qual    => $read->get_qual,
													_min_rl  => $min_read_length,
													_qseq_filter => $read->get_qseq_filter,
													_ascii_zero  => $read->get_ascii_zero);
								
		my $skip_this_read = 0;
		# 01 trim the pair using all methods
			while (@method_sequence){
				my $read_is_good = $read->is_good;
				if ($read_is_good) {
					my $current_method = shift (@method_sequence);
					
					if ($header_tag){
					# Add the current method to the read's "trimmed_by headers	
						$read->set_header(($read->get_header)."_$current_method");
						$unchanged_read->set_header(($read->get_header));
					}
					
					if ($current_method eq "3end"){
						&SE_ThreeEnd($read, $n_threeEnd, $min_read_length,$num_bases_trimmed_by_ThreeEnd_ref, $num_reads_trimmed_by_ThreeEnd_ref);
					}
					elsif ($current_method eq "5end"){
						&SE_FiveEnd ($read, $n_fiveEnd, $min_read_length,$num_bases_trimmed_by_FiveEnd_ref, $num_reads_trimmed_by_FiveEnd_ref);
					}
					elsif ($current_method eq "qseqB"){
						&SE_qseqB ($read, $B_num_cutoff, $qB_mode, $action, $num_bases_trimmed_by_qseqB_ref, $num_reads_trimmed_by_qseqB_ref);
					}
					elsif ($current_method eq "qseq0"){
						&SE_qseq0 ($read, $num_bases_trimmed_by_qseq0_ref, $num_reads_trimmed_by_qseq0_ref);
					}
					elsif ($current_method eq "nsplit"){
						# nsplit tries to break the read at an Nblock. Three scenarios :
							# - If no splitting is done, it returns nothing
							# - If splitting is done BUT neither of the daughter reads are good, the parent
							# 	read is destroyed (set to ->skip by Nsplit) by Nsplit, and nothing is returned.
							# - If splitting is done and some daughter read(s) r produced, nsplit returns an
							#   array (reference) of these reads
						 my $nsplitted_single_reads_set_arr_ref = &SE_Nsplit ($read, $nsplit_n_cutoff, $min_read_length,
																			  $num_of_removed_bases_using_Nsplit_ref, $num_of_removed_N_blocks_ref,
																			  $num_of_Nsplit_removed_reads_ref);
					  
						if ($nsplitted_single_reads_set_arr_ref){
								my $single_reads_set_arr_ref = $single_reads_set->get_arr_ref;
								push @$single_reads_set_arr_ref, @$nsplitted_single_reads_set_arr_ref;
								$skip_this_read = 1; 
						}
						else {
							# do nothing
						}
					}# end else if nsplit
						
					elsif ($current_method eq "nperc"){
						&SE_NPerc ($read, $Nperc_cutoff, $num_bases_trimmed_by_Nperc_ref, $num_reads_trimmed_by_Nperc_ref);
					}
					elsif ($current_method eq "ncutoff"){
						&SE_Ncutoff ($read, $N_cutoff, $num_bases_trimmed_by_Ncuotff_ref, $num_reads_trimmed_by_Ncuotff_ref);
					}
					elsif ($current_method eq "5adpt"){
						&SE_five_prime_adpt ($read, $adapter_seqs_array_R_ref,  
							$match_percentage, $furthest_allowed_index_for_adapter_match, 
							$five_prime_extracted_adpt_fH, $adpt_action, $min_read_length, 
							$num_adpt_trimmed_bases_ref, $num_adpt_trimmed_reads_ref,
							$num_detected_adapter_sequences_ref, $num_inss, $num_dels, $num_subs, $adpt_max_match_len_diff);
					}
					elsif ($current_method eq "tera"){
						&SE_TERA ($read, $avg_cutoff, $min_read_length, $num_TERA_trimmed_bases_ref,$num_TERA_trimmed_reads_ref);
					}
					elsif ($current_method eq "lqr"){
						&SE_LQR ($read, $LQS_cutoff, $QPerc_cutoff,  $number_of_LQR_trimmed_bases_ref, $number_of_LQR_trimmed_reads_ref);
					}
					elsif ($current_method eq "mott"){
						&SE_Mott ($read, $mott_limit, $min_read_length, $num_mott_trimmed_bases_ref, $num_mott_trimmed_reads_ref);
					}
					elsif ($current_method eq "rmHP"){
						&SE_rmHP ($read, $rmHP_min_length, $rmHP_bases_arr_ref,
								  $num_rmHP_trimmed_bases_ref,$num_rmHP_trimmed_reads_ref);
					}
					elsif (($current_method eq "s2i") || ($current_method eq "i2s")){
						$read->switch_qual_scores($current_method);
					}
					else {die "ERROR: invalid method name: $current_method";}
					
				}# end If the read is still good
				
			else{ # elsif the read is discarded
					last; # exit the [while @method_sequence]loop 
				}
			}# while @method_sequence
		
	 # 02 Print what's left of the reads
		if (($mode eq "trim") && !$skip_this_read){
			if ($read->is_good){
				print $trimmed_reads_fH "> >\n".$read->return_fQ_string."\n< <\n";
				if ($discarded_reads_fH){
					print $discarded_reads_fH "> >\n< <\n";
				}
			}
			else{# if the read is discarded
				if ($print_discarded_reads_flag){
					print $discarded_reads_fH "> >\n".$unchanged_read->return_fQ_string."\n< <\n";
				}
				print $trimmed_reads_fH "> >\n< <\n";
			}
		}
	}# end while $single_reads_set is NOT empty	
		
	return;
}# end sub process_single_read

