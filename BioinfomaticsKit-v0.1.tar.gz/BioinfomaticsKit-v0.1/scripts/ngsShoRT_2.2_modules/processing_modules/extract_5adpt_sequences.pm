package extract_5adpt_sequences;
require Exporter;

use strict;
use warnings;

our $VERSION =  1.0;
our @ISA = 		  qw(Exporter);
our @EXPORT =   qw(extract_5adpt_sequences_to_arrays_and_print_header);

=head1 NAME
 
 extract_5adpt_sequences: a module for extracting adapter sequences from special adapter sequence
 files and loading them into adapter arrays, then returning a string that contains these sequences 
 followed by header jargon.
 This module has one subroutine, &extract_5adpt_sequences_to_arrays_and_print_header.

=head1 SYNOPSIS

 my $five_prime_adapter_sequences_list_string =
	       extract_5adpt_sequences_to_arrays_and_print_header(
     							$five_prime_adapter_filepath, 
							R1_adapter_seq_arr_ref, R2_adapter_seq_arr_ref,
						        $five_prime_extracted_adapter_seqs_filepath 
							);
 print $five_prime_adapter_sequences_list_string;

=head1 I/O 

=head2 Input parameter details

 $five_prime_adapter_filepath: the path to the 5' adapter sequences file, a modified copy of ngsShoRT_1.N/
                               five_prime_adapter_seq_TEMPLATE.txt. It contains adapter sequences along with
                               number of bases to delete 5' and 3' to the detected sequence. The sequences
                               are listed for the _1 and _2 reads of a Paired-End read pair. For single read
                               files, the _1 list is used.

 R1_adapter_seq_arr_ref: a reference to an array for that will be filled with the extracted Read_1 information
 R2_adapter_seq_arr_ref: a reference to an array that will be filled with the extracted Read_2 information
 
 [Note: Both R1 and R2 are filled for PE files. For SE files, only R1 is filled.]
 
 $five_prime_extracted_adapter_seqs_filepath: the path of the output file that will contain the header jargon,
                                              the adapter seqs parsed from $five_prime_adapter_filepath, and
			                      later (when we parse the reads), details about any read sequences
					      that matched these adapter sequences.

=head2 Output 
    
The output is a result string containing the following text:
	
 \#----------------------- 5' Adapter sequences -----------------------
 \# 5' Adapter sequences file path: 
 \# Extracted_adapter_seqs_filepath:
	
 \#----------------------- Extracted Adapter sequences -----------------------
 \# r1/2 adapter_sequence 3'-bases_to_remove 5'_bases_to_remove
 \# ..
	
 \# header jargon (scroll down to see it in the code)

=head1 AUTHOR

 Sari Khaleel (skhaleel at udel.edu)
 Last modified on 1-24-2012

=cut


sub extract_5adpt_sequences_to_arrays_and_print_header{					
	# Input :
	#  - an input adapter sequences file to be parsed
	#  - the references to the adapter sequence and deletion coordinates for Read_1 and Read_2 
	#  - the output file's path
	
	# Output/Function
	#  - Parse the input adapter sequences file and extract the adapter sequences
	#  - Load these sequences into the referenced arrays 
	#  - Create a $result_paragraph_string that contains these sequences and some header jargon
	#  - Return that string.
	
	my ($five_prime_adapter_filepath,# Input file containing the listed adapter seqs
		$R1_adapter_seq_arr_ref, $R2_adapter_seq_arr_ref, # The arrays to be loaded with seqs parsed
														  # from $five_prime_adapter_filepath.
														  # R2_adapter_seq_arr_ref is defined ONLY
														  # for PE_ files.
		$five_prime_extracted_adapter_seqs_filepath, # output file path.
		) = @_;
	
	
	open ADPT, "<", $five_prime_adapter_filepath;
	
	my $result_paragraph_string =
		"\#----------------------- 5' Adapter sequences -----------------------\n".
		"\# 5' Adapter sequences file path: $five_prime_adapter_filepath\n".
		"\# Extracted_adapter_seqs_filepath: $five_prime_extracted_adapter_seqs_filepath\n".
		"\n\#----------------------- Extracted Adapter sequences -----------------------\n";
	
	my $line;
	while (defined ($line = <ADPT>)){
		chomp ($line);
		if (defined ($line)){
			if ($line =~ /^\#/){ 
				#it's a comment line. Skip it.
			}
			elsif ($line =~ /\w/) {
				$result_paragraph_string .= "\# $line\n";
				
				# Extract the 4 components of the line
					my ($read_num, $adpt_seq, $three_prime_bases, $five_prime_bases) = split /\s+/, $line;
				
				# Die if they don't follow the expected format	
					die "ERROR (extract_5adpt_sequences_to_arrays_and_print_header): the lines listed in the 5' adapter file, $five_prime_adapter_filepath, do not seem to ".
					"follow the standard format.\nPlease use five_prime_adapter_seq_TEMPLATE.txt as your ".
					"template.\n" if (!($read_num && $adpt_seq && $three_prime_bases && $five_prime_bases));
				
				# remove the + and - signs from five prime and three prime bases
					$five_prime_bases =~ s/-//; $three_prime_bases =~ s/\+//;
				
				# push the components into their respective arrays
					if ($read_num =~ /r1/){
						my $new_line = join (',', $adpt_seq, $three_prime_bases, $five_prime_bases);
						push (@$R1_adapter_seq_arr_ref, $new_line);
					}
					# Load r2 adapter lines only if $R2_adapter_seq_arr_ref is defined, which is true
					# ONLY for PE_ file processing.
					elsif (($read_num =~ /r2/) && $R2_adapter_seq_arr_ref){
						my $new_line = join (',', $adpt_seq, $three_prime_bases, $five_prime_bases);
						push (@$R2_adapter_seq_arr_ref, $new_line);
					}
			}
		}# end if defined line
	}# end while
	$result_paragraph_string .= "\n\n";
	
	close ADPT;
	
	# Print the header for the extracted adapters file
		$result_paragraph_string.= 	"\# This file contains matched adapter sequences in its reads\n".
									"\# When an adapter sequence is matched to a read sequence using fuzzy matching,\n".
									"\# the fuzzy-matched substring may not be exactly identical to the 5' adapter \n".
									"\# sequence at match percentages under 100%\n".
								    "\# Moreover, each adapter sequence has a specific number of bases to be deleted \n".
									"\# after it (in the 3' direction) and before it (in the 5' direction. Thus, the ma-\n".
									"\# tched substring is not always identical to the adapter sequence, and the matched\n".
		                            "\# substring is WITHIN the deleted string\n\n\n". 
	
	return $result_paragraph_string;
}
