package merge_thread_output;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(merge_output);

use strict;
use warnings;
use PerlIO::gzip;


=head1 Synopsis
	
 merge_thread_output takes the output of threads (0..$num_threads) and merges
 it. Each thread output entry must be surrounded by "> > < <".

 Example:
 Two threads, 0 and 1, produce single entries of a letter or nothing at a time.
 thread #0 produces (a, b, ,c) and thread #1 produces (d, e, f, g). We want to merge
 these outputs into (a, d, b, e, f, c, g). 
 - Note that all thread outputs are in the same directory and are prefixed with the 
   thread number. 
 - Note that we "skipped" the empty entry in #0. 
 
	sample_dir/0.example.txt :
	> >
	a
	< <
	> >
	b
	< <
	> >
	< <
	> >
	c
	< <
	
	sample_dir/1.example.txt :
	> >
	d
	< <
	> >
	e
	< <
	> >
	f
	< <
	> >
	g
	< <
	
	The code to merge them is
	open $MERGED, "> merged_thread_output.txt";
	&merge_output("sample_dir", "example.txt", $MERGED, 2);
	
	This will create merged_thread_output.txt:
	a
	d
	b
	e
	f
	c
	g

=cut 

sub merge_output{
	my ($thread_output_dir, $filename, $master_FH, $num_threads, $gzip, $output_filepath) = @_;
	#die "ok\n";
	#print $master_FH "Hello\n";
	#die;
	if ($gzip){# overwrite the master_FH with a >:gzip version of it
		open ($master_FH, ">:gzip", $output_filepath) or die "Failed to open gzip file at $output_filepath !";
	}
	
	# Initialize num_threads filehandles
		my @filehandles;
		for (my $thread_num=0; $thread_num<$num_threads; $thread_num++){
				# Localize the file glob, so FILE is unique to the inner loop.
				local *FILE;
				open(FILE, "< $thread_output_dir/$thread_num.$filename") or die "Failed to open thread output file $thread_output_dir/$thread_num.$filename\n";
				
				# push the typeglobe to the end of the array
				push(@filehandles, *FILE);
		}# end for
	
	# Merge
		my $num_finished_parts = 0;
		while ($num_finished_parts < $num_threads){
			for (my $thread_num=0; $thread_num<$num_threads; $thread_num++){
				my $filehandle = $filehandles[$thread_num];
				my $line = <$filehandle>;
				if (! $line) {
					# We've reached EOF for this part
					$num_finished_parts++;
				}
				else {
					# Print the lines between > and <
					if ($line !~ /^> >/){die "ERROR: this section of $thread_num.$filename is abnormal, it doesn't start with > : $line\n";}
					$line = <$filehandle>; # If nothing was in between > and <, the the line is now "<\n"
					while ($line !~ /^< </){
						print $master_FH $line;
						#print $line;
						$line = <$filehandle>;
					}
				}# end else
			}# end for
		}# end while
	
}# end sub merge
