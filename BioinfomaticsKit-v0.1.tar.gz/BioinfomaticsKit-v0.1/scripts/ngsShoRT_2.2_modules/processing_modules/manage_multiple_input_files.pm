package manage_multiple_input_files;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(manage_multiple_input_files);

use strict;
use warnings;

=head1 NAME

 manage_multiple_input_files: a module for taking input file paths (from commandline's
 -sr,-pe1 and -pe2, -dir_sr, and -dir_pe) and load the paths of their corresponding
 output directories into @$sr_output_dirs_arr_ref and @$pe_output_dirs_arr_ref,
 the arrays that contains these paths in ngsShoRT.pl. All of these output directories
 are created as (or within) output_dir, the master output directory.

=head1 SYNOPSIS

 ngsShoRT.pl can trim, in one job, any of the following input file combinations:

  1. Paired-End (PE) files: -pe1 pe_filpath_1.fastq -pe1 pe_filpath_1.fastq
  2. Single Read file: -sr sr_filepath.fastq
  3. Multiple single read files: -sr sr_filepath_1.fastq,sr_filepath_2.fastq,sr_filepath_3.fastq,..
  4. 1 and 2
  5. 1 and 3
  6. All Single read files in a directory: -dir_sr single_read_files_dir
  7. All PE files in a directory: -pe_dir pe_read_files_dir
  
  The question is whether we need to create a subdirectory for the trimmed output within
  output_dir. For 3, 4, 5, 6 and 7, we do.
  
  The most complex of these input cases is 7, because it has to detect, from pe_read_files_dir,
  which _1 pairs with which _2. This is why ALL files in the directory have to follow a specific
  naming format/pattern, specified by -pe_fname_pattern. See section for more detail.

=head2 1 : Paired-End file pair

 The output directory for -pe1 and -pe2 is simply the master output_dir itself
   
=head2 2 : Single read file
 
 The output directory for -sr is simply the master output_dir itself
 
=head2 3 : Multiple single read files

 If the value for -sr contains multiple filepaths separated by commas, manage_multiple_input_files
 extracts all of the listed files into an array, and creates a separate subdirectory for
 each file's trimming results inside output_directory/.
 The name of each subdirectory = "trimmed_".(its input file's name without the extension)
 
=head2 4, 5 : a PE file pair and ONE/MULTIPLE single_read file

 The PE files' trimming results are stored in a subdirectory called "trimmed_PE_files"
 The/Each SR file's trimming results are stored in a subdirectory called "trimmed_".(its name
 without the extension)
 
=head2 6 : All SR files in a directory

 manage_multiple_input_files loads all the files in the input_directory into an array using
 opendir, and then creates their separate output subdirectories in the same manner of 3. 
  
=head2 7 : All PE pairs in a directory

 This problem is complicated because manage_multiple_input_files has to identify which _1
 file pairs with which _2 file. To do this, manage_multiple_input_files assumes that _1
 and _2 filenames (1) have the same name pattern and that (2) the pattern includes 1/2 to
 specify the file's _1 or _2 pairing. This filename pattern can be sepecified using
 -pe_fname_pattern. The default pattern is x_x_N_x_x.x, which corresponds to PE pair filenames
 like (s_1234_1_jim_foo.bar,s_1234_2_jim_foo.bar), (s_1235_1_jim_foo.bar, s_1235_2_jim_foo.bar),
 and so on. As you might have figured out, x = any character except '_', and N = 1/2 of
 PE read orientation.
  
 So, when manage_multiple_input_files parses the filename s_1234_1_jim_foo.bar, it knows that
 it's corresponding _2 file is s_1234_2_jim_foo.bar, and will then create a subdirectory
 within output_dir for the trimming output of these files, named "trimmed_s_1234_jim_foo".

=cut


sub append{
    # Appends a small file's contents to a bigger file
    
    my ($big_file, $small_file) = @_;
    
    open BIG , ">> $big_file" or die "ERROR (manage_multiple_input_files): Failed to open a temp merged file at $big_file\n";
    open SMALL, "< $small_file" or die "ERROR (manage_multiple_input_files): Failed to open the small input file at $small_file\n";
    
    while (defined (my $line = <SMALL>)){
        print BIG $line;
    }
    
    #die "$big_file <<\n";
    close BIG; close SMALL;
}


sub manage_multiple_input_files{
    my ($sr_filepaths_arr_ref, $SR_input_filepath, $sr_dir_path,
        $PE_input_filepath_1, $PE_input_filepath_2, $pe_filepaths_arr_ref,$pe_dir_path,
        $pe_output_dirs_arr_ref, $sr_output_dirs_arr_ref, $output_dir,
        $merge_dir,
        $pe_filename_pattern,
        $big_temp_se_file, $big_temp_pe1_file, $big_temp_pe2_file
        ) = @_;
    
    #die "$merge_dir <-\n";
    
    if ($SR_input_filepath)   {
        # If a single file is listed (there are no commas in the path), check that it exists
            if ($SR_input_filepath !~ /,/){            
                # If there are no PE_1 PE_2 files being trimmed along, simply push the input
                # and output dirs into the arrays
                    if (!($PE_input_filepath_1 && $PE_input_filepath_2)){
                        push @$sr_filepaths_arr_ref, $SR_input_filepath;
                        push @$sr_output_dirs_arr_ref, $output_dir;
                    }
                
                # But if they are there, it gets complicated: we need to put the SR file in a
                # subdirectory of output_dir
                    else {
                        # Create a subdirectory for the SR file and push the paths.
                        # The subdir name for SR1234.fastq is trimmed_SR1234
                            my @sr_filepath_parts = split (/\//,$SR_input_filepath);
                            my $sr_filename = $sr_filepath_parts[-1];
                            my $sr_dirName = $sr_filename; $sr_dirName =~ s/\.\w+//;
                            $sr_dirName = $output_dir."/trimmed_$sr_dirName";
                            if (! -e $sr_dirName) { system ("mkdir $sr_dirName");}
                            
                            push @$sr_filepaths_arr_ref, $SR_input_filepath;
                            push @$sr_output_dirs_arr_ref, $sr_dirName;
                            
                            #print "\n$sr_filename -> $sr_dirName\n";  # !!!!!!!!!!!!!!!!!
                    }
            }
        # else: if there are commas in the path, i.e, there are multiple files listed here,
        #       you have to create a subdir (in outputdir) for each file.
            else{
                # Extract the paths (which were already validated earlier in ngsShoRT), and
                # push them into the sr_filepathsarray
                    my @SR_filepaths = split /,/, $SR_input_filepath;
                    push @$sr_filepaths_arr_ref, @SR_filepaths;
                
                # Create separate output_dirs for each SR file in the list
                    foreach my $sr_filepath (@SR_filepaths){
                        # Create the directory filename
                            my @sr_filepath_parts = split (/\//,$sr_filepath);
                            my $sr_filename = $sr_filepath_parts[-1];
                            my $dirName = $sr_filename; $dirName =~ s/\.\w+//;
                            $dirName = $output_dir."/trimmed_$dirName";
                            if (! -e $dirName) { system ("mkdir $dirName");}
                        
                        # Push it into the sr_output_dirs array
                            push @$sr_output_dirs_arr_ref, $dirName;
                            
                            #print "\n$sr_filename-> $dirName\n";  # !!!!!!!!!!!!!!!!!!!!!!!
                    }
                    
            }# end else if multiple SR files are specified 
    }# end if ($SR_input_filepath)
    
    if ($PE_input_filepath_1 && $PE_input_filepath_2) {
        # First off, check if any SR file is being trimmed along. If not, simply push the
        # paths as they are into the path arrays.
            if (!$SR_input_filepath && !$sr_dir_path){
                push @$pe_filepaths_arr_ref, ($PE_input_filepath_2, $PE_input_filepath_1);
                push @$pe_output_dirs_arr_ref, $output_dir;
            }
        
        # Else: If there are SR files being trimmed along, you must create a subdirectory
        # (in output_dir) for the PE pair simply called trimmed_PE_files
        else {
            my @pe_filepath_parts = split (/\//,$PE_input_filepath_1);
            my $PE_1_filename = $pe_filepath_parts[-1];
            my $pe_dirName = $output_dir."/trimmed_PE_files";
            if (! -e $pe_dirName) { system ("mkdir $pe_dirName");}
            
            push @$pe_filepaths_arr_ref, ($PE_input_filepath_2, $PE_input_filepath_1);
            push @$pe_output_dirs_arr_ref, $pe_dirName;
        }# end else
    }# end if ($PE_input_filepath_1 && $PE_input_filepath_2) 

    if ($sr_dir_path){
        # For every file in the sr_dir_path,
            # - Create a subdirectory for the SR file and push the paths.
            # - The subdir name for SR1234.fastq is trimmed_SR1234
            opendir (DIR, $sr_dir_path) or die "\nERROR (manage_multiple_input_files): Failed to open the SR files directory $sr_dir_path\n";
        
            my @files = readdir (DIR);
            closedir (DIR);
            @files = sort @files;
                
                my $first_iteration = 1;
                my $extension = ".unknown";
                foreach my $file (@files){
                    unless (($file eq ".") ||  ($file eq "..")){
                        print "Found this file : $file\n";
                        if ($merge_dir eq "yes"){
                            if ($first_iteration){
                                if ($file =~ /\.\w+$/){
                                    $extension = $&;
                                    $big_temp_se_file .= $extension ;
                                }
                                $first_iteration = 0;
                            }
                            print "merging it with a big temp file .. \n";
                            &append ($big_temp_se_file, "$sr_dir_path/$file");
                            print "Done merging.\n";
                        }
                        else {# if merge_dir eq "no" 
                            push @$sr_filepaths_arr_ref, "$sr_dir_path/$file";
                            my $dirName = $file; $dirName =~ s/\.\w+//; $dirName = $output_dir."/trimmed_$dirName";
                            if (! -e $dirName) { system ("mkdir $dirName");}
                            push @$sr_output_dirs_arr_ref, $dirName;
                            
                            #print "\n$file-> $dirName\n";  # !!!!!!!!!!!!!!!!!
                            #die "no\n";
                        }
                    }
                }# end foreach
                
                #die;
                
            if ($merge_dir eq "yes" ){
                push @$sr_filepaths_arr_ref, $big_temp_se_file;
                push @$sr_output_dirs_arr_ref, $output_dir;
            }
    }# end if sr_dir_path


    if ($pe_dir_path){
        # For every two files in the pe_dir_path whose names match the pe_filename_pattern,
            # - Create a subdirectory for the PE file pair and push the paths.
            # - The subdir name for SR1234_1.fastq and SR1234_2.fastq is trimmed_SR1234_PE. This
            #   distinguishes it from an SR file subdir.
            opendir (DIR, $pe_dir_path) or die "\nERROR (manage_multiple_input_files): Failed to open the PE files directory $pe_dir_path\n";
        
            my @files = readdir (DIR);
            closedir (DIR);
            @files = sort @files;
                
                # Split the filename pattern and locate the 'N'
                
                my @pe_filename_pattern_parts = split /\./, $pe_filename_pattern;
                   @pe_filename_pattern_parts = split /_/, $pe_filename_pattern_parts[0];
                my $N_index = -1; my $c = 0;
              foreach (@pe_filename_pattern_parts){
                    if ($_ eq 'N') {
                        $N_index = $c;
                        last;
                    }
                    $c++;
                }
                if ($N_index == -1) {die "ERROR (input: pe_dir : filename_pattern) : The character 'N' was not found in the pe_filename pattern $pe_filename_pattern !\n";}
                
                # Go thru the files in the directory and find ones that have the same name pattern as pe_filename_pattern
                    my (%pe_1_hash, %pe_2_hash);
                    foreach my $file (@files){
                          unless (($file eq ".") ||  ($file eq "..")){
                                my @filename_parts = split /\./, $file;
                                @filename_parts = split /_/, (shift @filename_parts);
                                
                                if ($#filename_parts == $#pe_filename_pattern_parts) {
                                    my $N = $filename_parts[$N_index];
                                    if ($N){
                                        if ($N eq "1") {$pe_1_hash{"$file"} = 1;}
                                        elsif ($N eq "2") {$pe_2_hash{"$file"} = 1;}
                                        else {
                                            print "WARNING (input: pe_dir : filename_pattern) : this filename, $file, does not match the pe_filename pattern $pe_filename_pattern\n"; 
                                        }
                                    }
                                    else {print "WARNING (input: pe_dir : filename_pattern) : this filename, $file, does not match the pe_filename pattern $pe_filename_pattern\n"; }
                                }# end if ($#filename_parts == $#pe_filename_pattern_parts)
                                else {
                                    print "WARNING (input: pe_dir : filename_pattern) : this filename, $file, does not match the pe_filename pattern $pe_filename_pattern\n";
                                }
                          }# end unless
                    }#end foreach file in @files
                
                # Create the PE _2 filename by swapping the 1 in the PE _1 filename for 2
                my $first_iteration = 1;
                foreach my $pe_1_filename (keys %pe_1_hash){
                    my @pe1_fname_parts = split /\./, $pe_1_filename;
                    my @pe1_fname_parts_b4_dot = split /_/, (shift @pe1_fname_parts);
                    
                    my $extension = join '.', @pe1_fname_parts; # In case there are multiple .x.x.x parts in the file
                       
                         $pe1_fname_parts_b4_dot[$N_index] = 2;
                         my $pe_2_filename = (join '_', @pe1_fname_parts_b4_dot).".$extension";
                         
                         if (exists $pe_2_hash{$pe_2_filename}){
                            print "Found this PE pair : $pe_1_filename and $pe_2_filename"."\n";
                            
                            if ($merge_dir eq "yes"){
                                if ($first_iteration){
                                    $big_temp_pe1_file.= ".$extension"; $big_temp_pe2_file.=".$extension";
                                    $first_iteration = 0;
                                }
                                print "merging this pair with big paired temp files .. \n";
                                &append ($big_temp_pe1_file, "$pe_dir_path/$pe_1_filename");
                                &append ($big_temp_pe2_file, "$pe_dir_path/$pe_2_filename");
                                print "Done merging.\n";
                            }
                            else {
                                
                                push @$pe_filepaths_arr_ref, ("$pe_dir_path/$pe_2_filename", "$pe_dir_path/$pe_1_filename");
                                $pe1_fname_parts_b4_dot[$N_index] = 'N';
                                my $dirName = join '_', @pe1_fname_parts_b4_dot;
                                $dirName = $output_dir."/trimmed_$dirName"."_PE";
                                if (! -e $dirName) { system ("mkdir $dirName");}
                                push @$pe_output_dirs_arr_ref, $dirName;
                            }
                         }
                         else {print "WARNING: could not find a PE _2 for this PE _1 file : $pe_1_filename in the PE directory $pe_dir_path\n";}
                }
                if ($merge_dir eq "yes" ){
                    push @$pe_filepaths_arr_ref, ($big_temp_pe1_file, $big_temp_pe2_file);
                    push @$pe_output_dirs_arr_ref, $output_dir;			
                }
    }# end if pe_dir_path

}# end sub manage_..