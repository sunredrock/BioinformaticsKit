package process_PE_read_pair;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(process_PE_read_pair);

use strict;
use warnings;

# Read classes
use single_fQ_read 1.0;
use PE_fQ_pair 1.0;
use fQ_array 1.0;

# Trimming modules
use five_prime_adpt 1.0 ;
use FiveEnd 1.0 ;
use LQR 1.0 ;
use Mott 1.0;
use Ncutoff 1.0;
use NPerc 1.0;
use Nsplit;
use qseq0 1.0;
use qseqB 1.0;
use TERA 1.0;
use ThreeEnd 1.0;
use rmHP 1.0;


=head1 I. NAME
  
  process_PE_read_pair: a module for trimming the sequence and quality score lines of
  the two reads (each being a single_fQ_read object) in a PE_fQ_pair  using the speci-
  fied ngsShoRT methods and their parameters.

=head1 II. SYNOPSIS

=head2 II.1. Calling and output

 The following call is made from process_PE_files_section, which parses its designated
 section of the two PE files (see process_PE_files_section.pm documentation), trimming one
 read pair (pair = one read from each PE file) at a time. Once a single_fQ_read object is
 created for each of the two reads, they are loaded into a PE_fQ_pair object, which in turn
 is put inside an fQ_array object called PE_pairs_set and is passed to process_PE_read_pair
 along with @methods (the ordered list of methods to run on the read), method parameters,
 and references to trimming counters and the output filehandles.

  &process_PE_read_pair ( 
		$PE_pairs_set,
		# Main parameters
			$mode, $method_sequence_arr_ref, $min_read_length, $print_discarded_reads_flag,
			$header_tag,
		
		# Filehandles
			$trimmed_reads_1_fH, $trimmed_reads_2_fH,$surv_fH,
			$discarded_reads_1_fH, $discarded_reads_2_fH,
			
		# Method Parameters and trimmed base/read/pair counter references
		 # PE_ThreeEnd
			$n_threeEnd, \$num_bases_trimmed_by_ThreeEnd, \$num_reads_trimmed_by_ThreeEnd,\$num_pairs_trimmed_by_ThreeEnd,
		 # PE_FiveEnd
			$n_fiveEnd,\$num_bases_trimmed_by_FiveEnd, \$num_reads_trimmed_by_FiveEnd,\$num_pairs_trimmed_by_FiveEnd,
		 # PE_five_prime_adpt
			$five_prime_r1_adpt_arr_ref, $five_prime_r2_adpt_arr_ref, 
			$match_percentage, $furthest_allowed_index_for_adapter_match, 
			$five_prime_extracted_adpt_fH,$adpt_action, \$num_adpt_trimmed_bases,
			\$num_adpt_trimmed_reads,\$num_adpt_trimmed_pairs, $adpt_max_match_len_diff,
			\$num_detected_adapter_sequences, $num_inss, $num_dels, $num_subs,
		 # PE_LQR
			$LQS_cutoff, $QPerc_cutoff,\$number_of_LQR_trimmed_bases, \$number_of_LQR_trimmed_reads,\$number_of_LQR_trimmed_pairs,
		 # PE_Mott
			$mott_limit,\$num_mott_trimmed_bases, \$num_mott_trimmed_reads,\$num_mott_trimmed_pairs,
		 # PE_Ncutoff
			$N_cutoff, 
			\$num_bases_trimmed_by_Ncuotff, \$num_reads_trimmed_by_Ncuotff,\$num_pairs_trimmed_by_Ncuotff,
		 # PE_NPerc
			$Nperc_cutoff, 
			\$num_bases_trimmed_by_Nperc, \$num_reads_trimmed_by_Nperc,\$num_pairs_trimmed_by_Nperc,
		 # PE_Nsplit
			$nsplit_n_cutoff, \$num_of_removed_bases_using_Nsplit, \$num_of_removed_N_blocks,
			\$num_of_Nsplit_removed_reads, \$num_of_Nsplit_removed_pairs,
		 # qseq0
			\$num_bases_trimmed_by_qseq0, \$num_reads_trimmed_by_qseq0, \$num_pairs_trimmed_by_qseq0,
		 # qseqB
			$B_num_cutoff, $qB_mode, $action, \$num_bases_trimmed_by_qseqB,
			\$num_reads_trimmed_by_qseqB,\$num_pairs_trimmed_by_qseqB,
		 # TERA
			$avg_cutoff, \$num_TERA_trimmed_bases,\$num_TERA_trimmed_reads,\$num_TERA_trimmed_pairs
					);

	By the end of the call, the counters will be updated and the trimmed/killed read pair
	will be printed to trimmed_1_FH and trimmed_2_FH (if mode = trim AND the read pair is
	still good* after all trimming methods), or to discarded_reads_1_FH/discarded_reads_2_FH
	and surv_FH (if print_discarded_reads yes AND the read is destroyed by one of the trimming methods) 
	
	* What's a "good" pair?
	----------------------
	  A PE_fQ_pair is good if its &status function returns the value 3. What does this mean?
	  
	  PE_fQ_pair::status returns 3 if both reads (each a single_fQ_read object) in the pair
	  are good (seq_length >= min_rl and the _skip flag = 0), which means that the pair is
	  good. The following is done:
	    - read1 is printed to trimmed_1_FH, enclosed by '> >' and '< <' lines*
		- read2 is printed to trimmed_2_FH, enclosed by '> >' and '< <' lines*
		- empty strings, enclosed by '> >' and '< <' lines*, are printed to discarded_reads_1_DH
		  and discarded_reads_2_FH. Note that this is optional and is done only if the user has
		  specified "-print_discarded_reads yes" in the commandline.
	  
	  PE_fQ_pair::status returns 2 or 1 if only read2 or read1 in the pair are good, respecti-
	  vely, which means that their mate read has become "bad" after trimming (because some
	  method made it shorter than min_rl or set its _skip flag to 1). In this case, the reads
	  of the pair can no longer be printed to the paired trimmed_1 and trimmed_2 files. Instead,
	  the following is done:
	   - The "good" read in the pair is printed out to surviving_SR_mates.fastq
	   - The "bad" read in the pair is printed to its corresponding discarded_reads (_1 or _2) file. 
	   - The removed PE read counter is incremented by 1 and the removed PE pair counter is also incremented
	     by 1, since the PE pair was removed from the final output.
	
	  PE_fQ_pair::status returns 0 if both reads are bad which means that they have both become "bad" after
	  trimming (because some method made them shorter than min_rl or set its _skip flag to 1). In this case,
	  the reads of the pair can no longer be printed to the paired trimmed_1 and trimmed_2 files. Instead,
	  the following is done:
	   - Each read is printed to its corresponding discarded_reads (_1 or _2) file. Again, Note
	     that this is optional and is done only if the user has specified "-print_discarded_reads yes" in
		 the commandline.
	   - The removed PE read counter is incremented by 2 and the removed PE pair counter is also incremented
	     by 1, since the PE pair was removed from the final output.
	
	 * To understand why all outputs of a read are enclosed by '> >' and '< <' lines, see section II.2.b.
	  			
=head2 II.2. Under the hood
 
 a. Trimming method calls and output
 -----------------------------------
 For every trimming method in the passed methods array, process_PE_read_pair calls the
 corresponding PE trimming subroutine, passing the PE_fQ_pair along with references
 to counter variables (passed to it from process_PE_files_section, which prints them,
 when reaching EOF, to counts.txt) 
 
 When a trimming method is done with the PE pair, process_PE_read_pair checks its
 status as described above. 

 b. Why enclose outputs (including null output) with '> >' and '< <' lines?
 ---------------------------------------------------------------------------
 Because of the multithreaded design of ngsShoRT, each process_PE_files_section will
 trim a different section of the files. Section outputs can be merged because of two
 things: prefixing each section with its (0-N) thread number, and enclosing every
 read's corresponding trimmed, surviving, and discarded read ouputs with > > and < < to
 indicate an entry. For more on that, see the documentation for process_PE_files section.pm
 and process_two_PE_files.pm.

 c. Read Header modification
 ---------------------------
 By default, process_PE_read_pair will append "|Trimmed_by" to each read's header,
 and then append method names as it iteratively runs the methods in
 @$method_sequence_arr_ref on the read. So, if @methods = (5adpt, 3end, tera),
 then by the end of trimming, each read should have "|Trimmed_by_5adpt_3end_tera"
 appended to its header, unless the read was killed/skipped/rendered too short
 by a method. In this case, header modification will be different -- see below.
 
 d. Discarded reads
 ------------------
 Before trimming a read, process_PE_read_pair creates an "unchanged_read" copy of
 this read. Like the read, unchanged_read will have its header modified (appending
 the next method), but its sequence is NOT trimmed. If the read gets killed/skipped/
 rendered shorter than min_rl before the end of trimming, then process_single_read
 will print out the unchanged_read to its corresponding discarded_reads_FH (if
 $print_discarded_reads_flag, passed as input from process_PE_files_section, is defined,
 which only if the user specified -printed_discarded_reads yes). So, the user can
 see the raw read and in its header, the sequence of methods that led to its removal.
 
 E.g. @methods = 5adpt, lqr, 3end, and the read was "skipped" by lqr. The printed
 output in discarded_reads_(1/2)FH will be:
 > >
 @READs_HEADER|Trimmed_by_5adpt_lqr
 UNCHANGED SEQUENCE LINE
 +
 UNCHANGED QUALITY LINE
 < <
 
 e. The nightmare called nsplit
 ------------------------------
 For all methods, process_PE_file_section will pass ONE PE_fQ_pair object, but
 it's inside an fQ_array object called PE_pairs_set. Why?

 The answer has to do with nsplit. nsplit is the ONLY method that splits a single
 read into potentially 2 reads, returning the result (1-2 pairs of split reads) inside
 an fQ_array object. If splitting has indeed occured and two "good" daughter reads are
 created for one/both reads in the pair, then the remaining methods in @methods have
 to be called on each of the daughter pairs, and so process_PE_read_pair will put
 these pairs into into a new fQ_array and call itself on these pairs with the remaining methods.
 
 Note that you can tell if a read in the trimmed file is a daughter read of nsplitting
 by its header: Since process_PE_read_pair was called again on the pair of this daughter read,
 it will have a new "|Trimmed_by_.." appended to its header.
 
 E.g.
 @methods = (5adpt, nsplit, 3end)
 current_method = 5adpt
 Parent read header: "@SR_1234|Trimmed_by_5adpt"
 -> Do 5adpt trimming
 
 current_method = nsplit 
 Parent read header: "@SR_1234|Trimmed_by_5adpt_nsplit"
 -> Do nsplit trimming
 -> You get two new daughter reads
 -> skip the parent read from being printed to trimmed_ or discarded_ FH
 -> Call process_single_read on each daughter read with @methods = (3end)
 
 @methods = 3end
 current_method = 3end
 Daughter read header: "@SR_1234|Trimmed_by_5adpt_nsplit|Trimmed_by_3end"
 -> Do 3end trimming
				
=cut

sub process_PE_read_pair{
	my (# Read pair
		  	$PE_pairs_set, 
		# Main parameters
		  	$mode, $method_sequence_arr_ref, $min_read_length,
			$print_discarded_reads_flag, # is defined (1) only if the user specified
			                             # "-print_discarded_reads yes" in the commandline
			$header_tag,
		  
		# Main Filehandles
		  	$trimmed_reads_fh_1, $trimmed_reads_fh_2, $surv_fh, $discarded1_fh, $discarded2_fh,
		  
		# Method Parameters and trimmed base/read/pair counter references
		 # PE_ThreeEnd
		  	$n_threeEnd, $num_bases_trimmed_by_ThreeEnd_ref, $num_reads_trimmed_by_ThreeEnd_ref,
			$num_pairs_trimmed_by_ThreeEnd_ref,
		 # PE_FiveEnd
		  	$n_fiveEnd,$num_bases_trimmed_by_FiveEnd_ref, $num_reads_trimmed_by_FiveEnd_ref,
			$num_pairs_trimmed_by_FiveEnd_ref,
		 # PE_five_prime_adpt
		  	$adapter_seqs_array_R1_ref, $adapter_seqs_array_R2_ref, 
		  	$match_percentage, $furthest_allowed_index_for_adapter_match, 
		  	$extracted_adapters_filehandle, $adpt_action, $num_adpt_trimmed_bases_ref,
			$num_adpt_trimmed_reads_ref,$num_adpt_trimmed_pairs_ref, $adpt_max_match_len_diff,
		  	$num_detected_adapter_sequences_ref, $num_inss, $num_dels, $num_subs,
		 # PE_LQR
		  	$LQS_cutoff, $QPerc_cutoff,$number_of_LQR_trimmed_bases_ref, $number_of_LQR_trimmed_reads_ref,
			$number_of_LQR_trimmed_pairs_ref,
		 # PE_Mott
		  	$mott_limit,$num_mott_trimmed_bases_ref, $num_mott_trimmed_reads_ref,
			$num_mott_trimmed_pairs_ref,
		 # PE_Ncutoff
		  	$N_cutoff, 
	    	$num_bases_trimmed_by_Ncuotff_ref, $num_reads_trimmed_by_Ncuotff_ref,
		  	$num_pairs_trimmed_by_Ncuotff_ref,
		 # PE_NPerc
		  	$Nperc_cutoff, 
	    	$num_bases_trimmed_by_Nperc_ref, $num_reads_trimmed_by_Nperc_ref,
		  	$num_pairs_trimmed_by_Nperc_ref,
		 # PE_Nsplit
		  	$nsplit_n_cutoff, $num_of_removed_bases_using_Nsplit_ref, $num_of_removed_N_blocks_ref,
			$num_of_Nsplit_removed_reads_ref, $num_of_Nsplit_removed_pairs_ref,
		 # qseq0
		  	$num_bases_trimmed_by_qseq0_ref, $num_reads_trimmed_by_qseq0_ref, $num_pairs_trimmed_by_qseq0_ref,
		 # qseqB
		  	$B_num_cutoff, $qB_mode, $action, $num_bases_trimmed_by_qseqB_ref,
	    	$num_reads_trimmed_by_qseqB_ref, $num_pairs_trimmed_by_qseqB_ref,
		 # TERA
		  	$avg_cutoff, $num_TERA_trimmed_bases_ref,$num_TERA_trimmed_reads_ref, $num_TERA_trimmed_pairs_ref,
		# rmHP
			$rmHP_min_length, $rmHP_bases_arr_ref, $num_rmHP_trimmed_bases_ref,$num_rmHP_trimmed_reads_ref,$num_rmHP_trimmed_pairs_ref
		) 
		= @_; 
	
	my @method_sequence = @$method_sequence_arr_ref;
	
	while (!($PE_pairs_set->is_empty)){
		my $PE_pair = $PE_pairs_set->pop;
		
		if ($header_tag && @method_sequence){
		# Add |trimmed_by_ to both reads
			$PE_pair->read1->set_header(($PE_pair->read1->get_header)."|Trimmed_by");
			$PE_pair->read2->set_header(($PE_pair->read2->get_header)."|Trimmed_by");
		}
			
		# Create a copy of the pair that won't be changed. This copy is used only if the user wants to have
		# a bad reads file, which would contain the bad "unchanged" read with its new header (now contains
		# the name of the method sequence that killed it)
			my ($unchanged_read1, $unchanged_read2);
			if ($PE_pair->read1->is_good){
				$unchanged_read1 = new single_fQ_read(
													_header  => $PE_pair->read1->get_header,
													_seq     => $PE_pair->read1->get_seq,
													_comment => $PE_pair->read1->get_comment,
													_qual    => $PE_pair->read1->get_qual,
													_min_rl  => $min_read_length,
													_qseq_filter => $PE_pair->read1->get_qseq_filter,
													_ascii_zero  => $PE_pair->read1->get_ascii_zero,
													_call_from => "process_PE_read_pair: unchanged_read1_creation");
			}
			
			if ($PE_pair->read2->is_good){
				$unchanged_read2 = new single_fQ_read(
													_header  => $PE_pair->read2->get_header,
													_seq     => $PE_pair->read2->get_seq,
													_comment => $PE_pair->read2->get_comment,
													_qual    => $PE_pair->read2->get_qual,
													_min_rl  => $min_read_length,
													_qseq_filter => $PE_pair->read2->get_qseq_filter,
													_ascii_zero  => $PE_pair->read2->get_ascii_zero,
													_call_from => "process_PE_read_pair: unchanged_read2_creation");
			}
			
		my $skip_this_pair = 0;
		# 01 trim the pair using all methods
			while (@method_sequence){
				my $PE_pair_status = $PE_pair->get_status ;
				
				if ($PE_pair_status == 3) { # this means both of the pair's reads are good
					my $current_method = shift (@method_sequence);
					
					if ($header_tag){
					# Add the current method to the read's "trimmed_by headers	
						$PE_pair->read1->set_header(($PE_pair->read1->get_header)."_$current_method");
						$PE_pair->read2->set_header(($PE_pair->read2->get_header)."_$current_method");
						$unchanged_read1->set_header(($PE_pair->read1->get_header));
						$unchanged_read2->set_header(($PE_pair->read2->get_header));
					}
					
					if ($current_method eq "3end"){
						&PE_ThreeEnd($PE_pair, $n_threeEnd, $min_read_length,$num_bases_trimmed_by_ThreeEnd_ref, 
						$num_reads_trimmed_by_ThreeEnd_ref, $num_pairs_trimmed_by_ThreeEnd_ref);
					}
					elsif ($current_method eq "5end"){
						&PE_FiveEnd ($PE_pair, $n_fiveEnd, $min_read_length,$num_bases_trimmed_by_FiveEnd_ref,
						 $num_reads_trimmed_by_FiveEnd_ref, $num_pairs_trimmed_by_FiveEnd_ref);
					}
					elsif ($current_method eq "qseqB"){
						&PE_qseqB ($PE_pair, $B_num_cutoff, $qB_mode, $action, $num_bases_trimmed_by_qseqB_ref,
						 $num_reads_trimmed_by_qseqB_ref, $num_pairs_trimmed_by_qseqB_ref);
					}
					elsif ($current_method eq "qseq0"){
						&PE_qseq0 ($PE_pair, $num_bases_trimmed_by_qseq0_ref, $num_reads_trimmed_by_qseq0_ref, 
						$num_pairs_trimmed_by_qseq0_ref);
					}
					elsif ($current_method eq "nsplit"){
						# nsplit tries to break each read in the pair at an Nblock.
						# 1. If neither of the reads are split, nsplit returns nothing
						# 2. If either/both reads is nsplit, but both resulting daughter reads are !good, the
						#    read is destroyed (set to ->skip by Nsplit) by Nsplit, and nothing is returned.
						# Note that for 1 and 2, nothing is returned and so we just move on with trimming
						# 3. If both reads are still good and some splitting was done,
						#    the pieces are shuffled to created new PE_fQ_pairs stored into an array,
						#    nsplit reutrns a reference to that array
						
						 my $nsplitted_PE_pairs_arr_ref = &PE_Nsplit ($PE_pair, $nsplit_n_cutoff, $min_read_length,
						  $num_of_removed_bases_using_Nsplit_ref, $num_of_removed_N_blocks_ref, 
						  $num_of_Nsplit_removed_reads_ref,$num_of_Nsplit_removed_pairs_ref);
					  
						# Check if there are items (results of nsplitting) in the nsplit_PE_pairs_set
							if ($nsplitted_PE_pairs_arr_ref){
								# if there items, add them to the PE_pairs_set, and skip this current (parent) pair
								# from being printed to trimmed/surv/discarded
								my $PE_pairs_set_arr_ref = $PE_pairs_set->get_arr_ref;
								push @$PE_pairs_set_arr_ref, @$nsplitted_PE_pairs_arr_ref;
								$skip_this_pair = 1; 
							}
							else {
								# do nothing
							}
					}#end if nsplit
					elsif ($current_method eq "nperc"){
						&PE_NPerc ($PE_pair, $Nperc_cutoff, $num_bases_trimmed_by_Nperc_ref, 
						$num_reads_trimmed_by_Nperc_ref, $num_pairs_trimmed_by_Nperc_ref);
					}
					elsif ($current_method eq "ncutoff"){
						&PE_Ncutoff ($PE_pair, $N_cutoff, $num_bases_trimmed_by_Ncuotff_ref,
						 $num_reads_trimmed_by_Ncuotff_ref, $num_pairs_trimmed_by_Ncuotff_ref);
					}
					elsif ($current_method eq "5adpt"){
						&PE_five_prime_adpt ($PE_pair, $adapter_seqs_array_R1_ref, $adapter_seqs_array_R2_ref, 
							$match_percentage, $furthest_allowed_index_for_adapter_match, 
							$extracted_adapters_filehandle, $adpt_action, $min_read_length, 
							$num_adpt_trimmed_bases_ref, $num_adpt_trimmed_reads_ref,$num_adpt_trimmed_pairs_ref,
							$num_detected_adapter_sequences_ref, $num_inss, $num_dels, $num_subs, 
							$adpt_max_match_len_diff);
					}
					elsif ($current_method eq "tera"){
						&PE_TERA ($PE_pair, $avg_cutoff, $min_read_length, $num_TERA_trimmed_bases_ref,
						$num_TERA_trimmed_reads_ref, $num_TERA_trimmed_pairs_ref);
					}
					elsif ($current_method eq "lqr"){
						&PE_LQR ($PE_pair, $LQS_cutoff, $QPerc_cutoff,  $number_of_LQR_trimmed_bases_ref,
						 $number_of_LQR_trimmed_reads_ref, $number_of_LQR_trimmed_pairs_ref);
					}
					elsif ($current_method eq "mott"){
						
						#print "BEFORE:\n".$PE_pair -> return_fQ_string."\n";
						
						&PE_Mott ($PE_pair, $mott_limit, $min_read_length, $num_mott_trimmed_bases_ref,
						 $num_mott_trimmed_reads_ref, $num_mott_trimmed_pairs_ref);	
					}
					elsif (($current_method eq "s2i") || ($current_method eq "i2s")){
						$PE_pair->switch_qual_scores($current_method);
					}
					elsif ($current_method eq "rmHP"){
						&PE_rmHP ($PE_pair, $rmHP_min_length, $rmHP_bases_arr_ref,
								  $num_rmHP_trimmed_bases_ref,$num_rmHP_trimmed_reads_ref,$num_rmHP_trimmed_pairs_ref);
					}
					else {die "ERROR: invalid method name: $current_method";}
					
				}# end ($PE_pair_status == 3), aka If the reads are still good
				elsif ($PE_pair_status !=3){
					last;
				}
			}# end while @method_sequence
	
	 # 02 Print what's left of the reads
		if (($mode eq "trim") && !$skip_this_pair){
			&print_trimmed_reads($PE_pair,$unchanged_read1,$unchanged_read2, $trimmed_reads_fh_1,
			 $trimmed_reads_fh_2, $surv_fh, $print_discarded_reads_flag, $discarded1_fh, $discarded2_fh);
		}
	}# end while $PE_pairs_set is NOT empty	
		
	return;
}# end sub process_PE_read_pair


sub print_trimmed_reads{
	my ($PE_pair, $unchanged_read1,$unchanged_read2, $trimmed_reads_fh_1, $trimmed_reads_fh_2, 
		$surv_fh, $print_discarded_reads_flag, $discarded1_fh, $discarded2_fh) = @_;
	my ($read1, $read2) = ($PE_pair->read1, $PE_pair->read2);
	
	# Get pair status (3 = both reads are good, 2/1= only read1/2 is good, 0 = neither)
	# and based on it, print reads to the appropriate files
		my $PE_pair_status = $PE_pair->get_status ;	
		
		if ($PE_pair_status == 3){
			print $trimmed_reads_fh_1 "> >\n".$read1->return_fQ_string."\n< <\n";
			print $trimmed_reads_fh_2 "> >\n".$read2->return_fQ_string."\n< <\n";
			
			print $surv_fh "> >\n< <\n";
			if ($print_discarded_reads_flag){
				print $discarded1_fh "> >\n< <\n";
				print $discarded2_fh "> >\n< <\n";
			}
		}
		elsif ($PE_pair_status == 2){
			print $surv_fh "> >\n".$read2->return_fQ_string."\n< <\n";
			
			print $trimmed_reads_fh_1 "> >\n< <\n";
			print $trimmed_reads_fh_2 "> >\n< <\n";
			
			if ($print_discarded_reads_flag){
				if ($unchanged_read1){
					print $discarded1_fh "> >\n".$unchanged_read1->return_fQ_string."\n< <\n";
				}
				else {print $discarded1_fh "> >\n< <\n";}
				print $discarded2_fh "> >\n< <\n";
			}
		}
		elsif ($PE_pair_status == 1){
			print $surv_fh "> >\n".$read1->return_fQ_string."\n< <\n";
			
			print $trimmed_reads_fh_1 "> >\n< <\n";
			print $trimmed_reads_fh_2 "> >\n< <\n";
			
			if ($print_discarded_reads_flag){
				print $discarded1_fh "> >\n< <\n";
				if ($unchanged_read2){
					print $discarded2_fh "> >\n".$unchanged_read2->return_fQ_string."\n< <\n";
				}
				else {print $discarded2_fh "> >\n< <\n";}
			}
		}
		elsif ($PE_pair_status == 0){
			if ($print_discarded_reads_flag){
				if ($unchanged_read1){
					print $discarded1_fh "> >\n".$unchanged_read1->return_fQ_string."\n< <\n";
				}
				else {print $discarded1_fh "> >\n< <\n";}
				if ($unchanged_read2){
					print $discarded2_fh "> >\n".$unchanged_read2->return_fQ_string."\n< <\n";
				}
				else {print $discarded2_fh "> >\n< <\n";}
			}
			
			print $surv_fh "> >\n< <\n";
			print $trimmed_reads_fh_1 "> >\n< <\n";
			print $trimmed_reads_fh_2 "> >\n< <\n";
		}
}# end sub print_trimmed_reads
