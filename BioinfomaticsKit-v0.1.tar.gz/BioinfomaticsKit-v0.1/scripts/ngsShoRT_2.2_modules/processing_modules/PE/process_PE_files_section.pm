package process_PE_files_section;
require Exporter;

our $VERSION =  1.0;
our @ISA = 		qw(Exporter);
our @EXPORT =   qw(process_PE_files_section);

use strict;
use warnings;
use threads;

# Read classes
use single_fQ_read 1.0;
use PE_fQ_pair 1.0;
use fQ_array 1.0;


# Processing modules
use process_PE_read_pair 1.0;
use qseq_line_2fastq_read_object 1.0;

=head1 NAME

 process_PE_files_section: a subroutine that parses a section of the input PE
 files and run ngsShoRT methods locally on that section of the files. The resulting
 output files are: 
 
  - trimmed PE_1 and PE_2 files (if mode = trim)
  - discarded reads files (optional) for reads that failed trimming and were thus
    discarded from the final trimmed output
  - surviving_SR_mates.fastq for surviving mates of discarded reads
  - extracted 5' adapter sequences (only if -methods include 5adpt).
  - counts.txt : a csv file containing all trimming counts for the files

	
=head1 SYNOPSIS

 In the MASTER thread, process_two_PE_files is called to trim its input files
 using N threads. To do this, N threads are created, each running an instance of
 process_PE_files_section on its separate "section" of the filew. Each thread starts
 at a different spot of the PE input files, and parses reads separated by N steps.
 The trimming result of each section is then merged by process_PE_files.
 
 To order the output, the output files of each thread/process_SR_file_section is
 prefixed with the number of the thread calling that instance process_SR_file_section.
 In addition, in each output file, the output corresponding to each read is enclosed
 by '> >' and '< <' lines -- even if the output is an empty string (if a read is
 trimmed successfuly, its corresponding "discarded read" is null). These lines are
 necessary for the merging step done by &process_PE_read_pair. 
 
 
 &process_PE_files_section(
    $thread_num, $num_threads, $read_format,
		# FilePaths
		  $input_filepath_1, $input_filepath_2,$output_dir,
				
		# Main params
		  $methods_include_qseq0, $methods_include_5adpt,
		  $mode, $method_sequence_arr_ref, $min_read_length, 
		   $ASCII_of_zero_qual_score, $qseq_dot_to_N, $print_discarded_reads,
		   $header_tag,
				
		 # Method params
		   # PE_ThreeEnd, PE_FiveEnd
		     $n_threeEnd,$n_fiveEnd,
		   # PE_five_prime_adpt
		     \@five_prime_r1_adpt, \@five_prime_r2_adpt,
		     $match_percentage, $furthest_allowed_index_for_adapter_match, 
		     $adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
		   # PE_LQR
		     $LQS_cutoff, $QPerc_cutoff,
		   # PE_Mott, PE_Ncutoff, PE_NPerc, PE_Nsplit
		     $mott_limit, $N_cutoff, $Nperc_cutoff,$nsplit_n_cutoff, 
		   # qseqB
		     $B_num_cutoff, $qB_mode, $action, 
		   # TERA
		     $avg_cutoff
	);
										
 
 The first read in the section is used to identify the read format of the file (either
 qseq or fastq).
   - If fastq, 4 lines are parsed at a time and the next read in the section
     is 4 * N lines away.
   - If qseq, 1 line is parsed at a time and the next read in the section
     is N lines away.

 Every read pair is parsed/processed/trimmed using process_PE_reads
 	
=head1 I/O 

=head2 Input parameter details

 See the initialization syntax " my ( ...) = @_" below; each parameter is followed
 by a comment explaining its function.

=head2 Output 
 
 See NAME and SYNOPSIS sections above for details. The resulting files are:
 (X = thread number)
  /temp/
	X.counts.txt
	X.trimmed_reads_1.fastq (only if mode = trim)
	X.trimmed_reads_2.fastq (only if mode = trim)
	X.surviving_mates.fastq 
	X.extracted_5adpt_seqs.txt (only if -methods includes 5adpt)
	X.discarded_reads.fastq (only if -print_discarded_reads yes)
 
=head1 AUTHOR

 Sari Khaleel (skhaleel at udel.edu)
 Last modified on 1-26-2012

=cut

sub process_PE_files_section{
	my ($thread_num, $num_threads, $read_format,
        
        # FilePaths
			$input_filepath_1, $input_filepath_2,$out_dir,
		
        # Main params
			$methods_include_qseq0, $methods_include_5adpt,
			$mode, $method_sequence_arr_ref, $min_read_length,
			$ASCII_of_zero_qual_score, $qseq_dot_to_N, $print_discarded_reads,
			$header_tag,
		
        # Method params
            # PE_ThreeEnd, PE_FiveEnd
                $n_threeEnd,$n_fiveEnd,
            # PE_five_prime_adpt
                $five_prime_r1_adpt_arr_ref, $five_prime_r2_adpt_arr_ref,
                $match_percentage, $furthest_allowed_index_for_adapter_match, 
                $adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
            # PE_LQR
                $LQS_cutoff, $QPerc_cutoff,
            # PE_Mott, PE_Ncutoff, PE_NPerc, PE_Nsplit
                $mott_limit, $N_cutoff, $Nperc_cutoff,$nsplit_n_cutoff, 
            # qseqB
                $B_num_cutoff, $qB_mode, $action, 
            # TERA
                $avg_cutoff,
			# rmHP
				$rmHP_min_length, $rmHP_bases_arr_ref
	) = @_;
	
	my $one_thread = ($num_threads == 1);
	#die $one_thread;
	
	# 0. translate print_discarded_reads from string to binary
		my $print_discarded_reads_flag;
		if ($print_discarded_reads eq "yes") {$print_discarded_reads_flag = 1;}
		else {$print_discarded_reads_flag = 0;}
		
	# 1. Open chunk handles
		my $temp_out_dir = "$out_dir/temp";
		if (! -e $temp_out_dir){
			system ("mkdir $temp_out_dir");
		}
		my ($trimmed_reads_1_fH, $trimmed_reads_2_fH, $five_prime_extracted_adpt_fH, $discarded_reads_1_fH, $discarded_reads_2_fH, $surv_fH, $counts_fH);
		
		open $counts_fH, "> $temp_out_dir/$thread_num.counts.txt";
		if ($mode eq "trim") {
			open $trimmed_reads_1_fH, "> $temp_out_dir/$thread_num.trimmed_reads_1.fastq";
			open $trimmed_reads_2_fH, "> $temp_out_dir/$thread_num.trimmed_reads_2.fastq";
			open $surv_fH, "> $temp_out_dir/$thread_num.surviving_mates.fastq";
		}
		if ($methods_include_5adpt){open $five_prime_extracted_adpt_fH, "> $temp_out_dir/$thread_num.extracted_5adpt_seqs.txt";}
		if ($print_discarded_reads_flag){
			open $discarded_reads_1_fH, "> $temp_out_dir/$thread_num.discarded_reads_1.fastq";
			open $discarded_reads_2_fH, "> $temp_out_dir/$thread_num.discarded_reads_2.fastq";
		}
	
	# 2. Initialize main counters
		my ($thread_read_count, $thread_base_count)  = (0,0);
					
    # 3. Initialize Local counters 
		my (
		 # PE_ThreeEnd
			$num_bases_trimmed_by_ThreeEnd, $num_reads_trimmed_by_ThreeEnd, $num_pairs_trimmed_by_ThreeEnd,
		 # PE_FiveEnd
			$num_bases_trimmed_by_FiveEnd, $num_reads_trimmed_by_FiveEnd,$num_pairs_trimmed_by_FiveEnd,
		 # PE_five_prime_adpt
			$num_adpt_trimmed_bases,
			$num_adpt_trimmed_reads, $num_adpt_trimmed_pairs,
			$num_detected_adapter_sequences, 
		 # PE_LQR
			$number_of_LQR_trimmed_bases, $number_of_LQR_trimmed_reads,$number_of_LQR_trimmed_pairs,
		 # PE_Mott
			$num_mott_trimmed_bases, $num_mott_trimmed_reads,$num_mott_trimmed_pairs,
		 # PE_Ncutoff
			$num_bases_trimmed_by_Ncuotff, $num_reads_trimmed_by_Ncuotff,$num_pairs_trimmed_by_Ncuotff,
		 # PE_NPerc
			$num_bases_trimmed_by_Nperc, $num_reads_trimmed_by_Nperc,$num_pairs_trimmed_by_Nperc,
		 # PE_Nsplit
			$num_of_removed_bases_using_Nsplit, $num_of_removed_N_blocks,$num_of_Nsplit_removed_pairs,
			$num_of_Nsplit_removed_reads, 
		 # qseq0
			$num_bases_trimmed_by_qseq0, $num_reads_trimmed_by_qseq0, $num_pairs_trimmed_by_qseq0,
		 # qseqB
			$num_bases_trimmed_by_qseqB,$num_reads_trimmed_by_qseqB,$num_pairs_trimmed_by_qseqB,
		 # TERA
			$num_TERA_trimmed_bases,$num_TERA_trimmed_reads,$num_TERA_trimmed_pairs,
		# rmHP
			$num_rmHP_trimmed_bases,$num_rmHP_trimmed_reads,$num_rmHP_trimmed_pairs
			
			)
		= (0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,0,0,0);
	
	# 4. Open the input and log files
		my $IN1; my $IN2; my $uncompress;
		
		if ($input_filepath_1 =~ /\.zip$/i) {
			if(grep { -x "$_/unzip"} split /:/,$ENV{PATH}) {
			  $uncompress = 'unzip -p'; # -p = pipe output to STDOUT
			}
			else {
				  print "unzip is not in your PATH, please add it\n";
				  exit 1;
			}
		}
		elsif ($input_filepath_1 =~ /\.gz$/i) {
			if(grep { -x "$_/gzip"}split /:/,$ENV{PATH}) {
				$uncompress = 'gzip -cd'; # -d = decompress; -c = write to STDOUT
			}
			else {
				print "gzip is not in your PATH, please add it\n";
				exit 1;
			}
		}
		elsif ($input_filepath_1 =~ /\.bz2$/i) {
			if(grep { -x "$_/bzip2"}split /:/,$ENV{PATH}) {
				$uncompress = 'bzip2 -cd';
			}
			else {
				print "bzip2 is not in your PATH, please add it\n";
				exit 1;
			}
		}
		
		
		if ($uncompress) {
			open ($IN1, "$uncompress $input_filepath_1|")|| die("ERROR: $uncompress can not read file ($input_filepath_1): $!\n");
			open ($IN2, "$uncompress $input_filepath_2|")|| die("ERROR: $uncompress can not read file ($input_filepath_2): $!\n");
		}
		else {
			open ($IN1, $input_filepath_1) || die("ERROR: Can not read file ($input_filepath_1): $!\n");
			open ($IN2, $input_filepath_2) || die("ERROR: Can not read file ($input_filepath_2): $!\n");
		}
		
		
		
	# 5. First, skip to the correct start position, count*num_lines_per_read
		my $num_lines_per_read = 1; if ($read_format eq "fastq") {$num_lines_per_read = 4;}
		my $start_position = 0; my ($Line1, $Line2);
		while (($thread_num *$num_lines_per_read) > $start_position){
			$Line1 = <$IN1>;
			$Line2 = <$IN2>;
			$start_position++;
		}
	
	# 6. Begin to parse the file
		my $done = 0;
		my $first_line_in_file = 1; # This is used to check the file's format (fastq vs qseq)
		my ($line1_1, $line1_2,$line1_3, $line1_4,$line2_1, $line2_2,$line2_3, $line2_4, $read1, $read2);
		
		while (!$done){
			$line1_1 = <$IN1>;
			$line2_1 = <$IN2>;
			
			# Determine the file's format (fastq vs qseq) <-- I deactivated the fastQ check part bc fastQ read headers no longer start with @
				if ($first_line_in_file){
					$first_line_in_file = 0;
					if ($line1_1 && $line2_1){
						if (($line1_1 =~ /\d+\t\d+\t\d+/) && ($line2_1 =~ /\d+\t\d+\t\d+/)){ # qseq lines have several nums separated by tabs.
							$read_format = "qseq";
						}
						#elsif (($line1_1 =~ /^@/) && ($line2_1 =~ /^@/)){  # fastq reads begin with a header line that begins with @
						#	$read_format = "fastq";
						#}
						else{
							$read_format = "fastq";
						}
						#else {
						#	die "ERROR (reading the first line from the files $input_filepath_1 && $input_filepath_2):\n\tRead format is neither fastq (line doesn't start with @) nor qseq (line doesn't have multiple nums sep.ed by tabs.\n";
						#}
					}
				}# end if $first_line_in_file
				
			if ($read_format eq "fastq") {
				$line1_2 = <$IN1>;$line2_2 = <$IN2>;
				$line1_3 = <$IN1>;$line2_3 = <$IN2>;		
				$line1_4 = <$IN1>;$line2_4 = <$IN2>;
				
				if (!($line1_1 && $line1_2 && $line1_3 && $line1_4 && $line2_1 && $line2_2 && $line2_3 && $line2_4)){
					print "Thread \#$thread_num has reached EOF\n" if !$one_thread;
					$done = 1;
				}
				else{# if not EOF
					chomp ($line1_1); chomp ($line1_2); chomp ($line1_3); chomp ($line1_4);
					chomp ($line2_1); chomp ($line2_2); chomp ($line2_3); chomp ($line2_4);
					
					$read1 = new single_fQ_read(
								_header => $line1_1,
								_seq    => $line1_2,
								_comment => $line1_3,
								_qual =>   $line1_4,
								_min_rl => $min_read_length,
								_ascii_zero => $ASCII_of_zero_qual_score,
								_call_from => "process_PE_files_section: read1 creation");
							 
					$read2 = new single_fQ_read(
								_header => $line2_1,
								_seq    => $line2_2,
								_comment => $line2_3,
								_qual =>   $line2_4,
								_min_rl => $min_read_length,
								_ascii_zero => $ASCII_of_zero_qual_score,
								_call_from => "process_PE_files_section: read2 creation");
				}
			}# end if ($read_format eq "fastq") {
			elsif ($read_format eq "qseq") {
				if (!($line1_1 && $line2_1)){
					print "\nThread \#$thread_num has reached EOF\n" if !$one_thread;
					$done = 1;
				}
				else{
					chomp ($line1_1);chomp ($line2_1);
					$read1 = get_single_fQ_read_from_qseq($line1_1,$min_read_length,$ASCII_of_zero_qual_score, $qseq_dot_to_N);
					$read2 = get_single_fQ_read_from_qseq($line2_1,$min_read_length,$ASCII_of_zero_qual_score, $qseq_dot_to_N);
				}
			}	
			
			if (!$done){	
				## a. Check that read headers are matching <-- deactivated b/c the headers no longer have to be _1 and _2
				#	if ($line1_1 ne $line2_1){# line1_1 and line2_1 are the headers of read1 and read2, respectively
				#		die "ERROR (process_two_PE_files: Loading PE Reads) : the header lines of the following reads ".
				#		"are not matching:\nRead _1:\n".
				#		$read1->return_fQ_string."\n\nRead _2:\n".$read2->return_fQ_string.
				#		"\n\nngsShoRT assumes that PE files have the same ordering of reads and that paired reads have ".
				#		"the same header (minus the read's pairing number).\n";
				#	}
				
				# b. Update Thread counts
					$thread_read_count  += 2; 
					$thread_base_count += (length $line1_2) + (length $line2_2); #($read1->get_length) + ($read2->get_length);
				
				# c. Create a PE pair from read1 and read2
					my $PE_pair = new PE_fQ_pair(
								 _read1 => $read1,
								 _read2 => $read2
									);
					my @array = ($PE_pair);
					my $PE_pairs_set = new fQ_array(_arr_ref => \@array);
				
				# d. call the process_PE_read_pair subroutine
					&process_PE_read_pair ( 
						$PE_pairs_set,
					# Main parameters
						$mode, $method_sequence_arr_ref, $min_read_length, $print_discarded_reads_flag,
						$header_tag,
					
					# Filehandles
						$trimmed_reads_1_fH, $trimmed_reads_2_fH,$surv_fH,
						$discarded_reads_1_fH, $discarded_reads_2_fH,
						
					# Method Parameters and trimmed base/read/pair counter references
					 # PE_ThreeEnd
						$n_threeEnd, \$num_bases_trimmed_by_ThreeEnd, \$num_reads_trimmed_by_ThreeEnd,\$num_pairs_trimmed_by_ThreeEnd,
					 # PE_FiveEnd
						$n_fiveEnd,\$num_bases_trimmed_by_FiveEnd, \$num_reads_trimmed_by_FiveEnd,\$num_pairs_trimmed_by_FiveEnd,
					 # PE_five_prime_adpt
						$five_prime_r1_adpt_arr_ref, $five_prime_r2_adpt_arr_ref, 
						$match_percentage, $furthest_allowed_index_for_adapter_match, 
						$five_prime_extracted_adpt_fH,$adpt_action, \$num_adpt_trimmed_bases,
						\$num_adpt_trimmed_reads,\$num_adpt_trimmed_pairs, $adpt_max_match_len_diff,
						\$num_detected_adapter_sequences, $num_inss, $num_dels, $num_subs,
					 # PE_LQR
						$LQS_cutoff, $QPerc_cutoff,\$number_of_LQR_trimmed_bases, \$number_of_LQR_trimmed_reads,\$number_of_LQR_trimmed_pairs,
					 # PE_Mott
						$mott_limit,\$num_mott_trimmed_bases, \$num_mott_trimmed_reads,\$num_mott_trimmed_pairs,
					 # PE_Ncutoff
						$N_cutoff, 
						\$num_bases_trimmed_by_Ncuotff, \$num_reads_trimmed_by_Ncuotff,\$num_pairs_trimmed_by_Ncuotff,
					 # PE_NPerc
						$Nperc_cutoff, 
						\$num_bases_trimmed_by_Nperc, \$num_reads_trimmed_by_Nperc,\$num_pairs_trimmed_by_Nperc,
					 # PE_Nsplit
						$nsplit_n_cutoff, \$num_of_removed_bases_using_Nsplit, \$num_of_removed_N_blocks,
						\$num_of_Nsplit_removed_reads, \$num_of_Nsplit_removed_pairs,
					 # qseq0
						\$num_bases_trimmed_by_qseq0, \$num_reads_trimmed_by_qseq0, \$num_pairs_trimmed_by_qseq0,
					 # qseqB
						$B_num_cutoff, $qB_mode, $action, \$num_bases_trimmed_by_qseqB,
						\$num_reads_trimmed_by_qseqB,\$num_pairs_trimmed_by_qseqB,
					 # TERA
						$avg_cutoff, \$num_TERA_trimmed_bases,\$num_TERA_trimmed_reads,\$num_TERA_trimmed_pairs,
					# rmHP
						$rmHP_min_length, $rmHP_bases_arr_ref, \$num_rmHP_trimmed_bases,\$num_rmHP_trimmed_reads,\$num_rmHP_trimmed_pairs
					);
					
				# f. skip by a step size of n_children * 4
					for (my $i =0; $i< (($num_threads -1) * $num_lines_per_read); $i++){
						$Line1 = <$IN1>;$Line2 = <$IN2>;
					}
				
			}# end if !done						
		}# end while
		
	# 7. Print your count results
		print $counts_fH  "$thread_read_count,$thread_base_count,"
						 ."$num_bases_trimmed_by_ThreeEnd,$num_reads_trimmed_by_ThreeEnd,$num_pairs_trimmed_by_ThreeEnd,"
						 ."$num_bases_trimmed_by_FiveEnd,$num_reads_trimmed_by_FiveEnd,$num_pairs_trimmed_by_FiveEnd,"
						 ."$num_adpt_trimmed_bases,$num_adpt_trimmed_reads,$num_adpt_trimmed_pairs,"
						 ."$num_detected_adapter_sequences,"
						 ."$number_of_LQR_trimmed_bases,$number_of_LQR_trimmed_reads,$number_of_LQR_trimmed_pairs,"
						 ."$num_mott_trimmed_bases,$num_mott_trimmed_reads,$num_mott_trimmed_pairs,"
						 ."$num_bases_trimmed_by_Ncuotff,$num_reads_trimmed_by_Ncuotff,$num_pairs_trimmed_by_Ncuotff,"
						 ."$num_bases_trimmed_by_Nperc,$num_reads_trimmed_by_Nperc,$num_pairs_trimmed_by_Nperc,"
						 ."$num_of_removed_bases_using_Nsplit,$num_of_removed_N_blocks,$num_of_Nsplit_removed_reads,$num_of_Nsplit_removed_pairs,"
						 ."$num_bases_trimmed_by_qseq0,$num_reads_trimmed_by_qseq0,$num_pairs_trimmed_by_qseq0,"
						 ."$num_bases_trimmed_by_qseqB,$num_reads_trimmed_by_qseqB,$num_pairs_trimmed_by_qseqB,"
						 ."$num_TERA_trimmed_bases,$num_TERA_trimmed_reads,$num_TERA_trimmed_pairs,"
						 ."$num_rmHP_trimmed_bases,$num_rmHP_trimmed_reads,$num_rmHP_trimmed_pairs"
						 ."\n";

    # 8. Close the filehandles
		close $IN1; close $IN2;
		close $counts_fH;
		if ($mode eq "trim") {close $trimmed_reads_1_fH;close $trimmed_reads_2_fH;close $surv_fH;}
		if ($methods_include_5adpt){close $five_prime_extracted_adpt_fH;}
		if ($print_discarded_reads_flag){close $discarded_reads_1_fH;close $discarded_reads_2_fH;}
}# end sub process_file_section
