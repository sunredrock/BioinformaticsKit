# Sari Khaleel (Sari.S.Khaleel.DM AT dartmouth.edu)
# Dartmouth Medical School
# Last updated 05-07-2013


#!/usr/bin/perl

use warnings;
use strict;
use FindBin;
use Getopt::Long qw(:config no_ignore_case);

# 1st, set the directory for modules to the local directory for this perl script
use lib "$FindBin::Bin/../libs/lib64/perl5/";
use lib "$FindBin::Bin/ngsShoRT_2.2_modules/trimming_modules";
use lib "$FindBin::Bin/ngsShoRT_2.2_modules/report_modules";
use lib "$FindBin::Bin/ngsShoRT_2.2_modules/processing_modules";
use lib "$FindBin::Bin/ngsShoRT_2.2_modules/processing_modules/PE";
use lib "$FindBin::Bin/ngsShoRT_2.2_modules/processing_modules/SE";
use lib "$FindBin::Bin/ngsShoRT_2.2_modules/read_classes";

# 2nd, use the correct processing modules
use manage_input_params 1.0;
use process_two_PE_files 1.0;
use process_SE_read_file 1.0;
use manage_multiple_input_files 1.0;


#=========================== USAGE ==================================
my $program=`basename $0`;
chomp $program;

my $usage =<<USAGE;

Usage (see manuals/quick_manual for extended usage details):
 > perl $program  -h              returns this message
 > perl $program  -full_help      returns the long version of the usage
 
* To run trimmer on PE files _1 and _2:
  -------------------------------------
  perl $program [-t <n_threads>] -pe1 <PE_file #1>  -pe2 <PE_file #2> -o <Output dirpath> [-gzip] -methods <m1_m2_m3_..> [method parameters]
 
  where  pe1 = forward reads file, pe2 = reverse reads file
         Default n_threads = 10, and method parameters are set to their default values listed in the full usage

* To run trimmer on a single file:
  --------------------------------
 perl $program [-t n_threads] -se <filepath> -o <Output dirpath> -methods <m1_m2_m3_..> [method parameters] 
 
 
* Available methods (the m1_m2_m3 above):
  ---------------------------------------
  5adpt lqr tera nsplit mott nperc ncutoff qseqB qseq0 3end 5end rmHP i2s s2i
                                 
  Example: -methods lqr_5adpt_mott will run lqr, then 5adpt, then mott on every read (pair)


* Compressed I/O:
  ---------------------------------------
  I: ngsShoRT auto-detects and opens file with the extension .gz, .zip, and .bz2
  O: Use -gzip option if you'd like your trimmed output to be gzipped (Default is no gzip)

USAGE


my $full_usage =<<USAGE;

Usage (see manual for details):
 > perl $program  -h  returns short usage 
 > perl $program  -full_help returns this message

To run trimmer using parameters set in a parameters_file.txt (recommended for beginners), which can be
created by modifying /path/ngsShoRT_2.0/input_file_TEMPLAE.txt:
 > perl $program  -i /path/parameters_file.txt [-t n_threads]
 
 
* To run trimmer from commandline on PE files _1 and _2:
  ------------------------------------------------------
  perl $program [-t <n_threads>] -pe1 <PE_file #1>  -pe2 <PE_file #2> -o <Output dirpath> [-gzip] -methods <m1_m2_m3_..> [method parameters]
 
  where  pe1 = forward reads file, pe2 = reverse reads file
         Default n_threads = 10, and method parameters are set to their default values listed in the full usage 

* To run trimmer from commandline  on a single file:
  --------------------------------------------------
  perl $program [-t n_threads] -se <filepath> -o <Output dirpath> -methods <m1_m2_m3_..> [method parameters] 
 
 
 * Compressed I/O:
  ---------------------------------------
  I: ngsShoRT auto-detects and opens file with the extension .gz, .zip, and .bz2
  O: Use -gzip option if you'd like your trimmed output to be gzipped (Default is no gzip)
  
 
* Available methods (the m1_m2_m3 above):
  ---------------------------------------
  5adpt lqr tera nsplit mott nperc ncutoff qseqB qseq0 3end 5end rmHP i2s s2i
                                 
  Example: -methods lqr_5adpt_mott will run lqr, then 5adpt, then mott on every read (pair)
 
 -pe1 paired_end_1.fastq  -pe2 paired_end_2.fastq  (qseq OK) For Paired-End  input 
 -se single_read.fastq,..                          (qseq OK) For Single Read input. Multiple SE files must
                                                    be separated by commas.
													
 
 [-mode (trim|report) ]       -> Default is'trim', produces trimmed files
 [-print_discarded_reads (yes|no)]  -> Print out reads that were discarded from the source file. Default is no.
 [-min_rl INT]                -> min_rl = minimum read length. Default is 21
 [-ascii_zero (i | s | INT)]  -> the value of ascii char equivalent to 0 Phred. s= 33 (Sanger), i= 64 (Illumina < 1.8). 
                                 Default is 33 (Sanger). User can also enter a custom integer value
 [-qseq_dot2N  (yes|no)]      -> convert qseq '.' to fastq 'N'. Default is yes. NOTE that ngShoRT treats
                                 '.' and 'N' equally. This option's goal is just the final Sanger "look"
 [-Header_tag (yes|no)]       -> append "|trimmed_by_m1_m2_m3" (m1,m2, m3 are the used methods) to the header
                                 of each read (Default = yes). See manual for more info on header content.
 
 
 ### The following options allow you to change trimming method parameters from their default values ###
 ###------------------------------------------------------------------------------------------------###
 [-nperc_p INT]               -> cutoff % of N/. bases for nperc. Default is 50
 [-nsplit_len -ncutoff_len]   -> N-block length cutoff for nsplit & ncutoff. Default is 5, 50 rspctvly.
                                 -nucutoff_len 5 => discard reads with (>= 5) Ns.
 [-lqs INT] [-lq_p INT]       -> lqs = low qual score cutoff (Default = 2). lq_p = cutoff perc of bas-
                                 es with qual scores <= lqs, Default is 50. (lqs=2, lq_p=50) means remove
                                 reads where >=50% of bases have quality scores <=2.
 [-tera_avg INT]              -> cutoff running avg qual score for TERA. Default = 2
 [-n3 INT] [-n5 INT]          -> num of bases to trim from the 3' or 5' end of ALL reads. Default is 0
 [-mott_lim FLOAT]            -> mott_limit. Default is 0.6 (see quick_manual)
  
 [-5a_f (lib_code | filepath)]-> adapter seq.s file, which can be one of our built-in libraries for Illumina 
                                 and 454 primers (please see quick_manual.txt for the list) or a user specified
                                 filepath (the file MUST follow the five_prime_adapter_seq_TEMPLATE.txt format).
                                 Default is "i-g" (Illumina Genomic library), see quick_manual.txt for others
								 
 [-5a_mp INT]                 -> mp = match percentage (Default = 100). 
                                 E.g., 5a_mp = 90 allows one indel/sub per 10 bases of target sequence 
 [-5a_ins INT]                -> ins = max number of allowed insertions (within the mp <100), default = 0
 [-5a_del INT]                -> del = max number of allowed deletions (within the mp <100), default = 0
 [-5a_sub INT]                -> sub = max number of allowed substitutions (within the mp <100), default = 0
                                 So, in commandline, -5a_mp 90 -5a_del 0 -5a_ins 0 means allow ONLY one substitution
                                 per 10 bases in target sequence
 
 [-5a_fmi (full | INT)]       -> fmi = furthest matching index. Default is full read length = match can start 
                                 anywhere in read.
 [-5a_axn (kr | ka)]          -> action if adpt is found. kr = kill read. ka (default) = kill at adpt start 
 
 [-qB_num INT]                -> cutoff num of B-scored bases (BSBs) for qseqB. Default  is 5                            
 [-qB_mode (global|local)]    -> global = count BSBs in the read, local (default) = find BSB string >= qB_num                      
 [-qB_axn (ka | kr)]          -> like -5a_axn. Default is ka, it works only with qB_mode = local

 [-rmHP_ml INT]               -> Sets the minimum length (ml) of your homopolymer. Default is 8
 [-rmHP_bases STRING]		  -> specifies the bases that can form homopolymers. Default is "agct" (all bases)

USAGE
#=========================== VARS ==================================

# BUILT-IN :  adapter file
my $built_in_adapter_lib_dirpath = "$FindBin::Bin/ngsShoRT_2.2_illumina_primers";
die "\nERROR (paths): built-in Illumina and 454 primer library dirpath not found at $built_in_adapter_lib_dirpath !\n" if (! -e $built_in_adapter_lib_dirpath);

# DEFINE INPUT VARS 
my (	
		# Number of threads
		$n_threads, $read_format,
		# File/Dir paths
		$SE_input_filepath,            # The path of the input file
		$PE_input_filepath_1,          # The path of the input file_1
		$PE_input_filepath_2,          # The path of the input file_2,
		
		$se_dir_path,
		$pe_dir_path,
		
		$output_dir,                # The output directory where the log file
		$gzip,
		
		# Main parameters
		$min_read_length, #min_read_length is the minimum allowed size for a read to be included in the trimmed file or surviving mates
		$ASCII_of_zero_qual_score, #ASCII_of_zero_qual_score is the ASCII value of a zero quality score (64 for Illumina, 33 for Sanger)
		$mode, #mode is trim (produce trimmed file, along with other files), or report (do not produce a trimmed file)
		$method_sequence_arr_ref, # The ordered sequence of methods to be applied
		$print_discarded_reads,           # yes|no
		$qseq_dot_to_N,
		
		$pe_filename_pattern, $merge_dir,
		
		
		# Method Parameters and trimmed base/read/pair counter references
		 # PE_ThreeEnd, PE_FiveEnd, TERA
		  $n_threeEnd, $n_fiveEnd, $avg_cutoff,
		 # PE_five_prime_adpt
		  $five_prime_adapter_filepath, 
		  $match_percentage, $furthest_allowed_index_for_adapter_match, 
		  $adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
		 # PE_LQR
		  $LQS_cutoff, $QPerc_cutoff,
		 # PE_Mott
		  $mott_limit,
		 # PE_Ncutoff, PE_NPerc, PE_Nsplit
		  $N_cutoff, $Nperc_cutoff, $nsplit_n_cutoff, 
		 # qseqB
		  $B_num_cutoff, $qB_mode, $qB_action,
		  $header_tag,
		  
		  # rmHP options
		  $rmHP_min_length, $rmHP_bases_string
		);

#========================= DEFAULT VALUES ===============================
# Main parameters
	($n_threads, $read_format, $mode, $min_read_length, $ASCII_of_zero_qual_score,
	 $print_discarded_reads, $qseq_dot_to_N, $header_tag, $gzip)
	= (10, "fastq", "trim", 21, 33, "no", "yes", "yes", 0);
	
	($pe_filename_pattern, $merge_dir) = ("x_x_N_x_x.x", "no");
	
# Method parameters
		 # ThreeEnd, FiveEnd, TERA
		  $n_threeEnd = 0 ; $n_fiveEnd = 0; $avg_cutoff = 2;
		 # ive_prime_adpt
		  $five_prime_adapter_filepath = "i-g";  
		  $match_percentage = 100; $furthest_allowed_index_for_adapter_match = 'full'; 
		  $adpt_action = 'ka'; $adpt_max_match_len_diff = 3; 
		 # LQR
		  $LQS_cutoff = 4; $QPerc_cutoff = 50;
		 # Mott
		  $mott_limit = 0.6;
		 # Ncutoff, NPerc, Nsplit
		  $N_cutoff = 50; $Nperc_cutoff = 50; $nsplit_n_cutoff = 5; 
		 # qseqB
		  $B_num_cutoff = 5; $qB_mode = 'local'; $qB_action = 'ka';
		  $rmHP_min_length = 8; $rmHP_bases_string = "agct";


#========================= MANAGE COMMANDLINE ===============================
die $usage unless @ARGV;

# Save the commandline
my $commandline = "\$ perl $program @ARGV";

my ($params_file, $help, $full_help, $methods_string, $opt_ascii); 

exit if !GetOptions("i=s"   => \$params_file,
					 "help"     => \$help,
					 "full_help" => \$full_help,
					 "t=i" => \$n_threads,
					 #"rf=s" => \$read_format,
				  
				  # File/Dir paths
						"pe1=s" => \$PE_input_filepath_1,
						"pe2=s" => \$PE_input_filepath_2,
						"se=s"  => \$SE_input_filepath,
						
						"dir_se=s" => \$se_dir_path,
						"dir_pe=s" => \$pe_dir_path,
						
						"o_dir=s" => \$output_dir,
						"gzip" =>\$gzip,
				 
				 
				 # Main vars
				  "mode=s" => \$mode,
				  "methods=s" => \$methods_string,
				  "min_rl=i" => \$min_read_length,
				  "ascii_zero=s" => \$opt_ascii,
				  "print_discarded_reads=s" => \$print_discarded_reads,
				  "qseq_dot2N=s" => \$qseq_dot_to_N,
				  "pe_fname_pattern=s" => \$pe_filename_pattern,
				  "merge_files=s" => \$merge_dir,
				  "Header_tag=s"=>\$header_tag,
									  
			    # ThreeEnd, FiveEnd, TERA, mott
				  "n3=i" => \$n_threeEnd, "n5=i" => \$n_fiveEnd, "tera_avg=i" => \$avg_cutoff,
				  "mott_lim=f" => \$mott_limit,
				 
				 # five_prime_adpt
				  "5a_f=s" => \$five_prime_adapter_filepath, 
				  "5a_mp=i" => \$match_percentage,
				 "5a_fmi=s" => \$furthest_allowed_index_for_adapter_match,
				 "5a_axn=s" => \$adpt_action,
				  "5a_ins=i" => \$num_inss, "5a_del=i" => \$num_dels, "5a_sub=i" => \$num_subs,
				  "5a_mx_len_dif=i" => \$adpt_max_match_len_diff,
			 
			   # LQR
				 "lqs=i"=>\$LQS_cutoff, "lq_p=i" => \$QPerc_cutoff,
				 
				 # Ncutoff, NPerc, Nsplit
				 "ncutoff_len=i" => \$N_cutoff, "nperc_p=i" => \$Nperc_cutoff,
				 "nsplit_len=i"=> \$nsplit_n_cutoff,
				 
				 # qseqB
				 "qB_num=i" => \$B_num_cutoff, "qB_mode=s" =>\$qB_mode,
				 "qB_axn=s" => \$qB_action,
				 
				 #rmHP
				 "rmHP_ml=i" =>\$rmHP_min_length,
				 "rmHP_bases=s" =>\$rmHP_bases_string
				 
	       );

# if commandlin contains -help, return usage
	  die $usage if ($help);
	  die $full_usage if ($full_help);

# Check that the number of threads is valid
	  die "ERROR: Invalid number of threads : must be >0\n" if ($n_threads <0);

	  #print "_1 = $PE_input_filepath_1\n _2 = $PE_input_filepath_2\n\n";
	  

if ($params_file){
	  ($SE_input_filepath, $PE_input_filepath_1, $PE_input_filepath_2, $output_dir,
		 $se_dir_path,$pe_dir_path,               
					# Main parameters
				$min_read_length, $ASCII_of_zero_qual_score, $mode, $method_sequence_arr_ref, 
				$print_discarded_reads, $qseq_dot_to_N,$pe_filename_pattern,$merge_dir, $header_tag,
			
				# Method Parameters and trimmed base/read/pair counter references
		  $n_threeEnd, $n_fiveEnd, $avg_cutoff, $mott_limit,

		  $five_prime_adapter_filepath, 
		  $match_percentage, $furthest_allowed_index_for_adapter_match, 
		  $adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
		 
		  $LQS_cutoff, $QPerc_cutoff,
		  $N_cutoff, $Nperc_cutoff, $nsplit_n_cutoff, 
		  $B_num_cutoff, $qB_mode, $qB_action,
		  $rmHP_min_length, $rmHP_bases_string) = &extract_parameters_from_input_file($params_file) ;
	  
}# end if $params_file


elsif (! $params_file){
	die "ERROR (main params: methods) : no methods were specified !!\n" if !($methods_string);	
	my @methods = split /_/, $methods_string;
	$method_sequence_arr_ref = \@methods;
	
	if ($opt_ascii){
		if ($opt_ascii eq "s") {$ASCII_of_zero_qual_score = 33;}
		elsif ($opt_ascii eq "i") {$ASCII_of_zero_qual_score = 64;}
		elsif (($opt_ascii =~ /^\d+/) && ($opt_ascii !~ /\D/)) {$ASCII_of_zero_qual_score = $opt_ascii;}
		else { die "\nERROR (main params: ascii_zero): Invalid value for -ascii_zero : $opt_ascii. Valid values are s, i, INT !!\n";}
	}
}


# ================================== INPUT VALIDATION ============================================	
&validate_input_params($mode, $min_read_length, $qseq_dot_to_N, $merge_dir, $header_tag,
		$method_sequence_arr_ref, $print_discarded_reads,
		$PE_input_filepath_1, $PE_input_filepath_2,$SE_input_filepath,
		$se_dir_path, $pe_dir_path,
		$output_dir,
		\$five_prime_adapter_filepath, $match_percentage, $adpt_action,
		\$furthest_allowed_index_for_adapter_match, $built_in_adapter_lib_dirpath,
		$nsplit_n_cutoff, $avg_cutoff, $mott_limit,
		$Nperc_cutoff, $N_cutoff, $QPerc_cutoff, $LQS_cutoff, $qB_action, $qB_mode,
		$rmHP_min_length, $rmHP_bases_string);

if ($header_tag eq "no"){$header_tag = "";}
 
# =================  HANDLE DIR CASES ====================================
if (! -e $output_dir) { system ("mkdir $output_dir");}
my (@se_filepaths, @pe_filepaths, @pe_output_dirs, @se_output_dirs, $dir_path);

my $big_temp_se_file =  "$output_dir/merged_SE_file";
my $big_temp_pe1_file = "$output_dir/merged_PE_1_file";
my $big_temp_pe2_file = "$output_dir/merged_PE_2_file";

&manage_multiple_input_files (\@se_filepaths, $SE_input_filepath, $se_dir_path,
							  $PE_input_filepath_1, $PE_input_filepath_2, \@pe_filepaths,$pe_dir_path,
							  \@pe_output_dirs, \@se_output_dirs,$output_dir,
							  $merge_dir,
							  $pe_filename_pattern,
							  $big_temp_se_file, $big_temp_pe1_file, $big_temp_pe2_file
							  );

#die;

# =================  PROCESS READS ====================================	
if (@$method_sequence_arr_ref){
	if ($SE_input_filepath || $se_dir_path){
		foreach my $se_filepath (@se_filepaths) {
			my $se_output_dir = pop @se_output_dirs;
			
			&process_SE_read_file(
				$commandline,
				$n_threads,$read_format,$gzip,
				$mode, #mode is trim (produce trimmed file, along with other files), or report (do not produce a trimmed file)
				$method_sequence_arr_ref, # The ordered sequence of methods to be applied
				$se_filepath,          # The path of the input file
				$se_output_dir,                # The output directory where the log file
				$print_discarded_reads,           # yes|no
				$qseq_dot_to_N,$header_tag,
				
				# Main parameters
				$min_read_length, #min_read_length is the minimum allowed size for a read to be included in the trimmed file or surviving mates
				$ASCII_of_zero_qual_score, #ASCII_of_zero_qual_score is the ASCII value of a zero quality score (64 for Illumina, 33 for Sanger),
				
				# Method Parameters and trimmed base/read/pair counter references
				 # SE_ThreeEnd, SE_FiveEnd, TERA
					$n_threeEnd, $n_fiveEnd, $avg_cutoff,
				 # SE_five_prime_adpt
					$five_prime_adapter_filepath, 
					$match_percentage, $furthest_allowed_index_for_adapter_match, 
					$adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
				 # SE_LQR
					$LQS_cutoff, $QPerc_cutoff,
				 # SE_Mott
					$mott_limit,
				 # SE_Ncutoff, SE_NPerc, SE_Nsplit
					$N_cutoff, $Nperc_cutoff, $nsplit_n_cutoff, 
				 # qseqB
					$B_num_cutoff, $qB_mode, $qB_action,
			     # rmHP
				    $rmHP_min_length, $rmHP_bases_string 
				);
		}# end foreach
	}# end if SE
	
	if (($PE_input_filepath_1 && $PE_input_filepath_2) || $pe_dir_path){
		while (@pe_filepaths) {
			my ($pe_filepath_1, $pe_filepath_2)  = (pop @pe_filepaths, pop @pe_filepaths);
			#die "($pe_filepath_1, $pe_filepath_2) \n";
			
			my $pe_output_dir = pop @pe_output_dirs;
			#print "$pe_filepath_1, $pe_filepath_2, $output_dir\n";
			
			&process_two_PE_files(
			$commandline,
			$n_threads,$read_format,$gzip,
			
			$mode, #mode is trim (produce trimmed file, along with other files), or report (do not produce a trimmed file)
			$method_sequence_arr_ref, # The ordered sequence of methods to be applied
			$pe_filepath_1,          # The path of the input file_1
			$pe_filepath_2,          # The path of the input file_2
			$pe_output_dir,                # The output directory where the log file
			$print_discarded_reads,           # yes|no
			$qseq_dot_to_N,$header_tag,
			
			# Main parameters
			$min_read_length, #min_read_length is the minimum allowed size for a read to be included in the trimmed file or surviving mates
			$ASCII_of_zero_qual_score, #ASCII_of_zero_qual_score is the ASCII value of a zero quality score (64 for Illumina, 33 for Sanger)
			
			# Method Parameters and trimmed base/read/pair counter references
			 # PE_ThreeEnd, PE_FiveEnd, TERA
				$n_threeEnd, $n_fiveEnd, $avg_cutoff,
			 # PE_five_prime_adpt
				$five_prime_adapter_filepath, 
				$match_percentage, $furthest_allowed_index_for_adapter_match, 
				$adpt_action, $adpt_max_match_len_diff, $num_inss, $num_dels, $num_subs,
			 # PE_LQR
				$LQS_cutoff, $QPerc_cutoff,
			 # PE_Mott
				$mott_limit,
			 # PE_Ncutoff, PE_NPerc, PE_Nsplit
				$N_cutoff, $Nperc_cutoff, $nsplit_n_cutoff, 
			 # qseqB
				$B_num_cutoff, $qB_mode, $qB_action,
			 # rmHP
			    $rmHP_min_length, $rmHP_bases_string
				);
		}# end while
	}# end if PE
	
}# end if (@$method_sequence_arr_ref)

if (-e $big_temp_se_file)  { system ("rm $big_temp_se_file");}
if (-e $big_temp_pe1_file) { system ("rm $big_temp_pe1_file");}
if (-e $big_temp_pe2_file) { system ("rm $big_temp_pe2_file");}

print "Done-MAIN.\n";
exit (0);

#======================================================================


